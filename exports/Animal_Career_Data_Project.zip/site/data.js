window.EXPLORER_DATA = {
  "glossary": [
    {
      "term": "Animal behavior",
      "definition": "The scientific study of what animals do and why, including learning, communication, social behavior, movement, feeding, reproduction, and responses to the environment."
    },
    {
      "term": "Applied animal behavior",
      "definition": "Using scientific knowledge about behavior and learning to solve practical problems involving animals, such as improving welfare, reducing problem behaviors, designing training plans, or improving management."
    },
    {
      "term": "Cognition",
      "definition": "How animals perceive, learn, remember, solve problems, make decisions, and process information."
    },
    {
      "term": "Husbandry",
      "definition": "Day-to-day professional care and management of animals under human care, including feeding, cleaning, health observation, enclosure maintenance, recordkeeping, enrichment, training, and safe handling."
    },
    {
      "term": "Behavioral husbandry",
      "definition": "Using observation, learning principles, enrichment, and training as part of animal care to support welfare and make routine care or medical procedures easier and less stressful."
    },
    {
      "term": "Animal welfare",
      "definition": "The physical and psychological well-being of an animal, including health, comfort, appropriate behavior, stress, environmental quality, and quality of life."
    },
    {
      "term": "Enrichment",
      "definition": "Changes, objects, choices, or activities designed to give animals meaningful opportunities to explore, forage, solve problems, exercise, or perform species-appropriate behavior."
    },
    {
      "term": "Ecology",
      "definition": "The study of relationships among organisms and their environment, including habitats, resources, other species, and ecological conditions."
    },
    {
      "term": "Behavioral ecology",
      "definition": "The study of how behavior relates to survival, reproduction, evolution, and environmental conditions."
    },
    {
      "term": "Population ecology",
      "definition": "The study of how and why populations change in size, distribution, survival, reproduction, and composition."
    },
    {
      "term": "Conservation biology",
      "definition": "Science aimed at understanding and protecting biodiversity, species, populations, and ecosystems."
    },
    {
      "term": "Restoration",
      "definition": "Work intended to repair or improve damaged habitats or ecological systems, such as wetlands, forests, streams, or native habitat."
    },
    {
      "term": "Wildlife rehabilitation",
      "definition": "Caring for injured, sick, or orphaned wild animals with the goal, when possible, of returning them to the wild."
    },
    {
      "term": "Reintroduction",
      "definition": "Releasing animals into an area where a species has disappeared or declined, usually as part of a conservation program."
    },
    {
      "term": "Conservation breeding",
      "definition": "Managed breeding of threatened species to support population survival, genetic diversity, or eventual reintroduction."
    },
    {
      "term": "Monitoring",
      "definition": "Systematically collecting information over time to determine what is happening, such as tracking behavior, movement, survival, population size, or habitat use."
    },
    {
      "term": "Post-release monitoring",
      "definition": "Following animals after rehabilitation, translocation, or reintroduction to determine where they go, whether they survive, how they behave, and whether the release was successful."
    },
    {
      "term": "Telemetry",
      "definition": "Using radio transmitters, GPS tags, acoustic tags, or similar technology to track animals and study movement, habitat use, survival, or behavior."
    },
    {
      "term": "GIS",
      "definition": "Geographic Information Systems: software and methods for working with mapped or spatial information such as animal locations, habitat, land use, or environmental conditions."
    },
    {
      "term": "Quantitative ecology",
      "definition": "Using statistics, mathematical models, and data analysis to study ecological questions such as population change, movement, habitat use, or survival."
    },
    {
      "term": "Organismal biology",
      "definition": "Studying whole animals and how anatomy, physiology, behavior, development, and evolution work."
    },
    {
      "term": "Neuroethology",
      "definition": "Studying how nervous systems produce natural animal behavior."
    },
    {
      "term": "Field ecology",
      "definition": "Ecological work conducted in natural settings, often involving observation, sampling, species identification, habitat measurements, or tracking."
    },
    {
      "term": "Research",
      "definition": "A systematic attempt to answer a question using evidence: defining a question, selecting methods, collecting data, analyzing results, and communicating conclusions."
    }
  ],
  "topics": [
    {
      "id": "topic0",
      "label": "Individual animal behavior",
      "help": "Why a particular animal behaves the way it does.",
      "dims": [
        0
      ]
    },
    {
      "id": "topic1",
      "label": "Animal learning",
      "help": "How behavior changes through experience and training.",
      "dims": [
        0,
        1
      ]
    },
    {
      "id": "topic2",
      "label": "Animal cognition",
      "help": "How animals perceive, remember, solve problems, and make decisions.",
      "dims": [
        0
      ]
    },
    {
      "id": "topic3",
      "label": "Animal communication",
      "help": "How animals send, receive, and interpret signals.",
      "dims": [
        0,
        9
      ]
    },
    {
      "id": "topic4",
      "label": "Animal welfare",
      "help": "How to assess and improve physical and psychological well-being.",
      "dims": [
        1
      ]
    },
    {
      "id": "topic5",
      "label": "Animal care and husbandry",
      "help": "The professional daily care and management of animals.",
      "dims": [
        1
      ]
    },
    {
      "id": "topic6",
      "label": "Wildlife in natural environments",
      "help": "How wild animals behave, move, survive, and interact with habitat.",
      "dims": [
        3,
        6
      ]
    },
    {
      "id": "topic7",
      "label": "Wildlife rehabilitation",
      "help": "Helping injured, sick, or orphaned wildlife recover for possible release.",
      "dims": [
        3,
        4
      ]
    },
    {
      "id": "topic8",
      "label": "Release and reintroduction",
      "help": "Returning animals to the wild and evaluating what happens afterward.",
      "dims": [
        4
      ]
    },
    {
      "id": "topic9",
      "label": "Conservation",
      "help": "Protecting species, populations, biodiversity, and ecological systems.",
      "dims": [
        3,
        6
      ]
    },
    {
      "id": "topic10",
      "label": "Animal physiology",
      "help": "How bodies and biological systems function.",
      "dims": [
        5
      ]
    },
    {
      "id": "topic11",
      "label": "Brain–behavior relationships",
      "help": "How nervous systems produce behavior.",
      "dims": [
        0,
        5
      ]
    },
    {
      "id": "topic12",
      "label": "Evolution",
      "help": "Why biological traits and behaviors evolved.",
      "dims": [
        0,
        5
      ]
    },
    {
      "id": "topic13",
      "label": "Habitats and ecosystems",
      "help": "How animals interact with environmental conditions and other species.",
      "dims": [
        3,
        6
      ]
    },
    {
      "id": "topic14",
      "label": "Scientific research",
      "help": "Answering questions systematically with data and evidence.",
      "dims": [
        7,
        8
      ]
    },
    {
      "id": "topic15",
      "label": "Environmental problem-solving",
      "help": "Applying science to habitat, regulation, restoration, or conservation decisions.",
      "dims": [
        3,
        6
      ]
    },
    {
      "id": "topic16",
      "label": "Education and communication",
      "help": "Helping other people understand animals, science, or conservation.",
      "dims": [
        0,
        6,
        9
      ]
    }
  ],
  "activities": [
    {
      "id": "act0",
      "label": "Carefully observe animal behavior for extended periods",
      "dims": [
        0,
        1
      ]
    },
    {
      "id": "act1",
      "label": "Record behavior systematically using an ethogram or coding scheme",
      "dims": [
        0
      ]
    },
    {
      "id": "act2",
      "label": "Work directly with animals",
      "dims": [
        8
      ]
    },
    {
      "id": "act3",
      "label": "Feed, clean, and perform routine husbandry",
      "dims": [
        1
      ]
    },
    {
      "id": "act4",
      "label": "Design enrichment activities",
      "dims": [
        1
      ]
    },
    {
      "id": "act5",
      "label": "Train animals using learning principles",
      "dims": [
        0,
        1
      ]
    },
    {
      "id": "act6",
      "label": "Assess whether an animal appears comfortable, stressed, engaged, or thriving",
      "dims": [
        1
      ]
    },
    {
      "id": "act7",
      "label": "Care for injured or recovering wildlife",
      "dims": [
        1,
        3,
        4
      ]
    },
    {
      "id": "act8",
      "label": "Prepare animals for release",
      "dims": [
        4
      ]
    },
    {
      "id": "act9",
      "label": "Collect biological or behavioral data outdoors",
      "dims": [
        0,
        3,
        7
      ]
    },
    {
      "id": "act10",
      "label": "Identify animals, plants, tracks, calls, or signs in the field",
      "dims": [
        3
      ]
    },
    {
      "id": "act11",
      "label": "Use telemetry or GPS data to follow animal movement",
      "dims": [
        3,
        7
      ]
    },
    {
      "id": "act12",
      "label": "Measure or evaluate habitat conditions",
      "dims": [
        3,
        6
      ]
    },
    {
      "id": "act13",
      "label": "Analyze data and look for patterns",
      "dims": [
        7,
        8
      ]
    },
    {
      "id": "act14",
      "label": "Use statistics to answer a biological question",
      "dims": [
        7
      ]
    },
    {
      "id": "act15",
      "label": "Use maps or GIS to understand spatial patterns",
      "dims": [
        7
      ]
    },
    {
      "id": "act16",
      "label": "Design a research study",
      "dims": [
        8
      ]
    },
    {
      "id": "act17",
      "label": "Read scientific literature to understand what is already known",
      "dims": [
        8
      ]
    },
    {
      "id": "act18",
      "label": "Write reports, papers, or explanations of findings",
      "dims": [
        8
      ]
    },
    {
      "id": "act19",
      "label": "Present research or explain evidence to others",
      "dims": [
        8,
        9
      ]
    },
    {
      "id": "act20",
      "label": "Solve a conservation or management problem",
      "dims": [
        6
      ]
    },
    {
      "id": "act21",
      "label": "Work with regulations, permits, or environmental decisions",
      "dims": [
        7
      ]
    },
    {
      "id": "act22",
      "label": "Teach visitors, students, or the public",
      "dims": [
        9
      ]
    },
    {
      "id": "act23",
      "label": "Develop educational or conservation programs",
      "dims": [
        6,
        9
      ]
    }
  ],
  "relationships": [
    {
      "id": "rel0",
      "label": "Working repeatedly with the same individual animals",
      "dims": [
        0,
        2
      ]
    },
    {
      "id": "rel1",
      "label": "Working with many animals or species",
      "dims": [
        3
      ]
    },
    {
      "id": "rel2",
      "label": "Observing animals without necessarily handling them",
      "dims": [
        8
      ]
    },
    {
      "id": "rel3",
      "label": "Handling or caring for animals directly",
      "dims": [
        8
      ]
    },
    {
      "id": "rel4",
      "label": "Working with animals under human care in zoos, aquariums, sanctuaries, or shelters",
      "dims": [
        1,
        2
      ]
    },
    {
      "id": "rel5",
      "label": "Working with wildlife in natural environments",
      "dims": [
        3
      ]
    },
    {
      "id": "rel6",
      "label": "Working with animals temporarily during rehabilitation or release",
      "dims": [
        4
      ]
    },
    {
      "id": "rel7",
      "label": "Studying individual animals in detail",
      "dims": [
        0,
        8
      ]
    },
    {
      "id": "rel8",
      "label": "Studying populations rather than particular individuals",
      "dims": [
        6,
        8
      ]
    },
    {
      "id": "rel9",
      "label": "Studying habitats and ecosystems as part of understanding animals",
      "dims": [
        3,
        6,
        8
      ]
    },
    {
      "id": "rel10",
      "label": "Working with animal-related data even when animals are not physically present",
      "dims": [
        7,
        9
      ]
    }
  ],
  "scienceQuestions": [
    {
      "id": "sci0",
      "label": "Behavior",
      "help": "Why did the animal do that?",
      "dims": [
        0
      ]
    },
    {
      "id": "sci1",
      "label": "Learning",
      "help": "How did the animal learn that, and how might experience change the behavior?",
      "dims": [
        0
      ]
    },
    {
      "id": "sci2",
      "label": "Cognition",
      "help": "What does the animal perceive, remember, understand, or decide?",
      "dims": [
        0
      ]
    },
    {
      "id": "sci3",
      "label": "Welfare",
      "help": "How can we determine whether the animal is doing well, and what would improve its experience?",
      "dims": [
        1
      ]
    },
    {
      "id": "sci4",
      "label": "Physiology",
      "help": "What is happening inside the body that affects function or behavior?",
      "dims": [
        0,
        5
      ]
    },
    {
      "id": "sci5",
      "label": "Neuroscience",
      "help": "How does the nervous system produce the behavior?",
      "dims": [
        0,
        5
      ]
    },
    {
      "id": "sci6",
      "label": "Evolution",
      "help": "Why did this trait or behavior evolve?",
      "dims": [
        0,
        5
      ]
    },
    {
      "id": "sci7",
      "label": "Ecology",
      "help": "How does the environment affect the animal?",
      "dims": [
        8
      ]
    },
    {
      "id": "sci8",
      "label": "Behavioral ecology",
      "help": "How does behavior affect survival and reproduction under natural conditions?",
      "dims": [
        0
      ]
    },
    {
      "id": "sci9",
      "label": "Population biology",
      "help": "Why is this population growing, declining, moving, or changing?",
      "dims": [
        6
      ]
    },
    {
      "id": "sci10",
      "label": "Conservation",
      "help": "What evidence-based action would help this species or population persist?",
      "dims": [
        3,
        6,
        8
      ]
    },
    {
      "id": "sci11",
      "label": "Reintroduction",
      "help": "How can animals be returned successfully, and what predicts survival afterward?",
      "dims": [
        4
      ]
    },
    {
      "id": "sci12",
      "label": "Habitat / restoration",
      "help": "What environmental changes would improve ecological conditions?",
      "dims": [
        3,
        6
      ]
    },
    {
      "id": "sci13",
      "label": "Management",
      "help": "What should people actually do differently based on the science?",
      "dims": [
        8
      ]
    }
  ],
  "conditions": [
    {
      "id": "cond0",
      "label": "Indoor animal-care facility"
    },
    {
      "id": "cond1",
      "label": "Outdoor field work"
    },
    {
      "id": "cond2",
      "label": "Laboratory work"
    },
    {
      "id": "cond3",
      "label": "Office/computer-based analysis"
    },
    {
      "id": "cond4",
      "label": "A mixed field + office schedule"
    },
    {
      "id": "cond5",
      "label": "Physically active work for much of the day"
    },
    {
      "id": "cond6",
      "label": "Feeding, cleaning, and enclosure maintenance"
    },
    {
      "id": "cond7",
      "label": "Early mornings"
    },
    {
      "id": "cond8",
      "label": "Weekend or holiday rotations"
    },
    {
      "id": "cond9",
      "label": "Weather-dependent work"
    },
    {
      "id": "cond10",
      "label": "Working in mud, insects, heat, cold, or rain"
    },
    {
      "id": "cond11",
      "label": "Temporary field placements or seasonal work early in a career"
    },
    {
      "id": "cond12",
      "label": "Relocating for a strong early-career opportunity"
    },
    {
      "id": "cond13",
      "label": "Long periods of careful observation"
    },
    {
      "id": "cond14",
      "label": "Substantial data analysis"
    },
    {
      "id": "cond15",
      "label": "Substantial scientific writing"
    },
    {
      "id": "cond16",
      "label": "Public speaking or visitor interaction"
    },
    {
      "id": "cond17",
      "label": "Working closely in a team"
    },
    {
      "id": "cond18",
      "label": "Working independently for long stretches"
    },
    {
      "id": "cond19",
      "label": "Exposure to sick or injured animals"
    },
    {
      "id": "cond20",
      "label": "Difficult welfare decisions or euthanasia as part of professional animal care"
    },
    {
      "id": "cond21",
      "label": "Working with regulations, permits, budgets, or administrative requirements"
    }
  ],
  "prepPaths": [
    {
      "id": "prep0",
      "label": "B.S. → direct entry job",
      "help": "Examples: keeper, technician, environmental scientist, some wildlife or education roles."
    },
    {
      "id": "prep1",
      "label": "B.S. → internship/seasonal work → permanent job",
      "help": "Common in zoo, wildlife, field biology, rehabilitation, and some conservation work."
    },
    {
      "id": "prep2",
      "label": "B.S. → research technician or lab manager → graduate study",
      "help": "A common bridge for research-oriented careers."
    },
    {
      "id": "prep3",
      "label": "B.S. → funded research M.S. → scientist/specialist role",
      "help": "Common in wildlife, ecology, behavior, and conservation specialization."
    },
    {
      "id": "prep4",
      "label": "B.S. → funded Ph.D. → independent research scientist",
      "help": "Typical for many research-scientist and academic careers."
    },
    {
      "id": "prep5",
      "label": "B.S. → several years of animal-care experience → specialist/manager",
      "help": "Common for behavioral husbandry, zoo welfare, lead keeper, curator, and management paths."
    },
    {
      "id": "prep6",
      "label": "B.S. → geographically mobile early-career projects → more stable professional role",
      "help": "Common in wildlife field science, reintroduction, and project-based conservation work."
    }
  ],
  "unknownTests": [
    {
      "unknown": "Would fieldwork actually be enjoyable?",
      "test": "Try a wildlife survey, bird count, tracking project, conservation field program, or field-based summer course."
    },
    {
      "unknown": "Would routine animal care be satisfying?",
      "test": "Seek husbandry exposure where feeding, cleaning, observation, recordkeeping, and maintenance are part of the experience—not just visitor-facing animal contact."
    },
    {
      "unknown": "Would behavior research be interesting?",
      "test": "Conduct a small observational project: define a question, build an ethogram, collect data, analyze it, and write a conclusion."
    },
    {
      "unknown": "Would rehabilitation be a fit?",
      "test": "Observe or volunteer in a permitted rehabilitation setting and pay attention to care routines, medical realities, release criteria, and emotional demands."
    },
    {
      "unknown": "Would data analysis be satisfying?",
      "test": "Take a real behavioral or ecological dataset and answer a question with basic statistics or visualization."
    },
    {
      "unknown": "Would public education be energizing?",
      "test": "Lead a club presentation, outreach activity, or animal/conservation awareness project and notice whether teaching people is satisfying."
    },
    {
      "unknown": "Would a research career be worth graduate school?",
      "test": "Read a few real research papers, talk to a working scientist or graduate student, and notice whether the questions and process—not just the animals—are compelling."
    },
    {
      "unknown": "Would zoo work be appealing beyond the setting?",
      "test": "Ask keepers or animal-care staff about cleaning, schedules, recordkeeping, enrichment, training, teamwork, and career progression; seek an experience that includes routine care."
    }
  ],
  "dimLabels": [
    "Individual behavior / cognition",
    "Behavior, welfare & husbandry",
    "Zoo / managed-animal care",
    "Wildlife / field biology",
    "Rehab / release / reintroduction",
    "Broad animal biology / mechanisms",
    "Conservation / population / habitat",
    "Quantitative / spatial / environmental",
    "Research science",
    "Education / communication"
  ],
  "categorySummaries": {
    "Animal behavior, cognition, welfare & training": {
      "short": "Behavior, learning, cognition, welfare, enrichment, training and behavioral research.",
      "progression": "B.S. entry can begin in research support, training, shelter behavior or welfare coordination; independent behavior science commonly adds research graduate training."
    },
    "Zoos, aquariums, sanctuaries & managed wildlife": {
      "short": "Daily animal care, husbandry, welfare, enrichment, training, conservation breeding, collection management and institutional research.",
      "progression": "Internship/entry care → keeper or aquarist → specialized behavior/welfare or lead responsibilities → management, curator, research or conservation leadership."
    },
    "Wildlife, rehabilitation & conservation": {
      "short": "Wild animals, populations, habitat, field sampling, rehabilitation, release, telemetry, reintroduction, species recovery and management.",
      "progression": "Seasonal/field or rehabilitation experience → technician/wildlife biologist → species, habitat, reintroduction, movement or management specialization; graduate study often increases autonomy."
    },
    "Organismal biology & ecological science": {
      "short": "Whole-animal biology, physiology, evolution, natural history, behavior and ecological relationships.",
      "progression": "Technical or field research roles can start after a B.S.; specialist scientist identities often develop through M.S./Ph.D. research."
    },
    "Quantitative, environmental & agency careers": {
      "short": "Data, spatial analysis, environmental decisions, regulation, consulting, restoration, habitat assessment and agency science.",
      "progression": "B.S. entry into environmental, monitoring, GIS or agency roles → project specialist/consultant → quantitative or management specialization."
    },
    "Research, graduate school & academia": {
      "short": "Producing new knowledge through study design, data collection, analysis, writing, publication, teaching and scientific leadership.",
      "progression": "Research assistant/technician → funded graduate study or lab management → research scientist, PI or faculty roles."
    },
    "Education, outreach & science communication": {
      "short": "Teaching, interpretation, public engagement, program development, museum work and science communication.",
      "progression": "B.S. entry into education, naturalist or program roles; subject specialization and management can deepen with experience or graduate study."
    }
  },
  "supportLegend": {
    "S": "Strong/direct",
    "C": "Credible with planning",
    "G": "Graduate-oriented",
    "SG": "Strong + graduate progression",
    "N": "Weakly aligned",
    "C*": "Later-career credible"
  },
  "resources": {
    "guide": "resources/Animal_Behavior_Wildlife_Undergraduate_and_Career_Guide_Final.docx",
    "workbook": "resources/Animal_Interests_Careers_College_Exploration_Workbook.docx",
    "spreadsheet": "resources/animal_career_path_matrix_researched_valid.xlsx"
  },
  "programs": [
    {
      "code": "ME-WE",
      "title": "Wildlife Ecology → behavioral ecology emphasis",
      "school": "University of Maine",
      "overview": "Institutional profile. Maine’s public flagship offers a traditional residential university experience in Orono, with nearby Bangor and a strong outdoors/natural-resource culture. It is smaller than UMass and URI but still has the breadth, laboratories, faculty research, athletics, and academic infrastructure of a public research university. Academic environment. Current UMaine KPI reporting shows total Fall 2025 headcount of 10,644, 79% first-year retention, 47% four-year graduation, 59% six-year graduation, a roughly 15–16:1 student-to-faculty ratio, and high participation in research/internship experiences. The institutional completion figures are lower than UMass; they should be treated as a characteristic of the environment, not as a personal probability of completion. Research and experience ecosystem. For the target fields, UMaine’s distinctive strength is that wildlife, field ecology, organismal biology, and undergraduate research are not peripheral. The Wildlife Ecology program has unusually strong documented employment/graduate outcomes; Zoology provides the broader animal-science alternative.",
      "fundamental": "A professional wildlife-science education focused on animals as members of populations and ecosystems: how wildlife uses habitat, how populations change, how behavior affects conservation, and how those processes are measured in the field.",
      "scienceFoundation": [
        "General biology and vertebrate biology",
        "Ecology and evolution/genetics",
        "Ecological statistics",
        "GIS and spatial methods",
        "Wildlife population dynamics",
        "Wildlife–habitat relationships",
        "Scientific communication and field methods"
      ],
      "animalContent": [
        "Animal Behavior (available within concentration/elective planning)",
        "Mammalian and avian biology",
        "Behavioral ecology and animal personality",
        "Habitat selection and movement",
        "Population monitoring",
        "Conservation and policy",
        "Reintroduction/post-release monitoring relevance"
      ],
      "experience": "Highly field-oriented. The curriculum includes Field Ecology & Scientific Communication, an intensive Wildlife Field Survey experience, and a capstone involving habitat-use research and radio telemetry. Internships and faculty research are common parts of the program culture.",
      "research": "Faculty alignment includes Margaret “Maisie” Merz (animal behavior, personality, crows, small mammals, fish spatial behavior) and Joseph Zydlewski (migratory fish physiology, behavior, and ecology). UMaine also supports undergraduate research fellowships and faculty-led projects.",
      "progression": [
        "Year 1: biology, introductory wildlife coursework, early exposure to the Wildlife Society and faculty research; pursue summer wildlife/rehab/zoo or field experience.",
        "Year 2: vertebrate biology, ecology, ecological statistics, scientific communication, and intensive field survey; begin research or substantial field work.",
        "Year 3: build a behavior-oriented concentration using Animal Behavior and organismal/wildlife electives; add GIS and deeper faculty research.",
        "Year 4: population dynamics, wildlife–habitat relationships, capstone/honors research using telemetry or behavior/movement questions, and a presentation or thesis."
      ],
      "resume": "B.S. Wildlife Ecology; ecological statistics; GIS; intensive field survey; vertebrate and wildlife biology; Animal Behavior/behavioral ecology electives; faculty research or field internship; capstone with telemetry/habitat-use analysis; scientific writing/presentation.",
      "advantages": [
        "Excellent preparation for wildlife field science, behavioral ecology, reintroduction/release monitoring, habitat and agency work.",
        "Structured field training reduces the risk of graduating with only classroom science.",
        "Very strong documented program outcomes, including high rates of field experience, faculty research, and science-related placement."
      ],
      "tradeoffs": [
        "Captive-animal welfare, enrichment, learning, and training are not central to the curriculum and would need internships or outside experiences.",
        "The degree is more professionally wildlife-oriented than a broad zoology/biology degree.",
        "An individualized concentration can shape coursework but does not appear as a named concentration on the transcript/diploma."
      ],
      "bestWhen": "Especially compelling when wildlife behavior, field ecology, rehabilitation/release, reintroduction, movement, habitat use, or agency/conservation work becomes the dominant interest.",
      "sources": [
        "umaine.edu/wle/undergraduate-program",
        "umaine.edu/wle/undergraduate-program/wildlife-ecology-curriculum",
        "umaine.edu/wle/undergraduate-program/concentrations",
        "umaine.edu/wle/faculty-staff-directory/merz-margaret-maisie"
      ],
      "type": "Wildlife professional",
      "experienceTags": [
        "fieldwork",
        "research",
        "GIS",
        "telemetry",
        "wildlife"
      ],
      "scale": "Public research university",
      "dims": [
        2.0,
        0.7,
        0.6,
        3.0,
        2.6,
        2.1,
        3.0,
        3.0,
        2.6,
        1.8
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 1.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "ME-ZOO",
      "title": "Zoology B.S. + Ecology concentration",
      "school": "University of Maine",
      "overview": "Institutional profile. Maine’s public flagship offers a traditional residential university experience in Orono, with nearby Bangor and a strong outdoors/natural-resource culture. It is smaller than UMass and URI but still has the breadth, laboratories, faculty research, athletics, and academic infrastructure of a public research university. Academic environment. Current UMaine KPI reporting shows total Fall 2025 headcount of 10,644, 79% first-year retention, 47% four-year graduation, 59% six-year graduation, a roughly 15–16:1 student-to-faculty ratio, and high participation in research/internship experiences. The institutional completion figures are lower than UMass; they should be treated as a characteristic of the environment, not as a personal probability of completion. Research and experience ecosystem. For the target fields, UMaine’s distinctive strength is that wildlife, field ecology, organismal biology, and undergraduate research are not peripheral. The Wildlife Ecology program has unusually strong documented employment/graduate outcomes; Zoology provides the broader animal-science alternative.",
      "fundamental": "A broad and rigorous animal-biology degree that studies animals from cellular and physiological mechanisms through whole organisms, evolution, biodiversity, behavior, and ecological interactions.",
      "scienceFoundation": [
        "Two semesters of general chemistry",
        "Organic chemistry sequence",
        "Physics sequence",
        "Statistics and calculus",
        "Cellular/molecular biology and genetics",
        "Evolution, physiology, ecology, and organismal biology"
      ],
      "animalContent": [
        "Animal Behavior",
        "Mammalogy",
        "Avian Biology",
        "Neurobiology",
        "Endocrinology",
        "General Ecology and evolutionary biology",
        "Broad upper-level animal biology choice"
      ],
      "experience": "Less automatically vocational than Wildlife Ecology, but highly compatible with field courses, faculty research, independent study, wildlife or zoo internships, and an Ecology concentration. Direct animal contact depends more on choices made outside the core.",
      "research": "The School of Biology and Ecology explicitly encourages independent faculty research, especially for students considering graduate school. The degree’s breadth supports behavior, physiology, ecology, evolution, and organismal research.",
      "progression": [
        "Year 1: biology, chemistry, math, and foundational animal biology; explore research areas and organismal interests.",
        "Year 2: continue chemistry/physics and core biology; add ecology and early research.",
        "Year 3: Animal Behavior plus mammalogy/avian biology, physiology, neurobiology or endocrinology; deepen independent research and pursue an animal-focused summer experience.",
        "Year 4: advanced Ecology concentration coursework, independent research/honors thesis where possible, and a poster or presentation."
      ],
      "resume": "B.S. Zoology with Ecology concentration; substantial chemistry/physics/math; animal behavior and organismal electives; ecology; faculty research; optional thesis; wildlife/zoo/rehab internship selected to shape the applied direction.",
      "advantages": [
        "One of the broadest animal-centered scientific foundations in the shortlist.",
        "Excellent preparation for research-oriented graduate study while keeping wildlife, behavior, physiology, and organismal biology open.",
        "Strong option when “animals and science” is clear but wildlife management versus captive behavior is not yet settled."
      ],
      "tradeoffs": [
        "Career-building experiences are less automatic than in Wildlife Ecology, URI’s zoo certificate, or UNE Animal Behavior.",
        "Little built-in husbandry/welfare/training content; those skills require internships or selected outside coursework."
      ],
      "bestWhen": "Especially compelling for a student who wants to become a broadly trained animal scientist first and decide later whether the main problem is behavior, physiology, ecology, evolution, or wildlife.",
      "sources": [
        "sbe.umaine.edu/undergraduate/zoology",
        "sbe.umaine.edu/undergraduate/concentrations_and_minors"
      ],
      "type": "Broad animal biology",
      "experienceTags": [
        "research",
        "fieldwork",
        "wildlife"
      ],
      "scale": "Public research university",
      "dims": [
        2.5,
        1.0,
        1.0,
        2.4,
        1.8,
        3.0,
        2.3,
        2.3,
        3.0,
        1.6
      ],
      "competencies": [
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 2.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "strength": 2.6,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 2.2,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_neuro",
          "name": "Neuroscience & neuroethology",
          "category": "Biological mechanisms",
          "description": "Neural mechanisms of behavior.",
          "strength": 2.2,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "UMA-AS",
      "title": "Animal Science → Management/Behavior",
      "school": "UMass Amherst",
      "overview": "Institutional profile. Massachusetts’ flagship is the largest and broadest institutional platform in the shortlist. Amherst is a genuine college town embedded in the Five College region, combining a major residential university with access to Amherst College, Smith, Mount Holyoke and Hampshire coursework. Academic environment. For Fall 2025, UMass reported more than 23,000 undergraduates, an average class size of 35, 77% of classes below 40 students, 18:1 student-faculty ratio, 92% first-year retention, 75.4% four-year graduation and 83.4% six-year graduation. The science pathways are conventionally demanding, especially Biology, but the completion environment is strong. Research and experience ecosystem. The major advantage is scale: many laboratories, departments, courses, funded summer programs, honors research and external internships. The corresponding risk is execution: animal-specific identity, faculty relationships and specialized experience need to be built intentionally.",
      "fundamental": "A rigorous managed-animal science degree centered on anatomy, physiology, genetics, nutrition, reproduction, health, welfare, and animal management, with behavior and exotic/wildlife electives available around a domestic/agricultural core.",
      "scienceFoundation": [
        "General and organic chemistry",
        "Anatomy & physiology",
        "Cellular/molecular biology",
        "Genetics",
        "Microbiology and biochemistry",
        "Statistics",
        "Nutrition, reproduction, immunity and disease"
      ],
      "animalContent": [
        "Animal Care & Welfare",
        "Clinical Animal Behavior",
        "Service Dog Training",
        "Wildlife Reproduction",
        "Exotic-animal courses",
        "Animal Behavior/Movement and selected wildlife electives"
      ],
      "experience": "Strong hands-on animal-management infrastructure, but much of it is built around domestic livestock and equine systems. Behavior/welfare pathways are possible but require careful elective selection.",
      "research": "Animal science research is scientifically substantial and can support graduate work in physiology, welfare, reproduction, behavior, or related fields. The broader UMass research ecosystem remains a strength.",
      "progression": [
        "Year 1: animal-science and biological/chemical foundations with early management exposure.",
        "Year 2: anatomy/physiology, genetics, welfare, microbiology, statistics; identify behavior/welfare research.",
        "Year 3: nutrition/reproduction plus clinical behavior, service dog, wildlife/exotic or Biology behavior electives; pursue managed-animal internship.",
        "Year 4: advanced animal-science electives and research/internship project directed toward welfare or behavior."
      ],
      "resume": "B.S. Animal Science; anatomy/physiology, disease, nutrition, reproduction, welfare, genetics and biochemistry; managed-animal experience; selected behavior/training/exotic or wildlife coursework; research/internship.",
      "advantages": [
        "Strong biological and physiological preparation for managed-animal welfare, companion-animal behavior, service animals, and some zoo-care paths.",
        "Good access to UMass research and institutional resources."
      ],
      "tradeoffs": [
        "Substantial livestock/agricultural and domestic-animal framing is unavoidable.",
        "Less efficient for wildlife, ecology, and broad organismal biology given the established scope priorities.",
        "Other UMass tracks preserve more relevant options with fewer off-target requirements."
      ],
      "bestWhen": "Most compelling only if interests move strongly toward managed-animal welfare, companion animals, service animals, or physiology rather than wildlife/ecology.",
      "sources": [
        "www.umass.edu/veterinary-animal-sciences/animal-science-major",
        "www.umass.edu/veterinary-animal-sciences/animal-science-major/animal-management-concentration"
      ],
      "type": "Managed-animal science",
      "experienceTags": [
        "animal care",
        "research",
        "managed animals"
      ],
      "scale": "Large public research university",
      "dims": [
        2.1,
        2.4,
        2.0,
        1.0,
        0.7,
        3.0,
        1.0,
        1.7,
        2.5,
        1.5
      ],
      "competencies": [
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_nutrition",
          "name": "Animal nutrition",
          "category": "Applied animal care",
          "description": "Diet formulation, food systems, nutrition science, and feeding management.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "strength": 1.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "UMA-BIO",
      "title": "Biology B.S. → Behavior/Ecology",
      "school": "UMass Amherst",
      "overview": "Institutional profile. Massachusetts’ flagship is the largest and broadest institutional platform in the shortlist. Amherst is a genuine college town embedded in the Five College region, combining a major residential university with access to Amherst College, Smith, Mount Holyoke and Hampshire coursework. Academic environment. For Fall 2025, UMass reported more than 23,000 undergraduates, an average class size of 35, 77% of classes below 40 students, 18:1 student-faculty ratio, 92% first-year retention, 75.4% four-year graduation and 83.4% six-year graduation. The science pathways are conventionally demanding, especially Biology, but the completion environment is strong. Research and experience ecosystem. The major advantage is scale: many laboratories, departments, courses, funded summer programs, honors research and external internships. The corresponding risk is execution: animal-specific identity, faculty relationships and specialized experience need to be built intentionally.",
      "fundamental": "A broad biological-science pathway that can connect genes, cells, physiology, nervous systems, evolution, ecology, and environment to animal behavior. The animal specialization must be constructed deliberately within a very large research university.",
      "scienceFoundation": [
        "Introductory biology sequence",
        "General chemistry and organic chemistry",
        "Physics sequence",
        "Statistics and additional quantitative work",
        "Genetics/molecular biology, cell/development, physiology",
        "Evolution/biodiversity and ecology/behavior breadth"
      ],
      "animalContent": [
        "Animal Behavior with lab",
        "Animal Communication",
        "Field Ecology",
        "Mammalogy and Ornithology",
        "Animal Movement",
        "Neural Basis of Animal Behavior",
        "Primate Behavior; psychology options in cognition/learning"
      ],
      "experience": "The largest research and course ecosystem of the four schools. Animal experience is not automatic; it must be assembled through research, internships, Five College coursework, zoo/wildlife placements, or honors work.",
      "research": "Strong infrastructure: OURS research advising, PROPEL project matching, Biology Undergraduate Research Club, Lee Science Impact paid summer research, Commonwealth Honors College, and relevant faculty such as Jeffrey Podos (communication/bioacoustics/learning) and Duncan Irschick (behavioral ecology/movement).",
      "progression": [
        "Year 1: biology/chemistry; meet undergraduate-research advising early and identify behavior/ecology labs.",
        "Year 2: evolution/ecology, statistics and remaining science foundation; begin sustained research; pursue summer animal-focused field/zoo/research experience.",
        "Year 3: Animal Behavior, Animal Communication and organismal/movement electives; deepen lab responsibility; compete for paid summer research.",
        "Year 4: advanced behavior/ecology electives, honors thesis or substantial independent project, conference/poster work, and a complementary animal internship if possible."
      ],
      "resume": "B.S. Biology; broad chemistry/physics/biology foundation; Animal Behavior/Communication and organismal electives; 2–3 years of faculty research; honors thesis or independent project; zoo/wildlife/behavior internship; poster or conference presentation.",
      "advantages": [
        "Strongest overall institutional and scientific platform in the shortlist.",
        "Excellent preparation for competitive funded graduate study and broad biological pivots.",
        "Large course and research ecosystem plus Five College access can create unusually customized combinations."
      ],
      "tradeoffs": [
        "High execution burden: the desired animal-behavior identity does not happen automatically.",
        "Large scale means students must actively seek faculty, research, internships, and smaller communities.",
        "Less direct captive-animal/husbandry preparation than UNE or URI’s zoo certificate."
      ],
      "bestWhen": "Especially compelling when scientific breadth, research intensity, graduate-school preparation, and the ability to pivot across biological science are more important than having an animal-specific degree title.",
      "sources": [
        "catalog.umass.edu/undergradguide/2026-2027/Page26040.html",
        "www.umass.edu/biology/academics/undergraduate-program/courses-approved-major-electives",
        "www.umass.edu/biology/about/directory/jeffrey-podos",
        "www.umass.edu/studentsuccess/five-college-interchange-registration"
      ],
      "type": "Broad biological science",
      "experienceTags": [
        "research",
        "honors",
        "Five College"
      ],
      "scale": "Large public research university",
      "dims": [
        2.6,
        1.4,
        1.0,
        2.2,
        1.4,
        3.0,
        2.2,
        2.5,
        3.0,
        1.8
      ],
      "competencies": [
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "strength": 2.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 2.4,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "strength": 2.4,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_neuro",
          "name": "Neuroscience & neuroethology",
          "category": "Biological mechanisms",
          "description": "Neural mechanisms of behavior.",
          "strength": 2.3,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "strength": 2.3,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_cognition",
          "name": "Animal cognition",
          "category": "Behavior & welfare",
          "description": "Perception, memory, decision making, and problem solving.",
          "strength": 1.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "UMA-WEC",
      "title": "Wildlife Ecology & Conservation",
      "school": "UMass Amherst",
      "overview": "Institutional profile. Massachusetts’ flagship is the largest and broadest institutional platform in the shortlist. Amherst is a genuine college town embedded in the Five College region, combining a major residential university with access to Amherst College, Smith, Mount Holyoke and Hampshire coursework. Academic environment. For Fall 2025, UMass reported more than 23,000 undergraduates, an average class size of 35, 77% of classes below 40 students, 18:1 student-faculty ratio, 92% first-year retention, 75.4% four-year graduation and 83.4% six-year graduation. The science pathways are conventionally demanding, especially Biology, but the completion environment is strong. Research and experience ecosystem. The major advantage is scale: many laboratories, departments, courses, funded summer programs, honors research and external internships. The corresponding risk is execution: animal-specific identity, faculty relationships and specialized experience need to be built intentionally.",
      "fundamental": "A professional wildlife and conservation track emphasizing field sampling, populations, habitats, quantitative ecology, GIS, management, and the interaction between wildlife and landscapes.",
      "scienceFoundation": [
        "Ecology and wildlife biology",
        "Quantitative ecology",
        "GIS",
        "Wildlife sampling and identification",
        "Population dynamics",
        "Habitat management and conservation",
        "Natural-resource policy"
      ],
      "animalContent": [
        "Behavioral Ecology & Conservation",
        "Vertebrate Ecology",
        "Ecophysiology",
        "Wildlife Ecology & Management",
        "Conservation Genetics",
        "Landscape Ecology"
      ],
      "experience": "More structured for field/wildlife work than UMass Biology. The concentration is designed for professional wildlife preparation and can be configured toward The Wildlife Society educational requirements.",
      "research": "The Environmental Conservation department posts undergraduate research opportunities, including paid and credit-bearing work. The large university also provides access to broader research infrastructure.",
      "progression": [
        "Year 1: biology/ecology and natural-resource foundations; join wildlife/conservation organizations and identify field opportunities.",
        "Year 2: quantitative ecology, identification/sampling and GIS; begin field or faculty research.",
        "Year 3: population/habitat/vertebrate ecology and behavioral-conservation electives; pursue substantial summer field work.",
        "Year 4: advanced wildlife management, research/capstone work, and agency/consulting/conservation internship preparation."
      ],
      "resume": "B.S. Natural Resources Conservation — Wildlife Ecology & Conservation; field sampling; quantitative ecology; GIS; wildlife population/habitat coursework; behavioral ecology elective work; field internship/research; professional wildlife credentials potentially supported.",
      "advantages": [
        "Direct professional preparation for wildlife, habitat, field, agency, and conservation careers.",
        "Built-in GIS and quantitative ecology improve employability and portability.",
        "Combines UMass institutional strength with a more structured wildlife identity."
      ],
      "tradeoffs": [
        "Less broad molecular/chemical/physics foundation than UMass Biology.",
        "Very little captive-animal welfare, cognition, enrichment, or husbandry unless added separately."
      ],
      "bestWhen": "Especially compelling if the intended direction becomes wildlife biology, field ecology, habitat/population work, environmental consulting, or agency conservation.",
      "sources": [
        "www.umass.edu/environmental-conservation/academics/undergraduate-programs/natural-resources-conservation/major/wildlife-ecology-conservation-concentration",
        "www.umass.edu/environmental-conservation/current-students/undergraduate-student-resources/undergraduate-research-opportunities"
      ],
      "type": "Wildlife professional",
      "experienceTags": [
        "fieldwork",
        "research",
        "GIS",
        "wildlife"
      ],
      "scale": "Large public research university",
      "dims": [
        1.8,
        0.5,
        0.5,
        3.0,
        2.3,
        1.7,
        3.0,
        3.0,
        2.5,
        1.8
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "strength": 2.4,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "UNE-AB",
      "title": "Animal Behavior B.S.",
      "school": "University of New England",
      "overview": "Institutional profile. UNE is the smallest and most specialized environment in the shortlist. The Animal Behavior program is based on the coastal Biddeford campus in southern Maine, with relatively small classes and close faculty contact. The location offers coastal access and proximity to the Portland/southern Maine region, while the campus itself is quieter than a large college town. Academic environment. UNE reports a roughly 12:1 student-teacher ratio and average class size around 18. Recent first-year retention has generally been in the upper 70% range; cohort four-year graduation has varied roughly from the mid-50s to mid-60s, with six-year rates in the low-60s to around 70%. The program is not academically light: it combines biology, chemistry, statistics, research methods, labs, reading/writing and behavioral research. Research and experience ecosystem. The major strength is low execution risk for an animal-behavior identity. Behavior, cognition, learning, communication, welfare/captive-management options, research and internships are central rather than something that must be assembled from several departments.",
      "fundamental": "The most behavior-centered degree in the shortlist: why animals behave as they do, how behavior is observed and measured, how animals learn and think, how communication works, and how behavioral science can improve welfare and conservation.",
      "scienceFoundation": [
        "Ecology/evolution biology with lab",
        "Cellular/molecular biology with lab",
        "Two chemistry semesters with labs",
        "Animal physiology",
        "Statistics",
        "Research methods and behavioral measurement"
      ],
      "animalContent": [
        "Introductory animal-behavior techniques and sampling",
        "Comparative Animal Behavior",
        "Animal Cognition",
        "Animal Learning & Behavior with lab",
        "Animal Communication",
        "Captive Animal Management",
        "Conservation Behavior",
        "Foraging Behavior and capstone research"
      ],
      "experience": "Animal behavior is not an elective afterthought; observation, methods, research, internship work and animal-focused coursework are built around the major. Internships have included wildlife centers, service-dog organizations, aquariums, zoos and federal wildlife organizations.",
      "research": "At least one research project is expected, with faculty labs and SURE summer funding. Relevant faculty areas include abnormal behavior/welfare, behavioral ecology/conservation, and comparative social/maternal behavior.",
      "progression": [
        "Year 1: biology/chemistry foundations and introductory behavior methods; identify faculty labs.",
        "Year 2: statistics, research methods and comparative behavior; join research and pursue summer experience.",
        "Year 3: cognition, learning with lab, biological bases, captive management/conservation behavior and organismal electives; substantial zoo/shelter/rehab/service-dog internship.",
        "Year 4: capstone plus research/internship, independent project, poster/presentation and potentially manuscript-level work."
      ],
      "resume": "B.S. Animal Behavior; biology/chemistry/physiology foundation; behavior sampling and research methods; cognition, learning, communication, welfare/captive-management electives; faculty research; internship; capstone/independent project; presentation.",
      "advantages": [
        "Strongest direct curriculum for individual-animal behavior, learning, cognition, communication, welfare, enrichment and behavioral husbandry.",
        "Small classes and direct faculty access reduce execution risk.",
        "Clear academic identity for animal-behavior graduate programs and applied behavior roles."
      ],
      "tradeoffs": [
        "Less built-in GIS, population ecology, habitat management and environmental consulting preparation than dedicated wildlife degrees.",
        "The institutional platform is narrower than a public flagship, with fewer unrelated majors and large-scale research ecosystems.",
        "Some wildlife/environmental directions require deliberate supplementation outside the core major."
      ],
      "bestWhen": "Especially compelling when the central question is the behavior of individual animals—learning, cognition, communication, welfare, enrichment, training or applied ethology.",
      "sources": [
        "www.une.edu/catalog/2025-2026/undergraduate/animal-behavior",
        "www.une.edu/cas/schools/social-behavioral-sciences/programs/bs-animal-behavior"
      ],
      "type": "Animal behavior specialist",
      "experienceTags": [
        "animal behavior",
        "animal care",
        "research",
        "internship",
        "welfare"
      ],
      "scale": "Smaller private university",
      "dims": [
        3.0,
        3.0,
        2.5,
        2.0,
        2.0,
        2.1,
        1.7,
        1.5,
        2.7,
        1.7
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_cognition",
          "name": "Animal cognition",
          "category": "Behavior & welfare",
          "description": "Perception, memory, decision making, and problem solving.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_enrichment",
          "name": "Enrichment",
          "category": "Applied animal care",
          "description": "Designing and evaluating enrichment that supports species-appropriate behavior.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 2.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 2.4,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "strength": 1.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "UNE-AN",
      "title": "Animal Behavior B.S. + selected neuroscience",
      "school": "University of New England",
      "overview": "Institutional profile. UNE is the smallest and most specialized environment in the shortlist. The Animal Behavior program is based on the coastal Biddeford campus in southern Maine, with relatively small classes and close faculty contact. The location offers coastal access and proximity to the Portland/southern Maine region, while the campus itself is quieter than a large college town. Academic environment. UNE reports a roughly 12:1 student-teacher ratio and average class size around 18. Recent first-year retention has generally been in the upper 70% range; cohort four-year graduation has varied roughly from the mid-50s to mid-60s, with six-year rates in the low-60s to around 70%. The program is not academically light: it combines biology, chemistry, statistics, research methods, labs, reading/writing and behavioral research. Research and experience ecosystem. The major strength is low execution risk for an animal-behavior identity. Behavior, cognition, learning, communication, welfare/captive-management options, research and internships are central rather than something that must be assembled from several departments.",
      "fundamental": "The Animal Behavior degree with added mechanistic depth in neural systems and cognition, without automatically committing to the full neuroscience minor.",
      "scienceFoundation": [
        "All Animal Behavior science foundations",
        "Introduction to Neurobiology with lab",
        "Behavioral/Cognitive Neuroscience with lab",
        "Potential additional neurobiology or neuroanatomy depending space"
      ],
      "animalContent": [
        "Animal cognition and learning",
        "Neural mechanisms of behavior",
        "Comparative behavior",
        "Behavioral research methods",
        "Welfare/captive management as in the Animal Behavior major"
      ],
      "experience": "Animal experience and behavior research remain anchored in the Animal Behavior major. Neuroscience coursework adds scientific depth rather than replacing internships or animal-focused electives.",
      "research": "Best suited to questions connecting behavior, cognition and nervous-system mechanisms. The full neuroscience minor is 22 credits and may create excessive overlap/opportunity cost, so selected courses are currently the preferred strategy.",
      "progression": [
        "Years 1–2: follow the Animal Behavior foundation and research sequence while completing prerequisites for neuroscience.",
        "Year 3: add neurobiology and/or behavioral-cognitive neuroscience alongside cognition, learning and behavior electives.",
        "Year 4: capstone/independent research that can integrate behavioral and mechanistic questions; preserve internship and presentation opportunities."
      ],
      "resume": "B.S. Animal Behavior; selected neurobiology/neuroscience labs; cognition/learning/behavior research; animal-focused internship; capstone or independent project connecting behavior with underlying mechanisms.",
      "advantages": [
        "Adds mechanistic depth for cognition, neuroethology and research graduate pathways.",
        "Preserves the strong behavior identity of UNE rather than reversing the major/minor emphasis."
      ],
      "tradeoffs": [
        "Does not materially expand B.S.-level career coverage; its value is intellectual and research-oriented.",
        "A full 22-credit neuroscience minor may consume flexibility better used for research, internships or organismal electives."
      ],
      "bestWhen": "Especially compelling if interest shifts from “what does the animal do?” toward “how do brain and biological mechanisms produce the behavior?” while retaining applied animal-behavior interests.",
      "sources": [
        "www.une.edu/catalog/2025-2026/undergraduate/animal-behavior",
        "www.une.edu/catalog/2025-2026/undergraduate/neuroscience-minor",
        "www.une.edu/catalog/2025-2026/undergraduate/neuroscience"
      ],
      "type": "Behavior + neuroscience",
      "experienceTags": [
        "animal behavior",
        "research",
        "neuroscience",
        "internship"
      ],
      "scale": "Smaller private university",
      "dims": [
        3.0,
        2.6,
        2.2,
        1.7,
        1.6,
        3.0,
        1.5,
        1.6,
        3.0,
        1.6
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_cognition",
          "name": "Animal cognition",
          "category": "Behavior & welfare",
          "description": "Perception, memory, decision making, and problem solving.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_neuro",
          "name": "Neuroscience & neuroethology",
          "category": "Biological mechanisms",
          "description": "Neural mechanisms of behavior.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_enrichment",
          "name": "Enrichment",
          "category": "Applied animal care",
          "description": "Designing and evaluating enrichment that supports species-appropriate behavior.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 2.4,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "strength": 2.2,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "URI-AZ",
      "title": "Animal Science + Zoo & Aquarium Science certificate",
      "school": "University of Rhode Island",
      "overview": "Institutional profile. URI is a New England flagship with a classic residential campus in Kingston and access to South County, Narragansett, Newport and Providence. Its scale is large enough for broad university resources but smaller and more concentrated than UMass. Academic environment. URI’s recent institutional reporting places first-year retention in the mid-80% range and completion around the high-50s for four years and roughly 70% by six years. Many classes are relatively small for a public university. The academic environment is serious STEM with laboratories, field methods, experiential learning and undergraduate research. Research and experience ecosystem. URI has become the most interesting school for within-institution flexibility between wildlife/conservation and animals under human care. The Zoo & Aquarium Science certificate, Roger Williams Park Zoo course connection, formal wildlife experiential sequence and funded undergraduate research provide unusually visible pathways.",
      "fundamental": "A managed-animal science route built around physiology, health, behavior, nutrition, reproduction, care and management, then specialized toward evidence-based zoo/aquarium welfare, husbandry, training, and research.",
      "scienceFoundation": [
        "Animal anatomy & physiology",
        "Animal disease",
        "Nutrition",
        "Reproductive physiology",
        "Statistics",
        "Animal management",
        "Research methods and animal care"
      ],
      "animalContent": [
        "Behavior of Managed Animals",
        "Zoo Animal Management at Roger Williams Park Zoo",
        "Zoo & Aquarium Animal Welfare",
        "Advanced Methods in Applied Animal Behavior",
        "Exotic Pet Management",
        "Marine mammal courses",
        "Zoo/aquarium internship practicum"
      ],
      "experience": "The zoo certificate fits naturally because AVS 343 (Behavior of Managed Animals) is already part of the Animal Science route. The combination is highly structured for animals under human care and includes required internship/special-project experience.",
      "research": "Faculty alignment includes Justin Richard, whose work spans animal behavior and reproductive physiology in zoos and the wild and who involves undergraduates in zoo/aquarium research. URI also provides institutional undergraduate-research funding.",
      "progression": [
        "Year 1: animal-science, biology and chemistry foundations.",
        "Year 2: anatomy/physiology, disease, management and statistics; begin research or zoo involvement.",
        "Year 3: managed-animal behavior, zoo management at Roger Williams Park Zoo, exotic/marine/behavior electives, internship preparation.",
        "Year 4: zoo welfare, advanced applied animal behavior/training, zoo/aquarium practicum, research/special project."
      ],
      "resume": "B.S. Animal Science + Zoo & Aquarium Science certificate; anatomy/physiology, disease, nutrition, reproduction, managed-animal behavior, zoo management, welfare assessment, science-based training, internship/practicum, and research/special project.",
      "advantages": [
        "Perhaps the most direct managed-animal/zoo welfare and behavioral-husbandry preparation in the four-school set.",
        "Combines serious physiology/health science with behavior, welfare and training rather than treating care as purely vocational.",
        "Certificate integration is structurally easier than in URI Wildlife."
      ],
      "tradeoffs": [
        "Wildlife ecology, GIS, field population work, reintroduction, and habitat science are less central.",
        "Animal Science retains domestic/livestock content and an organizing framework that is broader than zoo/welfare alone."
      ],
      "bestWhen": "Especially compelling if interests settle on animals under human care: zoo/aquarium husbandry, welfare, enrichment, training, managed-animal research, or conservation breeding.",
      "sources": [
        "web.uri.edu/favs/academics/animal-and-veterinary-science-b-s/animal-science-option",
        "web.uri.edu/favs/academics/zoo-and-aquarium-science-certificate",
        "web.uri.edu/favs/meet/justin-richard"
      ],
      "type": "Zoo / managed-animal science",
      "experienceTags": [
        "zoo",
        "animal care",
        "animal welfare",
        "training",
        "research",
        "internship"
      ],
      "scale": "Public research university",
      "dims": [
        2.8,
        3.0,
        3.0,
        1.4,
        1.1,
        2.7,
        1.5,
        1.7,
        2.5,
        2.0
      ],
      "competencies": [
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_nutrition",
          "name": "Animal nutrition",
          "category": "Applied animal care",
          "description": "Diet formulation, food systems, nutrition science, and feeding management.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_records",
          "name": "Animal records & databases",
          "category": "Professional",
          "description": "ZIMS/records systems, inventories, permits, transactions, and data stewardship.",
          "strength": 1.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "URI-W",
      "title": "Wildlife & Conservation Biology",
      "school": "University of Rhode Island",
      "overview": "Institutional profile. URI is a New England flagship with a classic residential campus in Kingston and access to South County, Narragansett, Newport and Providence. Its scale is large enough for broad university resources but smaller and more concentrated than UMass. Academic environment. URI’s recent institutional reporting places first-year retention in the mid-80% range and completion around the high-50s for four years and roughly 70% by six years. Many classes are relatively small for a public university. The academic environment is serious STEM with laboratories, field methods, experiential learning and undergraduate research. Research and experience ecosystem. URI has become the most interesting school for within-institution flexibility between wildlife/conservation and animals under human care. The Zoo & Aquarium Science certificate, Roger Williams Park Zoo course connection, formal wildlife experiential sequence and funded undergraduate research provide unusually visible pathways.",
      "fundamental": "A wildlife and conservation degree combining ecology, organismal biology, field methods, quantitative analysis, and a formal sequence of experiential learning.",
      "scienceFoundation": [
        "Biology and chemistry",
        "Calculus and statistics",
        "Ecology",
        "Wildlife management",
        "Wildlife field techniques",
        "Field botany",
        "Quantitative wildlife methods"
      ],
      "animalContent": [
        "Animal Behavior",
        "Mammalogy",
        "Field Ornithology",
        "Vertebrate Biology",
        "Herpetology",
        "Wildlife Biometrics",
        "Population/habitat conservation"
      ],
      "experience": "URI embeds experiential planning across the undergraduate years: early portfolio/planning, research apprenticeship or internship, and advanced research/co-op/thesis options. Up to 12 experiential-learning credits can apply within the program.",
      "research": "Relevant faculty and projects include migratory songbird behavior/physiology, waterbird ecology, amphibians, and wildlife-landscape interactions. URI supports paid summer undergraduate research through URISE and other fellowships.",
      "progression": [
        "Year 1: biology/chemistry and wildlife foundations; begin experiential portfolio and identify research interests.",
        "Year 2: ecology/statistics plus research apprenticeship or internship planning; pursue summer field/research work.",
        "Year 3: Animal Behavior, Mammalogy, Field Ornithology/Vertebrate Biology, Wildlife Ecology and Field Techniques.",
        "Year 4: advanced quantitative/endangered-species work, thesis/co-op/internship, and presentation."
      ],
      "resume": "B.S. Wildlife & Conservation Biology; chemistry/biology foundation; ecology; field techniques; statistics; Animal Behavior plus organismal electives; structured internship/research; possible thesis/co-op; strong wildlife/conservation identity.",
      "advantages": [
        "Strong middle ground between Maine’s field-heavy wildlife program and broader Biology/Zoology degrees.",
        "Experiential structure reduces execution risk.",
        "Regional flagship setting and zoo/aquarium partnerships create useful nearby options."
      ],
      "tradeoffs": [
        "Still conservation-heavy; direct captive welfare, husbandry, and training are limited without the zoo certificate.",
        "Less broad molecular/physiological science than a Biology or Zoology B.S."
      ],
      "bestWhen": "Especially compelling for wildlife/conservation careers when a structured experiential program and New England flagship environment are priorities.",
      "sources": [
        "web.uri.edu/nrs/academics/wildlife-and-conservation-biology/curriculum",
        "web.uri.edu/nrs/research/wildlife-and-conservation-biology",
        "web.uri.edu/undergraduate-research/programs-and-funding"
      ],
      "type": "Wildlife professional",
      "experienceTags": [
        "fieldwork",
        "research",
        "internship",
        "wildlife"
      ],
      "scale": "Public research university",
      "dims": [
        2.0,
        0.8,
        1.0,
        3.0,
        2.4,
        2.0,
        3.0,
        2.5,
        2.6,
        1.9
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "strength": 2.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "strength": 2.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "strength": 2.3,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    },
    {
      "code": "URI-WZ",
      "title": "Wildlife & Conservation Biology + Zoo & Aquarium Science certificate",
      "school": "University of Rhode Island",
      "overview": "Institutional profile. URI is a New England flagship with a classic residential campus in Kingston and access to South County, Narragansett, Newport and Providence. Its scale is large enough for broad university resources but smaller and more concentrated than UMass. Academic environment. URI’s recent institutional reporting places first-year retention in the mid-80% range and completion around the high-50s for four years and roughly 70% by six years. Many classes are relatively small for a public university. The academic environment is serious STEM with laboratories, field methods, experiential learning and undergraduate research. Research and experience ecosystem. URI has become the most interesting school for within-institution flexibility between wildlife/conservation and animals under human care. The Zoo & Aquarium Science certificate, Roger Williams Park Zoo course connection, formal wildlife experiential sequence and funded undergraduate research provide unusually visible pathways.",
      "fundamental": "A deliberately hybrid route: retain field wildlife, ecology, conservation, statistics, and organismal biology while adding zoo management, managed-animal behavior, welfare science, applied training, and an internship-linked practicum.",
      "scienceFoundation": [
        "Wildlife & Conservation Biology science core",
        "Ecology and quantitative wildlife analysis",
        "Field techniques and organismal biology",
        "Zoo/managed-animal behavior methods",
        "Welfare assessment",
        "Applied training methods"
      ],
      "animalContent": [
        "Zoo Animal Management at Roger Williams Park Zoo",
        "Behavior of Managed Animals",
        "Zoo & Aquarium Animal Welfare",
        "Advanced Methods in Applied Animal Behavior",
        "Zoo/Aquarium practicum and internship",
        "Animal Behavior, mammalogy/ornithology and conservation biology"
      ],
      "experience": "The broadest cross-over between wild and managed animals in the shortlist. The certificate is open to all URI undergraduates and includes a practicum tied to real zoo/aquarium internship experience. Zoo Animal Management is taught at Roger Williams Park Zoo.",
      "research": "Combines URI wildlife research opportunities with zoo/aquarium behavior and welfare possibilities. Recent URI examples include penguin social behavior and conservation-breeding work with regional zoo/aquarium partners.",
      "progression": [
        "Year 1: wildlife/biology foundations and experiential planning; identify zoo/wildlife research interests.",
        "Year 2: ecology/statistics plus early research; determine certificate prerequisites and internship timeline.",
        "Year 3: Animal Behavior and wildlife field courses plus Zoo Animal Management/managed-animal behavior sequence where scheduling permits.",
        "Year 4: zoo welfare/applied behavior, practicum/internship, and thesis/co-op/research integrating wildlife or managed-animal questions."
      ],
      "resume": "B.S. Wildlife & Conservation Biology + Zoo & Aquarium Science certificate; wildlife field methods; statistics; Animal Behavior; zoo management at Roger Williams Park Zoo; managed-animal behavior/welfare; applied training; zoo/aquarium internship; research/thesis or co-op potential.",
      "advantages": [
        "Unusually broad coverage of wildlife, conservation, zoo care, welfare, training, and research.",
        "Allows uncertainty between wildlife and zoo/managed-animal directions to persist longer without changing institutions.",
        "Roger Williams Park Zoo connection is concrete rather than merely a generic internship list."
      ],
      "tradeoffs": [
        "Certificate integration is not completely frictionless: AVS 343 has an Anatomy & Physiology prerequisite or instructor-permission issue for non-Animal-Science majors.",
        "Exact double-counting and four-year sequencing need confirmation with URI advising.",
        "Breadth may reduce depth relative to a more single-purpose program."
      ],
      "bestWhen": "Especially compelling when interests span both wildlife/conservation and zoo/animal-care/welfare work, or when that distinction is intentionally being left open.",
      "sources": [
        "web.uri.edu/nrs/academics/wildlife-and-conservation-biology/curriculum",
        "web.uri.edu/favs/academics/zoo-and-aquarium-science-certificate",
        "web.uri.edu/favs/academics/course-descriptions"
      ],
      "type": "Wildlife + zoo hybrid",
      "experienceTags": [
        "fieldwork",
        "research",
        "internship",
        "zoo",
        "animal welfare",
        "training"
      ],
      "scale": "Public research university",
      "dims": [
        2.7,
        2.6,
        3.0,
        3.0,
        2.8,
        2.2,
        3.0,
        2.4,
        2.8,
        2.0
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "strength": 3.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "strength": 2.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "strength": 2.8,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "strength": 2.7,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "strength": 2.5,
          "evidenceNote": "Curated from current program curriculum/profile research."
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "strength": 2.0,
          "evidenceNote": "Curated from current program curriculum/profile research."
        }
      ],
      "lastVerified": "2026-09-08"
    }
  ],
  "careers": [
    {
      "id": "cr_0079",
      "name": "Ambassador animal specialist / animal programs keeper",
      "slug": "ambassador-animal-specialist-animal-programs-keeper",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_zoo_training",
        "name": "Zoo training & ambassador animal programs",
        "description": "Animal training and ambassador-animal care/education within zoological settings."
      },
      "roleKind": "career",
      "marketStatus": "Verified current market titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Cares for and trains animals used in public programs, while combining husbandry, behavior, welfare, presentation, and conservation education.",
      "details": {
        "Typical work settings": "Zoo/aquarium ambassador-animal departments, conservation education programs, outreach animal programs.",
        "Undergraduate preparation most useful": "Husbandry, training, animal behavior, welfare, public speaking, conservation education.",
        "Searchable job titles": "Animal Ambassador Lead; Ambassador Animal Keeper; Zoological Care Specialist - Ambassador Animals; Animal Programs Keeper",
        "Alternate names / terms": "Animal ambassador team; education keeper; presentation animals",
        "Typical education / progression": "B.S. plus direct animal-care/training experience is common; advancement can include lead, supervisor, training, behavioral husbandry, or education leadership.",
        "Job outlook": "No dedicated federal occupation; validate through zoo/aquarium postings.",
        "Salary context": "Use employer postings and related keeper/trainer benchmarks.",
        "Market status": "Verified current market titles",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "C",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        2.1,
        2.5,
        3.0,
        0.6,
        0.2,
        1.0,
        1.1,
        0.3,
        0.9,
        2.8
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Education / public"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Animal ambassador team",
        "education keeper",
        "presentation animals",
        "Ambassador Animal Keeper",
        "Animal Ambassador Lead",
        "Animal Programs Keeper",
        "Zoological Care Specialist - Ambassador Animals"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0003",
          "career_id": "cr_0079",
          "title": "Animal Ambassador Lead",
          "organization": "Virginia Zoo Society",
          "location": "Norfolk, VA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0003",
          "career_id": "cr_0079",
          "title": "Animal Ambassador Lead",
          "employer": "Virginia Zoo Society",
          "location": "Norfolk, VA",
          "posted_date": "2026-09-08",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0001",
      "name": "Animal behavior research assistant / technician",
      "slug": "animal-behavior-research-assistant-technician",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_behavior_research",
        "name": "Behavioral research & cognition",
        "description": "Research on behavior, cognition, learning, communication, and comparative psychology."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Supports laboratory or field studies of animal behavior by observing animals, coding behavior, maintaining research records, helping run experiments, and preparing data for analysis.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Research Assistant; Research Technician; Lab Technician; Research Associate",
        "Alternate names / terms": "Behavioral Research Assistant; Animal Behavior Technician",
        "Typical education / progression": "B.S. commonly sufficient for entry research roles",
        "O*NET / BLS proxy": "Biological Technicians (19-4021.00)",
        "Job outlook": "3%–4% (Average); ~9,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $40,330–$48,130; mid proxy $57,510–$71,520",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-BIO, UMA-AS, ME-ZOO, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-WEC, ME-WE, URI-W",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "S",
        "UMA-AS": "S",
        "UMA-BIO": "S",
        "UMA-WEC": "C",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "Strong B.S.-level research entry point",
      "dims": [
        3.0,
        2.9,
        2.0,
        1.2,
        0.5,
        2.0,
        0.5,
        1.5,
        2.9,
        1.1
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        40330,
        48130
      ],
      "midSalary": [
        57510,
        71520
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Animal Behavior Technician",
        "Behavioral Research Assistant",
        "Lab Technician",
        "Research Assistant",
        "Research Associate",
        "Research Technician"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0022",
          "career_id": "cr_0001",
          "title": "Animal Behavioral Research Assistant",
          "organization": "Brookfield Zoo Chicago",
          "location": "Brookfield, IL",
          "observation_type": "job_posting",
          "observed_date": "2026-06-04",
          "source_id": "src_aza_jobs",
          "notes": "Observed AZA research title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0022",
          "career_id": "cr_0001",
          "title": "Animal Behavioral Research Assistant",
          "employer": "Brookfield Zoo Chicago",
          "location": "Brookfield, IL",
          "posted_date": "2026-06-04",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/jobs?locale=en",
          "active_status": "current_or_recent",
          "notes": "Observed AZA research title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0002",
      "name": "Animal behaviorist / applied animal behavior scientist",
      "slug": "animal-behaviorist-applied-animal-behavior-scientist",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_applied_behavior",
        "name": "Applied behavior & training",
        "description": "Science-based training, behavior modification, service-animal work, and applied behavior."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses behavioral science to understand, assess, and modify animal behavior in settings such as shelters, zoos, companion-animal programs, research institutions, or welfare organizations.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Applied Animal Behaviorist; Animal Behavior Scientist; Behavior Scientist; Research Scientist",
        "Alternate names / terms": "Behaviorist; Applied Animal Behaviorist; Ethologist",
        "Typical education / progression": "Independent scientist/behaviorist commonly M.S./Ph.D.; applied roles vary",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-WEC, ME-WE, URI-W",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-AS, ME-ZOO, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "C",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "C",
        "URI-WZ": "G"
      },
      "notes": "Professional independent work commonly requires graduate training",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.0,
        2.9,
        1.1
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Applied Animal Behaviorist",
        "Behaviorist",
        "Ethologist",
        "Animal Behavior Scientist",
        "Applied Animal Behaviorist",
        "Behavior Scientist",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [
        {
          "evidence_id": "ev_0007",
          "entity_type": "career",
          "entity_id": "cr_0002",
          "claim_type": "credential",
          "claim_value": "ACAAB requires research-based master’s preparation in biological/behavioral science with animal-behavior emphasis; CAAB is a higher doctoral-level certification route.",
          "source_id": "src_abs_caab",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_abs_caab",
            "organization": "Animal Behavior Society",
            "source_type": "credential_standard",
            "title": "CAAB / ACAAB Certification Requirements",
            "url": "https://www.animalbehaviorsociety.org/web/committees-applied-behavior-caab.php",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Research-based graduate education and experience requirements for applied-animal-behavior certification."
          }
        }
      ],
      "credentials": [
        {
          "relationship": "useful_or_role_defining",
          "notes": "Relevant for advanced professional applied-animal-behavior practice.",
          "credential_id": "cred_abs_acaab",
          "name": "Associate Certified Applied Animal Behaviorist (ACAAB)",
          "organization": "Animal Behavior Society",
          "credential_type": "professional certification",
          "description": "Requires a research-based master’s degree in a biological or behavioral science with animal-behavior emphasis plus experience and endorsement requirements.",
          "source_id": "src_abs_caab",
          "source_url": "https://www.animalbehaviorsociety.org/web/committees-applied-behavior-caab.php",
          "source_retrieved": "2026-09-08"
        },
        {
          "relationship": "useful_or_role_defining",
          "notes": "Advanced certification for doctoral-level applied behavior professionals.",
          "credential_id": "cred_abs_caab",
          "name": "Certified Applied Animal Behaviorist (CAAB)",
          "organization": "Animal Behavior Society",
          "credential_type": "professional certification",
          "description": "Advanced applied animal behavior certification generally requiring relevant doctoral-level preparation plus professional experience.",
          "source_id": "src_abs_caab",
          "source_url": "https://www.animalbehaviorsociety.org/web/committees-applied-behavior-caab.php",
          "source_retrieved": "2026-09-08"
        }
      ],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0022",
      "name": "Animal collection / management specialist",
      "slug": "animal-collection-management-specialist",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_zoo_science_leadership",
        "name": "Zoo research, conservation & leadership",
        "description": "Zoo/aquarium research, conservation coordination, collection leadership, and curation."
      },
      "roleKind": "later_career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Coordinates the operational management of an animal collection, including husbandry standards, staffing, records, transfers, welfare, breeding recommendations, and institutional procedures.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "Experience-driven later-career / management role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Animal Collection Manager; Animal Operations Manager; Curator; Registrar",
        "Alternate names / terms": "Live-Collection Manager; Animal Management Specialist",
        "Typical education / progression": "B.S. plus significant animal-management experience",
        "O*NET / BLS proxy": "Natural Sciences Managers (11-9121.00)",
        "Job outlook": "3%–4% (Average); ~8,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $79,710–$119,430; mid proxy $167,220–$221,540",
        "Proxy fit": "Low",
        "Strong/direct paths": "UNE-AB, UMA-AS, URI-WZ, URI-AZ",
        "Credible with planning": "UNE-AN",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "N",
        "UMA-AS": "S",
        "UMA-BIO": "N",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "C",
        "URI-AZ": "S",
        "URI-W": "N",
        "URI-WZ": "S"
      },
      "notes": "Captive-animal management focus",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        0.7,
        2.2,
        1.4
      ],
      "directContact": "High",
      "educationBand": "Experience-driven / later career",
      "careerStage": "leadership",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        79710,
        119430
      ],
      "midSalary": [
        167220,
        221540
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Animal Management Specialist",
        "Live-Collection Manager",
        "Animal Collection Manager",
        "Animal Operations Manager",
        "Curator",
        "Registrar"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0005",
      "name": "Animal communication researcher",
      "slug": "animal-communication-researcher",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_behavior_research",
        "name": "Behavioral research & cognition",
        "description": "Research on behavior, cognition, learning, communication, and comparative psychology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Investigates acoustic, visual, chemical, tactile, or multimodal signaling and how communication relates to learning, social behavior, ecology, and evolution.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Research Scientist; Postdoctoral Fellow; Professor",
        "Alternate names / terms": "Animal Communication Scientist; Bioacoustics Researcher; Behavioral Ecologist",
        "Typical education / progression": "B.S. for assistant roles; M.S./Ph.D. typical for scientist roles",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-WEC, ME-WE, URI-W, URI-WZ",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, ME-ZOO",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "C",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "N",
        "URI-W": "C",
        "URI-WZ": "C"
      },
      "notes": "Particularly natural at UNE/UMass Biology",
      "dims": [
        3.0,
        2.9,
        2.0,
        1.2,
        0.5,
        2.5,
        0.5,
        1.0,
        2.9,
        1.6
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "variable",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 87264,
        "observedMax": 98172,
        "medianLow": 87264,
        "medianHigh": 98172,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Animal Communication Scientist",
        "Behavioral Ecologist",
        "Bioacoustics Researcher",
        "Postdoctoral Fellow",
        "Professor",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0023",
          "career_id": "cr_0005",
          "title": "Post Doctoral Associate, Elephant Communication",
          "organization": "San Diego Zoo Wildlife Alliance",
          "location": "Escondido, CA",
          "observation_type": "job_posting",
          "observed_date": "2026-05-25",
          "source_id": "src_aza_elephantcomm",
          "notes": "Three-year postdoctoral research position.",
          "source": {
            "source_id": "src_aza_elephantcomm",
            "organization": "San Diego Zoo Wildlife Alliance / AZA",
            "source_type": "job_posting",
            "title": "Post Doctoral Associate, Elephant Communication",
            "url": "https://www.aza.org/jobs?job=51494",
            "published_date": "2026-05-25",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Advanced communication research posting with salary."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0023",
          "career_id": "cr_0005",
          "title": "Post Doctoral Associate, Elephant Communication",
          "employer": "San Diego Zoo Wildlife Alliance",
          "location": "Escondido, CA",
          "posted_date": "2026-05-25",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "Doctorate/postdoctorate",
          "experience_min": null,
          "salary_min": 87264.0,
          "salary_max": 98172.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_elephantcomm",
          "url": "https://www.aza.org/jobs?job=51494",
          "active_status": "current_or_recent",
          "notes": "Three-year postdoctoral research position.",
          "source": {
            "source_id": "src_aza_elephantcomm",
            "organization": "San Diego Zoo Wildlife Alliance / AZA",
            "source_type": "job_posting",
            "title": "Post Doctoral Associate, Elephant Communication",
            "url": "https://www.aza.org/jobs?job=51494",
            "published_date": "2026-05-25",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Advanced communication research posting with salary."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0004",
      "name": "Animal learning researcher",
      "slug": "animal-learning-researcher",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_behavior_research",
        "name": "Behavioral research & cognition",
        "description": "Research on behavior, cognition, learning, communication, and comparative psychology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies conditioning, learning, memory, reinforcement, discrimination, and related behavioral processes; independent research roles generally sit within psychology, biology, neuroscience, or animal-behavior programs.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Research Scientist; Postdoctoral Fellow; Professor; Research Assistant",
        "Alternate names / terms": "Learning & Behavior Researcher; Comparative Learning Researcher; Experimental Psychologist",
        "Typical education / progression": "B.S. for assistant roles; M.S./Ph.D. for independent research",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-AS, ME-ZOO, URI-WZ",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, URI-AZ",
        "Weakly aligned paths": "UMA-WEC, ME-WE, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "C",
        "UMA-BIO": "G",
        "UMA-WEC": "N",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "N",
        "URI-WZ": "C"
      },
      "notes": "UNE explicitly emphasizes learning/conditioning",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.5,
        0.5,
        1.0,
        2.9,
        1.6
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "variable",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Comparative Learning Researcher",
        "Experimental Psychologist",
        "Learning & Behavior Researcher",
        "Postdoctoral Fellow",
        "Professor",
        "Research Assistant",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_neuro",
          "name": "Neuroscience & neuroethology",
          "category": "Biological mechanisms",
          "description": "Neural mechanisms of behavior.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0046",
      "name": "Animal physiologist",
      "slug": "animal-physiologist",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_physiology",
        "name": "Physiology & neuroethology",
        "description": "Animal physiology, neuroethology, and mechanisms of behavior."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies how animal bodies function and respond to environment, stress, reproduction, energetics, temperature, exercise, disease, or other biological challenges.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Broad animal biology; evolution/ecology/physiology; field or laboratory methods; statistics; species identification; scientific writing; faculty-mentored research.",
        "Searchable job titles": "Animal Physiologist; Comparative Physiologist; Physiological Ecologist; Research Scientist",
        "Alternate names / terms": "Comparative Animal Physiologist; Organismal Physiologist",
        "Typical education / progression": "M.S./Ph.D. typical for scientist roles",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-WEC, ME-WE, URI-W, URI-WZ",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-AS, ME-ZOO, URI-AZ"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "C",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "C",
        "URI-WZ": "C"
      },
      "notes": "UMass/UMaine Zoology/URI Animal Science provide strong biological foundations",
      "dims": [
        1.5,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        1.8,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Comparative Animal Physiologist",
        "Organismal Physiologist",
        "Animal Physiologist",
        "Comparative Physiologist",
        "Physiological Ecologist",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_dir_0013",
          "career_id": "cr_0046",
          "title": "Research Physiologist",
          "organization": "U.S. Geological Survey - EESC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_eesc",
          "notes": "Current federal research title.",
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0007",
      "name": "Animal welfare / behavior coordinator",
      "slug": "animal-welfare-behavior-coordinator",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_welfare_husbandry",
        "name": "Welfare, enrichment & behavioral husbandry",
        "description": "Welfare assessment, enrichment, behavioral husbandry, and applied animal-care behavior."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Coordinates practical welfare and behavior programs, often combining assessment, staff guidance, enrichment plans, training protocols, records, and case management.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Animal Welfare Specialist; Behavior Coordinator; Clinical Animal Behavior Coordinator; Behavior Manager",
        "Alternate names / terms": "Welfare Coordinator; Animal Behavior Coordinator",
        "Typical education / progression": "B.S. plus substantial applied experience common",
        "O*NET / BLS proxy": "Animal Trainers (39-2011.00)",
        "Job outlook": "5%–6% (Faster than average); ~7,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $29,600–$33,740; mid proxy $39,990–$53,580",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, ME-ZOO, URI-W",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-WEC, ME-WE"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "Applied institution/zoo/shelter role",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.0,
        2.9,
        1.1
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        29600,
        33740
      ],
      "midSalary": [
        39990,
        53580
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Animal Behavior Coordinator",
        "Welfare Coordinator",
        "Animal Welfare Specialist",
        "Behavior Coordinator",
        "Behavior Manager",
        "Clinical Animal Behavior Coordinator"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0006",
      "name": "Animal welfare scientist",
      "slug": "animal-welfare-scientist",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_welfare_husbandry",
        "name": "Welfare, enrichment & behavioral husbandry",
        "description": "Welfare assessment, enrichment, behavioral husbandry, and applied animal-care behavior."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Develops and applies behavioral, physiological, and environmental measures to evaluate animal welfare and test ways to improve care, housing, husbandry, enrichment, or management.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral and physiological welfare measures, experimental design, statistics, husbandry knowledge, ethics/welfare frameworks, and research communication.",
        "Searchable job titles": "Animal Welfare Scientist; Animal Welfare & Behaviour Scientist; Research Scientist",
        "Alternate names / terms": "Applied Animal Welfare Scientist; Welfare Research Scientist",
        "Typical education / progression": "M.S./Ph.D. common for scientist roles",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-BIO, ME-ZOO",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Weakly aligned paths": "UMA-WEC, ME-WE, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "G",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "N",
        "URI-WZ": "G"
      },
      "notes": "URI Zoo pathway particularly strong",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.5,
        0.5,
        1.5,
        2.9,
        1.1
      ],
      "directContact": "High",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Applied Animal Welfare Scientist",
        "Welfare Research Scientist",
        "Animal Welfare & Behaviour Scientist",
        "Animal Welfare Scientist",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0015",
      "name": "Aquarist / aquarium animal-care specialist",
      "slug": "aquarist-aquarium-animal-care-specialist",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_aquatic_care",
        "name": "Aquatic animal care",
        "description": "Aquarist work and related aquatic animal care."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Maintains aquatic animals and life-support environments, including feeding, water-quality checks, habitat maintenance, observation, enrichment, records, and sometimes diving.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Aquarist; Aquarium Biologist; Aquarium Animal Care Specialist",
        "Alternate names / terms": "Aquarium Keeper; Aquatic Animal Care Specialist",
        "Typical education / progression": "B.S. commonly preferred; strong hands-on aquatic experience",
        "O*NET / BLS proxy": "Animal Caretakers (39-2021.00)",
        "Job outlook": "7%+ (Much faster than average); ~74,600 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $27,250–$29,820; mid proxy $35,360–$40,050",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, UMA-AS, ME-ZOO, URI-W",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-WEC, ME-WE"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "C",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "URI Zoo certificate particularly relevant",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        0.7,
        2.2,
        1.4
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        27250,
        29820
      ],
      "midSalary": [
        35360,
        40050
      ],
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 36400,
        "observedMax": 36400,
        "medianLow": 36400,
        "medianHigh": 36400,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Aquarium Keeper",
        "Aquatic Animal Care Specialist",
        "Aquarist",
        "Aquarium Animal Care Specialist",
        "Aquarium Biologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0027",
          "career_id": "cr_0015",
          "title": "Animal Care Specialist - Aquarium Team",
          "organization": "Kansas City Zoo & Aquarium",
          "location": "Kansas City, MO",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_aza_aquariumcare",
          "notes": "SCUBA preferred; weekend/holiday work.",
          "source": {
            "source_id": "src_aza_aquariumcare",
            "organization": "Kansas City Zoo & Aquarium / AZA",
            "source_type": "job_posting",
            "title": "Animal Care Specialist - Aquarium Team",
            "url": "https://www.aza.org/jobs?job=51307",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Aquarium animal-care posting with salary and dive requirements."
          }
        },
        {
          "observed_id": "obs_post_0015",
          "career_id": "cr_0015",
          "title": "Dive Coordinator",
          "organization": "Texas State Aquarium",
          "location": "Corpus Christi, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-09-02",
          "source_id": "src_aza_jobs",
          "notes": "Adjacent aquarium-care/operations role.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0027",
          "career_id": "cr_0015",
          "title": "Animal Care Specialist - Aquarium Team",
          "employer": "Kansas City Zoo & Aquarium",
          "location": "Kansas City, MO",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": 17.5,
          "salary_max": 17.5,
          "salary_unit": "hourly",
          "currency": "USD",
          "source_id": "src_aza_aquariumcare",
          "url": "https://www.aza.org/jobs?job=51307",
          "active_status": "current_or_recent",
          "notes": "SCUBA preferred; weekend/holiday work.",
          "source": {
            "source_id": "src_aza_aquariumcare",
            "organization": "Kansas City Zoo & Aquarium / AZA",
            "source_type": "job_posting",
            "title": "Animal Care Specialist - Aquarium Team",
            "url": "https://www.aza.org/jobs?job=51307",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Aquarium animal-care posting with salary and dive requirements."
          }
        },
        {
          "posting_id": "post_0015",
          "career_id": "cr_0015",
          "title": "Dive Coordinator",
          "employer": "Texas State Aquarium",
          "location": "Corpus Christi, TX",
          "posted_date": "2026-09-02",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/Jobs/",
          "active_status": "current_or_recent",
          "notes": "Adjacent aquarium-care/operations role.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0032",
      "name": "Behavioral ecologist",
      "slug": "behavioral-ecologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_wildlife_biology",
        "name": "Wildlife biology & management",
        "description": "Professional wildlife biology, nongame/diversity biology, and wildlife program work."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies how behavior is shaped by ecological conditions and evolution, including foraging, mating, social systems, predator avoidance, movement, communication, and life-history tradeoffs.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Research Scientist; Postdoctoral Fellow; Professor",
        "Alternate names / terms": "Behavioral Ecologist; Animal Behavior Ecologist; Behavioral Ecology Researcher",
        "Typical education / progression": "M.S./Ph.D. typical for independent scientist roles",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-AS, URI-AZ",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "C",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "C",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Typically graduate-level scientific career",
      "dims": [
        1.8,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.7
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Animal Behavior Ecologist",
        "Behavioral Ecologist",
        "Behavioral Ecology Researcher",
        "Postdoctoral Fellow",
        "Professor",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0008",
      "name": "Behavioral husbandry specialist",
      "slug": "behavioral-husbandry-specialist",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_welfare_husbandry",
        "name": "Welfare, enrichment & behavioral husbandry",
        "description": "Welfare assessment, enrichment, behavioral husbandry, and applied animal-care behavior."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Integrates husbandry with behavior science, using training, choice/control, enrichment, cooperative care, and behavioral monitoring to improve daily animal management.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Behavioral Husbandry Manager; Curator of Behavioral Husbandry; Animal Behavior Manager",
        "Alternate names / terms": "Behavioral Husbandry Specialist; Training & Enrichment Specialist",
        "Typical education / progression": "B.S. plus animal-care/training experience",
        "O*NET / BLS proxy": "Animal Trainers (39-2011.00)",
        "Job outlook": "5%–6% (Faster than average); ~7,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $29,600–$33,740; mid proxy $39,990–$53,580",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, ME-ZOO, URI-W",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-WEC, ME-WE"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "Strong match for UNE and URI Zoo routes",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.5,
        2.9,
        1.1
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        29600,
        33740
      ],
      "midSalary": [
        39990,
        53580
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Behavioral Husbandry Specialist",
        "Training & Enrichment Specialist",
        "Animal Behavior Manager",
        "Behavioral Husbandry Manager",
        "Curator of Behavioral Husbandry"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0080",
      "name": "Canine behavior consultant",
      "slug": "canine-behavior-consultant",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_shelter_companion",
        "name": "Shelter & companion-animal behavior",
        "description": "Shelter behavior, companion-animal behavior, and complex behavior consulting."
      },
      "roleKind": "career",
      "marketStatus": "Established professional role; title and regulation vary",
      "evidenceStatus": "verified_professional_role",
      "lastVerified": "2026-09-08",
      "roleFocus": "Assesses and helps modify complex canine behavior problems such as fear, aggression, anxiety, compulsive behavior, and reactivity using behavior science and client/handler coaching.",
      "details": {
        "Typical work settings": "Private behavior practice, shelters/rescues, training organizations, humane societies, service-animal programs.",
        "Undergraduate preparation most useful": "Learning theory, ethology, behavior observation, animal welfare, applied behavior analysis, physiology, client communication.",
        "Searchable job titles": "Canine Behavior Consultant; Dog Behavior Consultant; Behavior Specialist; Behavior Modification Consultant",
        "Alternate names / terms": "CBCC-KA; behavior consultant; canine behavior specialist",
        "Typical education / progression": "Formal degree requirements vary; substantial supervised experience and independent certification can be important. Advanced applied-animal-behavior science may require research graduate education.",
        "Job outlook": "No dedicated federal occupation; use certification organizations and real postings/practice data.",
        "Salary context": "Highly variable by employer, geography, and self-employment; broad animal-trainer wages are an imperfect proxy.",
        "Market status": "Established professional role; title and regulation vary",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "N",
        "URI-WZ": "C"
      },
      "notes": "",
      "dims": [
        3.0,
        2.8,
        1.1,
        0.1,
        0.1,
        1.3,
        0.1,
        0.4,
        1.1,
        2.0
      ],
      "directContact": "High",
      "educationBand": "Experience-driven; advanced certification valuable",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Education / public"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "CBCC-KA",
        "behavior consultant",
        "canine behavior specialist",
        "Behavior Modification Consultant",
        "Behavior Specialist",
        "Canine Behavior Consultant",
        "Dog Behavior Consultant"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [
        {
          "evidence_id": "ev_0008",
          "entity_type": "career",
          "entity_id": "cr_0080",
          "claim_type": "credential",
          "claim_value": "CBCC-KA eligibility includes at least 300 hours of canine behavior consulting within the previous three years plus attestation and examination requirements.",
          "source_id": "src_ccpdt_cbcc",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_ccpdt_cbcc",
            "organization": "Certification Council for Professional Dog Trainers",
            "source_type": "credential_standard",
            "title": "Certified Behavior Consultant Canine - Knowledge Assessed",
            "url": "https://www.ccpdt.org/certification/dog-behavior-consultant/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Canine behavior-consultant experience and certification requirements."
          }
        }
      ],
      "credentials": [
        {
          "relationship": "useful",
          "notes": "Independent certification for experienced canine behavior consultants.",
          "credential_id": "cred_ccpdt_cbcc",
          "name": "CBCC-KA®",
          "organization": "Certification Council for Professional Dog Trainers",
          "credential_type": "professional certification",
          "description": "Advanced canine behavior-consultant credential; current eligibility includes 300 hours of behavior consulting within the previous three years plus attestation and exam requirements.",
          "source_id": "src_ccpdt_cbcc",
          "source_url": "https://www.ccpdt.org/certification/dog-behavior-consultant/",
          "source_retrieved": "2026-09-08"
        }
      ],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0013",
      "name": "Companion-animal behavior researcher",
      "slug": "companion-animal-behavior-researcher",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_shelter_companion",
        "name": "Shelter & companion-animal behavior",
        "description": "Shelter behavior, companion-animal behavior, and complex behavior consulting."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies behavior, cognition, welfare, social interaction, learning, or human-animal relationships in dogs, cats, and other companion species.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Research Scientist; Postdoctoral Fellow; Professor",
        "Alternate names / terms": "Companion Animal Welfare Scientist; Canine Cognition Researcher; Feline Behavior Researcher",
        "Typical education / progression": "B.S. for RA roles; M.S./Ph.D. typical for independent research",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "ME-ZOO, URI-WZ",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-AS, URI-AZ",
        "Weakly aligned paths": "UMA-WEC, ME-WE, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "N",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "N",
        "URI-WZ": "C"
      },
      "notes": "Advanced research normally graduate-level",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.0,
        2.9,
        1.6
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate degree typical",
      "careerStage": "variable",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Canine Cognition Researcher",
        "Companion Animal Welfare Scientist",
        "Feline Behavior Researcher",
        "Postdoctoral Fellow",
        "Professor",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0003",
      "name": "Comparative cognition researcher",
      "slug": "comparative-cognition-researcher",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_behavior_research",
        "name": "Behavioral research & cognition",
        "description": "Research on behavior, cognition, learning, communication, and comparative psychology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies how different species perceive, learn, remember, solve problems, make decisions, and process information, usually through controlled behavioral experiments and comparative methods.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Research Assistant; Research Scientist; Postdoctoral Fellow; Professor",
        "Alternate names / terms": "Comparative Cognition Scientist; Animal Cognition Researcher; Comparative Psychologist",
        "Typical education / progression": "B.S. for RA roles; Ph.D. typical for independent research",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-AS, URI-WZ, URI-AZ",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, ME-ZOO",
        "Weakly aligned paths": "UMA-WEC, ME-WE, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "G",
        "UMA-AS": "C",
        "UMA-BIO": "G",
        "UMA-WEC": "N",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "C",
        "URI-W": "N",
        "URI-WZ": "C"
      },
      "notes": "UNE especially direct; UMass Biology/UMaine Zoology strong research foundations",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.0,
        2.9,
        1.6
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "variable",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Animal Cognition Researcher",
        "Comparative Cognition Scientist",
        "Comparative Psychologist",
        "Postdoctoral Fellow",
        "Professor",
        "Research Assistant",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0057",
      "name": "Conservation NGO scientist / coordinator",
      "slug": "conservation-ngo-scientist-coordinator",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_agency",
        "name": "Natural-resource agency & management",
        "description": "Agency biology, park/resource work, natural-resource management, and program management."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Works within nonprofit conservation organizations on research, field projects, species/habitat programs, partnerships, outreach, grants, or program coordination.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Statistics; data management; GIS/spatial methods where relevant; field ecology; regulatory/scientific writing; reproducible analysis; project documentation and communication.",
        "Searchable job titles": "Conservation Scientist; Program Scientist; Project Biologist; Conservation Coordinator",
        "Alternate names / terms": "NGO Conservation Scientist; Conservation Program Coordinator",
        "Typical education / progression": "B.S./M.S. depending technical responsibility",
        "O*NET / BLS proxy": "Conservation Scientists (19-1031.00)",
        "Job outlook": "3%–4% (Average); ~2,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $47,550–$57,700; mid proxy $73,010–$91,560",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, URI-AZ",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Scientific and programmatic nonprofit work",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.6,
        2.0
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        47550,
        57700
      ],
      "midSalary": [
        73010,
        91560
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Conservation Program Coordinator",
        "NGO Conservation Scientist",
        "Conservation Coordinator",
        "Conservation Scientist",
        "Program Scientist",
        "Project Biologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0039",
          "career_id": "cr_0057",
          "title": "Conservation Impact Specialist",
          "organization": "American Bird Conservancy",
          "location": "Remote, U.S.",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Featured current TWS posting.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0039",
          "career_id": "cr_0057",
          "title": "Conservation Impact Specialist",
          "employer": "American Bird Conservancy",
          "location": "Remote, U.S.",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/",
          "active_status": "current_or_recent",
          "notes": "Featured current TWS posting.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0033",
      "name": "Conservation biologist",
      "slug": "conservation-biologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_wildlife_biology",
        "name": "Wildlife biology & management",
        "description": "Professional wildlife biology, nongame/diversity biology, and wildlife program work."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Applies biological science to biodiversity conservation, combining species/population ecology, threats, habitat, management, monitoring, restoration, and conservation planning.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "Mixed entry path; assistant roles may be B.S.-level, scientist roles generally graduate-level",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Conservation Biologist; Wildlife Biologist; Research Biologist",
        "Alternate names / terms": "Conservation Scientist; Biodiversity Biologist",
        "Typical education / progression": "B.S. for some roles; M.S./Ph.D. common for research/lead roles",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, URI-AZ",
        "Graduate-oriented foundations": "UMA-BIO, ME-ZOO",
        "Weakly aligned paths": "UMA-AS"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "SG",
        "UMA-AS": "N",
        "UMA-BIO": "SG",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Biology/Zoology may require graduate work for scientist-level roles",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Biodiversity Biologist",
        "Conservation Scientist",
        "Conservation Biologist",
        "Research Biologist",
        "Wildlife Biologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0084",
      "name": "Conservation delivery / habitat program coordinator",
      "slug": "conservation-delivery-habitat-program-coordinator",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_habitat",
        "name": "Habitat & conservation delivery",
        "description": "Habitat biology, restoration delivery, conservation planning, and refuge management."
      },
      "roleKind": "career",
      "marketStatus": "Verified current market titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Coordinates habitat conservation delivery across agencies, NGOs, landowners, and partners, translating conservation plans into habitat projects, incentives, restoration, and implementation.",
      "details": {
        "Typical work settings": "Conservation NGOs, joint ventures, state/federal agencies, landowner partnerships, habitat programs.",
        "Undergraduate preparation most useful": "Wildlife ecology, habitat management, GIS, conservation planning, technical writing, stakeholder communication.",
        "Searchable job titles": "Conservation Delivery Specialist; Habitat Delivery Coordinator; Habitat Program Manager; Conservation Delivery Coordinator",
        "Alternate names / terms": "Habitat delivery; conservation implementation; joint venture coordinator",
        "Typical education / progression": "B.S. is common; 3–5 years of applied conservation/project experience often appears in coordinator roles.",
        "Job outlook": "No dedicated O*NET occupation; use current NGO/agency postings.",
        "Salary context": "Use employer postings; current examples can differ substantially by responsibility and region.",
        "Market status": "Verified current market titles",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        0.4,
        0.1,
        0.1,
        2.0,
        0.2,
        0.8,
        3.0,
        2.0,
        1.2,
        1.6
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Education / public",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 74520,
        "observedMax": 82800,
        "medianLow": 74520,
        "medianHigh": 82800,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Habitat delivery",
        "conservation implementation",
        "joint venture coordinator",
        "Conservation Delivery Coordinator",
        "Conservation Delivery Specialist",
        "Habitat Delivery Coordinator",
        "Habitat Program Manager"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0037",
          "career_id": "cr_0084",
          "title": "GCJV Coastal Grassland Incentive Program and Habitat Delivery Coordinator",
          "organization": "American Bird Conservancy",
          "location": "Lafayette, LA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_habitatdelivery",
          "notes": "Habitat conservation delivery leadership.",
          "source": {
            "source_id": "src_tws_habitatdelivery",
            "organization": "American Bird Conservancy / TWS",
            "source_type": "job_posting",
            "title": "GCJV Habitat Delivery Coordinator",
            "url": "https://careers.wildlife.org/job/gulf-coast-joint-venture-gcjv-coastal-grassland-incentive-program-cgrip-and-habitat-delivery-coordinator/85122735/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Habitat delivery posting with salary and education."
          }
        },
        {
          "observed_id": "obs_post_0041",
          "career_id": "cr_0084",
          "title": "Rio Grande Joint Venture Conservation Delivery Specialist",
          "organization": "American Bird Conservancy",
          "location": "Alpine, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Featured current TWS posting.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0037",
          "career_id": "cr_0084",
          "title": "GCJV Coastal Grassland Incentive Program and Habitat Delivery Coordinator",
          "employer": "American Bird Conservancy",
          "location": "Lafayette, LA",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "B.A./B.S.",
          "experience_min": "3–5 years",
          "salary_min": 74520.0,
          "salary_max": 82800.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_habitatdelivery",
          "url": "https://careers.wildlife.org/job/gulf-coast-joint-venture-gcjv-coastal-grassland-incentive-program-cgrip-and-habitat-delivery-coordinator/85122735/",
          "active_status": "current_or_recent",
          "notes": "Habitat conservation delivery leadership.",
          "source": {
            "source_id": "src_tws_habitatdelivery",
            "organization": "American Bird Conservancy / TWS",
            "source_type": "job_posting",
            "title": "GCJV Habitat Delivery Coordinator",
            "url": "https://careers.wildlife.org/job/gulf-coast-joint-venture-gcjv-coastal-grassland-incentive-program-cgrip-and-habitat-delivery-coordinator/85122735/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Habitat delivery posting with salary and education."
          }
        },
        {
          "posting_id": "post_0041",
          "career_id": "cr_0084",
          "title": "Rio Grande Joint Venture Conservation Delivery Specialist",
          "employer": "American Bird Conservancy",
          "location": "Alpine, TX",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/",
          "active_status": "current_or_recent",
          "notes": "Featured current TWS posting.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0015",
          "entity_type": "career",
          "entity_id": "cr_0084",
          "claim_type": "market_title",
          "claim_value": "Current TWS postings include Habitat Delivery Coordinator and Conservation Delivery Specialist.",
          "source_id": "src_tws_habitatdelivery",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_tws_habitatdelivery",
            "organization": "American Bird Conservancy / TWS",
            "source_type": "job_posting",
            "title": "GCJV Habitat Delivery Coordinator",
            "url": "https://careers.wildlife.org/job/gulf-coast-joint-venture-gcjv-coastal-grassland-incentive-program-cgrip-and-habitat-delivery-coordinator/85122735/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Habitat delivery posting with salary and education."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0086",
      "name": "Conservation geneticist / wildlife genomicist",
      "slug": "conservation-geneticist-wildlife-genomicist",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_evolution",
        "name": "Evolutionary & ecological science",
        "description": "Evolutionary biology and broad ecological science involving animals."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "Established scientific specialty with verified institutional titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses genetics and genomics to study population structure, diversity, gene flow, relatedness, adaptation, and conservation management of wildlife or managed populations.",
      "details": {
        "Typical work settings": "USGS and other government science centers, zoo conservation-genetics programs, universities, NGOs, genomic laboratories.",
        "Undergraduate preparation most useful": "Genetics, molecular/cellular biology, population biology, statistics, bioinformatics, ecology, research.",
        "Searchable job titles": "Research Geneticist; Conservation Geneticist; Wildlife Geneticist; Population Genomics Scientist",
        "Alternate names / terms": "Conservation genomics; population genetics; molecular ecology",
        "Typical education / progression": "Research technician roles may begin after a B.S.; independent research commonly requires a Ph.D.",
        "O*NET / BLS proxy": "Biological Scientists / Geneticists (broad proxy)",
        "Job outlook": "No narrow conservation-genetics benchmark; use federal genetics series, biological-science data, and current postings.",
        "Salary context": "Use government/institutional postings and research-scientist benchmarks.",
        "Market status": "Established scientific specialty with verified institutional titles",
        "Career type": "Scientific Specialty"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "G",
        "UMA-AS": "C",
        "UMA-BIO": "G",
        "UMA-WEC": "C",
        "UNE-AB": "C",
        "UNE-AN": "G",
        "URI-AZ": "C",
        "URI-W": "C",
        "URI-WZ": "C"
      },
      "notes": "",
      "dims": [
        0.5,
        0.2,
        0.5,
        1.5,
        0.2,
        3.0,
        2.6,
        2.6,
        3.0,
        0.8
      ],
      "directContact": "Low",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 87264,
        "observedMax": 98172,
        "medianLow": 87264,
        "medianHigh": 98172,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Conservation genomics",
        "molecular ecology",
        "population genetics",
        "Conservation Geneticist",
        "Population Genomics Scientist",
        "Research Geneticist",
        "Wildlife Geneticist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0024",
          "career_id": "cr_0086",
          "title": "Conservation Genetics Post Doctoral Associate",
          "organization": "San Diego Zoo Wildlife Alliance",
          "location": "Escondido, CA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_aza_genetics",
          "notes": "Two-year conservation genetics postdoctoral position.",
          "source": {
            "source_id": "src_aza_genetics",
            "organization": "San Diego Zoo Wildlife Alliance / AZA",
            "source_type": "job_posting",
            "title": "Conservation Genetics Post Doctoral Associate",
            "url": "https://www.aza.org/jobs?job=51965",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Conservation genetics posting with salary."
          }
        },
        {
          "observed_id": "obs_dir_0010",
          "career_id": "cr_0086",
          "title": "Research Geneticist",
          "organization": "U.S. Geological Survey - Forest & Rangeland Ecosystem Science Center",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_werc",
          "notes": "Current federal research-genetics title observed in USGS ecosystem science.",
          "source": {
            "source_id": "src_usgs_werc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Western Ecological Research Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/werc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        },
        {
          "observed_id": "obs_dir_0009",
          "career_id": "cr_0086",
          "title": "Supervisory Research Geneticist",
          "organization": "U.S. Geological Survey - WERC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_werc",
          "notes": "Current federal research-genetics title.",
          "source": {
            "source_id": "src_usgs_werc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Western Ecological Research Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/werc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0024",
          "career_id": "cr_0086",
          "title": "Conservation Genetics Post Doctoral Associate",
          "employer": "San Diego Zoo Wildlife Alliance",
          "location": "Escondido, CA",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "Doctorate/postdoctorate",
          "experience_min": null,
          "salary_min": 87264.0,
          "salary_max": 98172.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_genetics",
          "url": "https://www.aza.org/jobs?job=51965",
          "active_status": "current_or_recent",
          "notes": "Two-year conservation genetics postdoctoral position.",
          "source": {
            "source_id": "src_aza_genetics",
            "organization": "San Diego Zoo Wildlife Alliance / AZA",
            "source_type": "job_posting",
            "title": "Conservation Genetics Post Doctoral Associate",
            "url": "https://www.aza.org/jobs?job=51965",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Conservation genetics posting with salary."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0005",
          "entity_type": "career",
          "entity_id": "cr_0086",
          "claim_type": "qualification",
          "claim_value": "Federal GS-0440 genetics work requires genetics or related biological science with at least 9 semester hours genetics.",
          "source_id": "src_opm_0440",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_opm_0440",
            "organization": "U.S. Office of Personnel Management",
            "source_type": "qualification_standard",
            "title": "Genetics Series 0440",
            "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/genetics-series-0440/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Federal genetics education requirements."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": [
        {
          "qualification_id": "qual_0440",
          "career_id": "cr_0086",
          "organization": "U.S. Office of Personnel Management",
          "series_code": "0440",
          "name": "Federal Genetics Series 0440",
          "education_requirement": "Degree in genetics or a basic biological science.",
          "coursework_requirement": "At least 9 semester hours in genetics for related biological-science degrees.",
          "experience_requirement": "Graduate training is common because specialized genetics preparation may be limited at undergraduate level.",
          "source_id": "src_opm_0440",
          "source_url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/genetics-series-0440/",
          "source_title": "Genetics Series 0440",
          "source_retrieved": "2026-09-08"
        }
      ]
    },
    {
      "id": "cr_0071",
      "name": "Conservation outreach / program coordinator",
      "slug": "conservation-outreach-program-coordinator",
      "category": "Education, outreach & science communication",
      "domain": {
        "id": "dm_education",
        "name": "Education, outreach & communication",
        "description": "Interpretation, education, outreach, museums, collections, and science communication."
      },
      "roleFamily": {
        "id": "rf_wildlife_education",
        "name": "Wildlife interpretation & outreach",
        "description": "Wildlife/environmental education, naturalist work, and conservation outreach."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Coordinates education, engagement, volunteer, citizen-science, or conservation-program activities and communicates scientific issues to public or stakeholder audiences.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, museums, parks/refuges, nature centers, schools, NGOs, government outreach programs, publishers, and scientific organizations.",
        "Undergraduate preparation most useful": "Strong biological content knowledge; writing and presentation; audience-centered communication; interpretation/teaching; program organization; research literacy.",
        "Searchable job titles": "Outreach Coordinator; Conservation Engagement Coordinator; Education & Outreach Coordinator; Program Coordinator",
        "Alternate names / terms": "Conservation Outreach Coordinator; Community Engagement Coordinator",
        "Typical education / progression": "B.S. common; program experience important",
        "O*NET / BLS proxy": "Park Naturalists (19-1031.03)",
        "Job outlook": "3%–4% (Average; Conservation Scientists proxy); ~2,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $47,550–$57,700; mid proxy $73,010–$91,560",
        "Proxy fit": "Low",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, UMA-AS, URI-AZ",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "C",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Combines science knowledge with communication/program work",
      "dims": [
        1.3,
        0.5,
        1.2,
        1.3,
        0.3,
        1.0,
        2.2,
        0.8,
        1.4,
        3.0
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Education / public",
        "Research"
      ],
      "entrySalary": [
        47550,
        57700
      ],
      "midSalary": [
        73010,
        91560
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Community Engagement Coordinator",
        "Conservation Outreach Coordinator",
        "Conservation Engagement Coordinator",
        "Education & Outreach Coordinator",
        "Outreach Coordinator",
        "Program Coordinator"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0010",
          "career_id": "cr_0071",
          "title": "Outreach Specialist",
          "organization": "Fort Worth Zoo",
          "location": "Fort Worth, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-09-04",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0010",
          "career_id": "cr_0071",
          "title": "Outreach Specialist",
          "employer": "Fort Worth Zoo",
          "location": "Fort Worth, TX",
          "posted_date": "2026-09-04",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0021",
      "name": "Conservation-breeding scientist",
      "slug": "conservation-breeding-scientist",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_population",
        "name": "Conservation breeding & population management",
        "description": "Conservation breeding, population biology, studbooks, and SSP population-management work."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses population, behavioral, genetic, reproductive, and welfare science to design and evaluate conservation-breeding and population-management strategies.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Conservation Scientist; Population Biologist; Research Scientist; Reintroduction Biologist",
        "Alternate names / terms": "Conservation Breeding Scientist; Population Management Scientist",
        "Typical education / progression": "M.S./Ph.D. common",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Graduate research path across all tracks",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        0.7,
        2.2,
        1.4
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Conservation Breeding Scientist",
        "Population Management Scientist",
        "Conservation Scientist",
        "Population Biologist",
        "Reintroduction Biologist",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_release",
          "name": "Reintroduction & release",
          "category": "Applied conservation",
          "description": "Release planning, reintroduction, translocation, and post-release evaluation.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0020",
      "name": "Conservation-breeding technician",
      "slug": "conservation-breeding-technician",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_population",
        "name": "Conservation breeding & population management",
        "description": "Conservation breeding, population biology, studbooks, and SSP population-management work."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Provides husbandry, breeding support, records, behavioral monitoring, sampling, and sometimes release preparation for threatened or endangered species programs.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Conservation Breeding Keeper; Conservation Husbandry Technician; Reintroduction Technician",
        "Alternate names / terms": "Breeding Program Technician; Conservation Keeper",
        "Typical education / progression": "B.S. plus husbandry/field experience",
        "O*NET / BLS proxy": "Biological Technicians (19-4021.00)",
        "Job outlook": "3%–4% (Average); ~9,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $40,330–$48,130; mid proxy $57,510–$71,520",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UMA-WEC, UMA-AS, ME-WE, URI-W, URI-WZ, URI-AZ",
        "Credible with planning": "UNE-AB, UNE-AN, UMA-BIO, ME-ZOO",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "S",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Bridges animal management and conservation",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        1.2,
        2.2,
        1.4
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        40330,
        48130
      ],
      "midSalary": [
        57510,
        71520
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Breeding Program Technician",
        "Conservation Keeper",
        "Conservation Breeding Keeper",
        "Conservation Husbandry Technician",
        "Reintroduction Technician"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_release",
          "name": "Reintroduction & release",
          "category": "Applied conservation",
          "description": "Release planning, reintroduction, translocation, and post-release evaluation.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0088",
      "name": "Ecological data scientist",
      "slug": "ecological-data-scientist",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_quant",
        "name": "Quantitative ecology & data science",
        "description": "Statistics, ecological modeling, data science, and quantitative ecology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "Verified institutional title variants",
      "evidenceStatus": "verified_professional_role",
      "lastVerified": "2026-09-08",
      "roleFocus": "Builds, manages, analyzes, and models ecological or wildlife datasets, often integrating monitoring, spatial, remote-sensing, population, or citizen-science data.",
      "details": {
        "Typical work settings": "Government science centers, universities, conservation NGOs, consulting firms, research programs.",
        "Undergraduate preparation most useful": "Statistics, data management, programming, ecology, GIS, research design, scientific communication.",
        "Searchable job titles": "Biologist (Data Scientist); Ecological Data Scientist; Wildlife Data Scientist; Biodiversity Data Analyst",
        "Alternate names / terms": "Ecological informatics; conservation data science",
        "Typical education / progression": "B.S. can support analyst/assistant roles; M.S./Ph.D. often useful for advanced modeling or independent research.",
        "Job outlook": "No single dedicated occupation; use data/statistics plus biological-science evidence.",
        "Salary context": "Posting-specific data are preferable to generic computer-occupation proxies.",
        "Market status": "Verified institutional title variants",
        "Career type": "Scientific Specialty"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "C",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        0.3,
        0.1,
        0.0,
        1.5,
        0.2,
        1.2,
        2.1,
        3.0,
        2.8,
        0.8
      ],
      "directContact": "Low",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Ecological informatics",
        "conservation data science",
        "Biodiversity Data Analyst",
        "Biologist (Data Scientist)",
        "Ecological Data Scientist",
        "Wildlife Data Scientist"
      ],
      "competencies": [
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_dir_0007",
          "career_id": "cr_0088",
          "title": "Biologist (Data Scientist)",
          "organization": "U.S. Geological Survey - EESC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_eesc",
          "notes": "Current federal title.",
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "recentPostings": [],
      "evidence": [
        {
          "evidence_id": "ev_0018",
          "entity_type": "career",
          "entity_id": "cr_0088",
          "claim_type": "market_title",
          "claim_value": "USGS ecological science centers include the title Biologist (Data Scientist).",
          "source_id": "src_usgs_eesc",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0045",
      "name": "Ecological research technician",
      "slug": "ecological-research-technician",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_evolution",
        "name": "Evolutionary & ecological science",
        "description": "Evolutionary biology and broad ecological science involving animals."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Provides hands-on support for ecological studies through field sampling, lab processing, species identification, data management, equipment use, and research logistics.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Broad animal biology; evolution/ecology/physiology; field or laboratory methods; statistics; species identification; scientific writing; faculty-mentored research.",
        "Searchable job titles": "Ecological Technician; Research Technician; Field Technician; Biological Science Technician",
        "Alternate names / terms": "Ecology Technician; Field Research Technician",
        "Typical education / progression": "B.S. common",
        "O*NET / BLS proxy": "Biological Technicians (19-4021.00)",
        "Job outlook": "3%–4% (Average); ~9,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $40,330–$48,130; mid proxy $57,510–$71,520",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, URI-AZ",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Strong B.S.-level research role",
      "dims": [
        1.5,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        2.3,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        40330,
        48130
      ],
      "midSalary": [
        57510,
        71520
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Ecology Technician",
        "Field Research Technician",
        "Biological Science Technician",
        "Ecological Technician",
        "Field Technician",
        "Research Technician"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0034",
      "name": "Endangered-species biologist",
      "slug": "endangered-species-biologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_reintroduction",
        "name": "Species recovery & reintroduction",
        "description": "Release, reintroduction, post-release monitoring, and species recovery."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Works on recovery and management of threatened or endangered species through surveys, habitat analysis, monitoring, permitting, recovery planning, and coordination with agencies or landowners.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Species Recovery Biologist; Threatened & Endangered Species Biologist; Fish & Wildlife Biologist",
        "Alternate names / terms": "Endangered Species Biologist; Species Recovery Specialist",
        "Typical education / progression": "B.S./M.S. common",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Dedicated wildlife/conservation paths strongest",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Endangered Species Biologist",
        "Species Recovery Specialist",
        "Fish & Wildlife Biologist",
        "Species Recovery Biologist",
        "Threatened & Endangered Species Biologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0009",
      "name": "Enrichment coordinator / specialist",
      "slug": "enrichment-coordinator-specialist",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_welfare_husbandry",
        "name": "Welfare, enrichment & behavioral husbandry",
        "description": "Welfare assessment, enrichment, behavioral husbandry, and applied animal-care behavior."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Plans, evaluates, documents, and improves enrichment programs designed to promote species-appropriate behavior and reduce behavioral problems in animals under human care.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Enrichment Manager; Behavioral Husbandry & Enrichment Manager; Animal Welfare Specialist",
        "Alternate names / terms": "Enrichment Coordinator; Enrichment Specialist",
        "Typical education / progression": "B.S. plus animal-care/behavior experience",
        "O*NET / BLS proxy": "Animal Trainers (39-2011.00)",
        "Job outlook": "5%–6% (Faster than average); ~7,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $29,600–$33,740; mid proxy $39,990–$53,580",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, ME-ZOO, URI-W",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-WEC, ME-WE"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "Strong captive-animal application",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.0,
        2.9,
        1.1
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        29600,
        33740
      ],
      "midSalary": [
        39990,
        53580
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Enrichment Coordinator",
        "Enrichment Specialist",
        "Animal Welfare Specialist",
        "Behavioral Husbandry & Enrichment Manager",
        "Enrichment Manager"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0052",
      "name": "Environmental consultant — wildlife/ecology",
      "slug": "environmental-consultant-wildlife-ecology",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_env_consult",
        "name": "Environmental consulting & compliance",
        "description": "Environmental consulting, permitting, regulatory, and compliance biology."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Conducts biological surveys and analyses for clients, often related to development, permitting, environmental review, habitat, threatened species, mitigation, or compliance.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Statistics; data management; GIS/spatial methods where relevant; field ecology; regulatory/scientific writing; reproducible analysis; project documentation and communication.",
        "Searchable job titles": "Ecologist; Environmental Scientist; Wildlife Biologist; Biological Consultant",
        "Alternate names / terms": "Environmental Consultant; Ecological Consultant",
        "Typical education / progression": "B.S. common; M.S. helps for advanced work",
        "O*NET / BLS proxy": "Environmental Scientists and Specialists, Including Health (19-2041.00)",
        "Job outlook": "3%–4% (Average); ~8,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $52,520–$64,490; mid proxy $82,220–$107,970",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Strong professional fallback for wildlife/ecology degrees",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.6,
        1.5
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        52520,
        64490
      ],
      "midSalary": [
        82220,
        107970
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Ecological Consultant",
        "Environmental Consultant",
        "Biological Consultant",
        "Ecologist",
        "Environmental Scientist",
        "Wildlife Biologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0053",
      "name": "Environmental permitting / compliance biologist",
      "slug": "environmental-permitting-compliance-biologist",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_env_consult",
        "name": "Environmental consulting & compliance",
        "description": "Environmental consulting, permitting, regulatory, and compliance biology."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Evaluates projects against environmental and wildlife regulations, prepares permit documents, conducts biological assessments, coordinates surveys, and develops mitigation/compliance measures.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Statistics; data management; GIS/spatial methods where relevant; field ecology; regulatory/scientific writing; reproducible analysis; project documentation and communication.",
        "Searchable job titles": "Regulatory Permitting Biologist; Permitting Biologist; Environmental Compliance Biologist",
        "Alternate names / terms": "Regulatory Biologist; Environmental Permitting Specialist",
        "Typical education / progression": "B.S. common",
        "O*NET / BLS proxy": "Environmental Scientists and Specialists, Including Health (19-2041.00)",
        "Job outlook": "3%–4% (Average); ~8,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $52,520–$64,490; mid proxy $82,220–$107,970",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UMA-BIO",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Agency/consulting route",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.6,
        1.5
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        52520,
        64490
      ],
      "midSalary": [
        82220,
        107970
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Environmental Permitting Specialist",
        "Regulatory Biologist",
        "Environmental Compliance Biologist",
        "Permitting Biologist",
        "Regulatory Permitting Biologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0048",
      "name": "Evolutionary biologist studying animals",
      "slug": "evolutionary-biologist-studying-animals",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_evolution",
        "name": "Evolutionary & ecological science",
        "description": "Evolutionary biology and broad ecological science involving animals."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies evolutionary processes in animals using genetics, comparative biology, morphology, ecology, behavior, phylogenetics, or experimental approaches.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Broad animal biology; evolution/ecology/physiology; field or laboratory methods; statistics; species identification; scientific writing; faculty-mentored research.",
        "Searchable job titles": "Evolutionary Biologist; Evolutionary Ecologist; Research Scientist; Professor",
        "Alternate names / terms": "Animal Evolutionary Biologist; Evolutionary Zoologist",
        "Typical education / progression": "Ph.D. typical for independent research",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Research career normally requires graduate degree",
      "dims": [
        2.0,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        1.8,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Animal Evolutionary Biologist",
        "Evolutionary Zoologist",
        "Evolutionary Biologist",
        "Evolutionary Ecologist",
        "Professor",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0044",
      "name": "Field ecologist",
      "slug": "field-ecologist",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_evolution",
        "name": "Evolutionary & ecological science",
        "description": "Evolutionary biology and broad ecological science involving animals."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Collects and analyzes ecological data in natural systems, often combining species surveys, habitat measurements, experimental design, monitoring, and environmental reporting.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Broad animal biology; evolution/ecology/physiology; field or laboratory methods; statistics; species identification; scientific writing; faculty-mentored research.",
        "Searchable job titles": "Field Ecologist; Ecologist; Field Biologist",
        "Alternate names / terms": "Field Ecology Scientist; Ecological Field Biologist",
        "Typical education / progression": "B.S. common for entry roles",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Wildlife/ecology curricula particularly direct",
      "dims": [
        1.5,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        2.3,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Ecological Field Biologist",
        "Field Ecology Scientist",
        "Ecologist",
        "Field Biologist",
        "Field Ecologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0049",
      "name": "GIS / wildlife spatial analyst",
      "slug": "gis-wildlife-spatial-analyst",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_gis",
        "name": "GIS, remote sensing & spatial analysis",
        "description": "GIS, remote sensing, spatial analysis, and geospatial ecology."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses GIS and geospatial data to map and analyze habitat, movement, land use, species distributions, environmental change, and conservation priorities.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Wildlife/environmental agencies, consulting firms, conservation NGOs, universities, and geospatial teams supporting ecological projects.",
        "Undergraduate preparation most useful": "GIS, cartography, spatial databases, remote-sensing/spatial analysis basics, wildlife/ecology concepts, data QA, and clear map-based communication.",
        "Searchable job titles": "GIS Analyst; Geospatial Analyst; GIS Specialist; Spatial Analyst",
        "Alternate names / terms": "Wildlife GIS Analyst; Conservation GIS Analyst",
        "Typical education / progression": "B.S. common; strong GIS portfolio important",
        "O*NET / BLS proxy": "Geographic Information Systems Technologists and Technicians (15-1299.02)",
        "Job outlook": "7%+ (Much faster than average; parent occupation); ~31,300 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $55,940–$79,370; mid proxy $116,580–$157,500",
        "Proxy fit": "Low",
        "Strong/direct paths": "UMA-WEC, ME-WE, URI-W, URI-WZ",
        "Credible with planning": "UMA-BIO, ME-ZOO",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Dedicated wildlife programs provide strongest GIS/spatial preparation",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.1,
        1.5
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "variable",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        55940,
        79370
      ],
      "midSalary": [
        116580,
        157500
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Conservation GIS Analyst",
        "Wildlife GIS Analyst",
        "GIS Analyst",
        "GIS Specialist",
        "Geospatial Analyst",
        "Spatial Analyst"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_dir_0011",
          "career_id": "cr_0049",
          "title": "GIS Specialist",
          "organization": "U.S. Geological Survey - Northern Prairie Wildlife Research Center",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_npwrc",
          "notes": "Current federal GIS title.",
          "source": {
            "source_id": "src_usgs_npwrc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Northern Prairie Wildlife Research Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/northern-prairie-wildlife-research-center/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific/geospatial titles in federal wildlife research."
          }
        }
      ],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0039",
      "name": "Habitat / wildlife management biologist",
      "slug": "habitat-wildlife-management-biologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_habitat",
        "name": "Habitat & conservation delivery",
        "description": "Habitat biology, restoration delivery, conservation planning, and refuge management."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Plans and evaluates habitat or population management, using field data, vegetation/habitat measures, wildlife monitoring, GIS, and management objectives.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Wildlife Habitat Biologist; Habitat Biologist; Wildlife Management Specialist",
        "Alternate names / terms": "Habitat Management Biologist; Wildlife Manager",
        "Typical education / progression": "B.S./M.S. common",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-WEC, ME-WE, URI-W, URI-WZ",
        "Credible with planning": "UMA-BIO, ME-ZOO",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Population, habitat and agency-oriented work",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Habitat Management Biologist",
        "Wildlife Manager",
        "Habitat Biologist",
        "Wildlife Habitat Biologist",
        "Wildlife Management Specialist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0042",
          "career_id": "cr_0039",
          "title": "Assistant Regional Habitat Program Manager - Region 3",
          "organization": "Washington Department of Fish & Wildlife",
          "location": "Ellensburg, WA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Featured current TWS posting.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0042",
          "career_id": "cr_0039",
          "title": "Assistant Regional Habitat Program Manager - Region 3",
          "employer": "Washington Department of Fish & Wildlife",
          "location": "Ellensburg, WA",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/",
          "active_status": "current_or_recent",
          "notes": "Featured current TWS posting.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [
        {
          "relationship": "useful",
          "notes": "Useful professional wildlife credential.",
          "credential_id": "cred_tws_awb",
          "name": "Associate Wildlife Biologist®",
          "organization": "The Wildlife Society",
          "credential_type": "professional certification",
          "description": "Academic credential for wildlife professionals demonstrating qualifying coursework.",
          "source_id": "src_tws_cert",
          "source_url": "https://wildlife.org/tws-certifications/",
          "source_retrieved": "2026-09-08"
        }
      ],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0058",
      "name": "Habitat restoration / ecological-monitoring specialist",
      "slug": "habitat-restoration-ecological-monitoring-specialist",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_restoration",
        "name": "Restoration & ecological monitoring",
        "description": "Habitat restoration, ecological monitoring, and environmental field implementation."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Plans, implements, or evaluates restoration and monitoring projects using field ecology, vegetation/habitat methods, GIS, data analysis, and long-term performance measures.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Statistics; data management; GIS/spatial methods where relevant; field ecology; regulatory/scientific writing; reproducible analysis; project documentation and communication.",
        "Searchable job titles": "Habitat Restoration Specialist; Restoration Ecologist; Environmental Restoration Planner; Watershed Coordinator",
        "Alternate names / terms": "Ecological Monitoring Specialist; Restoration Specialist",
        "Typical education / progression": "B.S./M.S. common",
        "O*NET / BLS proxy": "Environmental Restoration Planners (19-2041.02)",
        "Job outlook": "3%–4% (Average; parent occupation); ~8,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $52,520–$64,490; mid proxy $82,220–$107,970",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UMA-BIO",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Field and habitat science emphasized",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.6,
        1.5
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        52520,
        64490
      ],
      "midSalary": [
        82220,
        107970
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Ecological Monitoring Specialist",
        "Restoration Specialist",
        "Environmental Restoration Planner",
        "Habitat Restoration Specialist",
        "Restoration Ecologist",
        "Watershed Coordinator"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0043",
      "name": "Herpetologist",
      "slug": "herpetologist",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_taxon",
        "name": "Taxon & natural-history specialists",
        "description": "Zoology and organismal specialties such as mammalogy, ornithology, and herpetology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Specializes in reptiles and amphibians through ecology, behavior, conservation, taxonomy, physiology, captive management, or collections work.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Broad animal biology; evolution/ecology/physiology; field or laboratory methods; statistics; species identification; scientific writing; faculty-mentored research.",
        "Searchable job titles": "Herpetologist; Curator of Herpetology; Amphibian/Reptile Biologist",
        "Alternate names / terms": "Herpetofaunal Biologist; Reptile/Amphibian Ecologist",
        "Typical education / progression": "M.S./Ph.D. common for specialist careers",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UNE-AB, UNE-AN, ME-WE",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, ME-ZOO, URI-W, URI-WZ",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "UMaine Zoology especially natural organismal route",
      "dims": [
        2.0,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        1.8,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Herpetofaunal Biologist",
        "Reptile/Amphibian Ecologist",
        "Amphibian/Reptile Biologist",
        "Curator of Herpetology",
        "Herpetologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0092",
      "name": "Human dimensions / conservation social scientist",
      "slug": "human-dimensions-conservation-social-scientist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_human_dimensions",
        "name": "Human-wildlife & social dimensions",
        "description": "Human-wildlife conflict and conservation social science."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "Established conservation specialty with verified government titles",
      "evidenceStatus": "verified_professional_role",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies how people perceive, value, use, or interact with wildlife and conservation, supporting conflict management, policy, public engagement, and conservation decisions.",
      "details": {
        "Typical work settings": "Wildlife agencies, USGS, universities, conservation NGOs, human-wildlife conflict programs.",
        "Undergraduate preparation most useful": "Wildlife/ecology, psychology or social science, survey/research methods, statistics, communication, policy.",
        "Searchable job titles": "Research Social Scientist; Human Dimensions Specialist; Wildlife Human Dimensions Scientist; Conservation Social Scientist",
        "Alternate names / terms": "Human dimensions of wildlife; conservation social science",
        "Typical education / progression": "Graduate training is common for independent research; applied outreach/conflict roles may be B.S.-accessible with strong field/communication experience.",
        "Job outlook": "No narrow benchmark; use social-science and wildlife/conservation postings.",
        "Salary context": "Use agency/university/NGO postings.",
        "Market status": "Established conservation specialty with verified government titles",
        "Career type": "Scientific Specialty"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        0.3,
        0.1,
        0.0,
        1.0,
        0.1,
        0.4,
        2.4,
        2.0,
        2.5,
        2.7
      ],
      "directContact": "Low",
      "educationBand": "Graduate degree often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Human dimensions of wildlife",
        "conservation social science",
        "Conservation Social Scientist",
        "Human Dimensions Specialist",
        "Research Social Scientist",
        "Wildlife Human Dimensions Scientist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0038",
      "name": "Human-wildlife conflict specialist",
      "slug": "human-wildlife-conflict-specialist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_human_dimensions",
        "name": "Human-wildlife & social dimensions",
        "description": "Human-wildlife conflict and conservation social science."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Develops science-based responses to conflicts between people and wildlife, including coexistence, damage prevention, public communication, policy, and field assessment.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Wildlife Conflict Specialist; Human-Wildlife Conflict Biologist; Wildlife Biologist",
        "Alternate names / terms": "Conflict Biologist; Wildlife Coexistence Specialist",
        "Typical education / progression": "B.S./M.S. common",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-WEC, ME-WE, URI-W, URI-WZ",
        "Credible with planning": "UMA-BIO, ME-ZOO",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Particularly natural in professional wildlife programs",
      "dims": [
        1.8,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Conflict Biologist",
        "Wildlife Coexistence Specialist",
        "Human-Wildlife Conflict Biologist",
        "Wildlife Biologist",
        "Wildlife Conflict Specialist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0065",
      "name": "M.S. / Ph.D. in animal welfare science",
      "slug": "m-s-ph-d-in-animal-welfare-science",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_grad",
        "name": "Graduate research pathways",
        "description": "Research M.S./Ph.D. routes into advanced science."
      },
      "roleKind": "education_path",
      "marketStatus": "EDU — Graduate-education pathway, not a job",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Graduate-study pathway focused on welfare assessment, behavior, physiology, husbandry, ethics, and evidence-based improvement of animal care.",
      "details": {
        "Market status": "EDU — Graduate-education pathway, not a job",
        "Career type": "Graduate-study pathway (not an occupation)",
        "Typical work settings": "Universities, research institutes, museums, government laboratories, conservation research programs, and other scientific organizations.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "N/A",
        "Alternate names / terms": "Graduate program in animal welfare science; applied animal behavior",
        "Typical education / progression": "Graduate education destination, not an occupation",
        "O*NET / BLS proxy": "N/A — education pathway",
        "Job outlook": "—",
        "Salary context": "—",
        "Proxy fit": "N/A",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-AS, ME-ZOO, URI-WZ, URI-AZ",
        "Weakly aligned paths": "UMA-WEC, ME-WE, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "N",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "N",
        "URI-WZ": "G"
      },
      "notes": "UNE and URI Zoo/Animal Science particularly natural",
      "dims": [
        1.9,
        1.2,
        1.0,
        1.9,
        0.5,
        3.0,
        2.1,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "High",
      "educationBand": "Graduate study pathway",
      "careerStage": "education",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Graduate program in animal welfare science",
        "applied animal behavior",
        "N/A"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0062",
      "name": "M.S. / Ph.D. in behavioral ecology",
      "slug": "m-s-ph-d-in-behavioral-ecology",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_grad",
        "name": "Graduate research pathways",
        "description": "Research M.S./Ph.D. routes into advanced science."
      },
      "roleKind": "education_path",
      "marketStatus": "EDU — Graduate-education pathway, not a job",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Graduate-study pathway emphasizing behavior in ecological/evolutionary context, usually with intensive research and quantitative analysis.",
      "details": {
        "Market status": "EDU — Graduate-education pathway, not a job",
        "Career type": "Graduate-study pathway (not an occupation)",
        "Typical work settings": "Universities, research institutes, museums, government laboratories, conservation research programs, and other scientific organizations.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "N/A",
        "Alternate names / terms": "Graduate program in behavioral ecology; behavior & evolution",
        "Typical education / progression": "Graduate education destination, not an occupation",
        "O*NET / BLS proxy": "N/A — education pathway",
        "Job outlook": "—",
        "Salary context": "—",
        "Proxy fit": "N/A",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-AS, URI-AZ",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "C",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "C",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Biology/wildlife/zoology routes especially strong",
      "dims": [
        1.9,
        0.7,
        1.0,
        1.9,
        0.5,
        3.0,
        2.1,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate study pathway",
      "careerStage": "education",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Graduate program in behavioral ecology",
        "behavior & evolution",
        "N/A"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0063",
      "name": "M.S. / Ph.D. in wildlife ecology / conservation",
      "slug": "m-s-ph-d-in-wildlife-ecology-conservation",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_grad",
        "name": "Graduate research pathways",
        "description": "Research M.S./Ph.D. routes into advanced science."
      },
      "roleKind": "education_path",
      "marketStatus": "EDU — Graduate-education pathway, not a job",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Graduate-study pathway for advanced wildlife, population, habitat, conservation, movement, or management research.",
      "details": {
        "Market status": "EDU — Graduate-education pathway, not a job",
        "Career type": "Graduate-study pathway (not an occupation)",
        "Typical work settings": "Universities, research institutes, museums, government laboratories, conservation research programs, and other scientific organizations.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "N/A",
        "Alternate names / terms": "Graduate program in wildlife ecology; conservation biology; wildlife science",
        "Typical education / progression": "Graduate education destination, not an occupation",
        "O*NET / BLS proxy": "N/A — education pathway",
        "Job outlook": "—",
        "Salary context": "—",
        "Proxy fit": "N/A",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UNE-AB, UNE-AN",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Dedicated wildlife routes strongest",
      "dims": [
        1.4,
        0.7,
        1.0,
        1.9,
        0.5,
        2.5,
        2.1,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate study pathway",
      "careerStage": "education",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Graduate program in wildlife ecology",
        "conservation biology",
        "wildlife science",
        "N/A"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0064",
      "name": "M.S. / Ph.D. in zoology / organismal biology",
      "slug": "m-s-ph-d-in-zoology-organismal-biology",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_grad",
        "name": "Graduate research pathways",
        "description": "Research M.S./Ph.D. routes into advanced science."
      },
      "roleKind": "education_path",
      "marketStatus": "EDU — Graduate-education pathway, not a job",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Graduate-study pathway for advanced animal biology, physiology, evolution, ecology, behavior, morphology, or integrative organismal science.",
      "details": {
        "Market status": "EDU — Graduate-education pathway, not a job",
        "Career type": "Graduate-study pathway (not an occupation)",
        "Typical work settings": "Universities, research institutes, museums, government laboratories, conservation research programs, and other scientific organizations.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "N/A",
        "Alternate names / terms": "Graduate program in zoology; organismal biology; integrative biology",
        "Typical education / progression": "Graduate education destination, not an occupation",
        "O*NET / BLS proxy": "N/A — education pathway",
        "Job outlook": "—",
        "Salary context": "—",
        "Proxy fit": "N/A",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Broadly reachable with suitable coursework/research",
      "dims": [
        1.9,
        0.7,
        1.0,
        1.9,
        0.5,
        3.0,
        2.1,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate study pathway",
      "careerStage": "education",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Graduate program in zoology",
        "integrative biology",
        "organismal biology",
        "N/A"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0061",
      "name": "M.S. in animal behavior / ethology",
      "slug": "m-s-in-animal-behavior-ethology",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_grad",
        "name": "Graduate research pathways",
        "description": "Research M.S./Ph.D. routes into advanced science."
      },
      "roleKind": "education_path",
      "marketStatus": "EDU — Graduate-education pathway, not a job",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Graduate-study pathway for deeper work in behavior, ethology, cognition, welfare, learning, communication, or related research.",
      "details": {
        "Market status": "EDU — Graduate-education pathway, not a job",
        "Career type": "Graduate-study pathway (not an occupation)",
        "Typical work settings": "Universities, research institutes, museums, government laboratories, conservation research programs, and other scientific organizations.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "N/A",
        "Alternate names / terms": "Graduate program in animal behavior; ethology; comparative behavior",
        "Typical education / progression": "Graduate education destination, not an occupation",
        "O*NET / BLS proxy": "N/A — education pathway",
        "Job outlook": "—",
        "Salary context": "—",
        "Proxy fit": "N/A",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "All can lead there; preparation emphasis differs",
      "dims": [
        1.9,
        1.2,
        1.0,
        1.9,
        0.5,
        2.5,
        2.1,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate study pathway",
      "careerStage": "education",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Graduate program in animal behavior",
        "comparative behavior",
        "ethology",
        "N/A"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0041",
      "name": "Mammalogist",
      "slug": "mammalogist",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_taxon",
        "name": "Taxon & natural-history specialists",
        "description": "Zoology and organismal specialties such as mammalogy, ornithology, and herpetology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Specializes in mammals, often through field ecology, behavior, taxonomy, conservation, collections, physiology, or population research.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Broad animal biology; evolution/ecology/physiology; field or laboratory methods; statistics; species identification; scientific writing; faculty-mentored research.",
        "Searchable job titles": "Mammalogist; Mammal Ecologist; Mammal Biologist",
        "Alternate names / terms": "Mammalian Ecologist; Mammal Researcher",
        "Typical education / progression": "M.S./Ph.D. common for specialist careers",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UNE-AB, UNE-AN",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Professional specialist roles commonly graduate-level",
      "dims": [
        2.0,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        1.8,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Mammal Researcher",
        "Mammalian Ecologist",
        "Mammal Biologist",
        "Mammal Ecologist",
        "Mammalogist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0036",
      "name": "Movement / spatial ecologist",
      "slug": "movement-spatial-ecologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_movement",
        "name": "Movement, monitoring & spatial ecology",
        "description": "Movement ecology, telemetry, spatial ecology, and post-release monitoring."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies how animals move through landscapes or seascapes using telemetry, GPS, GIS, spatial statistics, and movement models to understand migration, habitat use, connectivity, and risk.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Movement Ecologist; Spatial Ecologist; Spatial Wildlife Ecologist; Movement Biologist",
        "Alternate names / terms": "Movement Ecology Scientist; Spatial Biologist",
        "Typical education / progression": "M.S./Ph.D. commonly",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UNE-AB, UNE-AN",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "GIS, telemetry and quantitative ecology valuable",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Movement Ecology Scientist",
        "Spatial Biologist",
        "Movement Biologist",
        "Movement Ecologist",
        "Spatial Ecologist",
        "Spatial Wildlife Ecologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0073",
      "name": "Museum / natural-history education or collections work",
      "slug": "museum-natural-history-education-or-collections-work",
      "category": "Education, outreach & science communication",
      "domain": {
        "id": "dm_education",
        "name": "Education, outreach & communication",
        "description": "Interpretation, education, outreach, museums, collections, and science communication."
      },
      "roleFamily": {
        "id": "rf_scicomm",
        "name": "Science communication & museum work",
        "description": "Science writing, communication, natural-history museums, and collections."
      },
      "roleKind": "education_path",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Supports natural-history collections, specimen care, databases, curation, research access, exhibitions, and/or public education; advanced curator roles often require graduate training.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "Mixed entry path; assistant roles may be B.S.-level, scientist roles generally graduate-level",
        "Typical work settings": "Natural-history museums, university museums/collections, herbaria/zoological collections, research collections, and public education departments.",
        "Undergraduate preparation most useful": "Strong biological content knowledge; writing and presentation; audience-centered communication; interpretation/teaching; program organization; research literacy.",
        "Searchable job titles": "Collections Manager; Museum Technician; Collections Assistant; Museum Educator; Vertebrate Zoology Curator",
        "Alternate names / terms": "Natural History Collections Specialist; Collections Technician",
        "Typical education / progression": "B.S. for technician roles; M.S./Ph.D. often for curator roles",
        "O*NET / BLS proxy": "Museum Technicians and Conservators (25-4013.00)",
        "Job outlook": "5%–6% (Faster than average); ~1,900 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $33,780–$41,050; mid proxy $51,440–$67,640",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UMA-BIO, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, UMA-WEC, ME-WE",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "C",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Zoology/biology/organismal backgrounds especially useful",
      "dims": [
        1.3,
        0.5,
        1.2,
        1.3,
        0.3,
        1.5,
        1.7,
        1.3,
        1.4,
        3.0
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate study pathway",
      "careerStage": "education",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Education / public",
        "Research"
      ],
      "entrySalary": [
        33780,
        41050
      ],
      "midSalary": [
        51440,
        67640
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Collections Technician",
        "Natural History Collections Specialist",
        "Collections Assistant",
        "Collections Manager",
        "Museum Educator",
        "Museum Technician",
        "Vertebrate Zoology Curator"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0054",
      "name": "Natural-resource agency biologist",
      "slug": "natural-resource-agency-biologist",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_agency",
        "name": "Natural-resource agency & management",
        "description": "Agency biology, park/resource work, natural-resource management, and program management."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Works in government on wildlife, fisheries, habitat, monitoring, restoration, regulation, research, or resource-management programs.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Statistics; data management; GIS/spatial methods where relevant; field ecology; regulatory/scientific writing; reproducible analysis; project documentation and communication.",
        "Searchable job titles": "Wildlife Biologist; Fish & Wildlife Biologist; Biological Scientist; Habitat Biologist",
        "Alternate names / terms": "Agency Biologist; Natural Resources Biologist",
        "Typical education / progression": "B.S. common; exact federal/state coursework rules may apply",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "State/federal natural-resource careers",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.8,
        3.0,
        3.0,
        2.6,
        1.5
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": {
        "count": 2,
        "observedMin": 89508,
        "observedMax": 126502,
        "medianLow": 93408,
        "medianHigh": 121432,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Agency Biologist",
        "Natural Resources Biologist",
        "Biological Scientist",
        "Fish & Wildlife Biologist",
        "Habitat Biologist",
        "Wildlife Biologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0057",
          "career_id": "cr_0054",
          "title": "Fish and Wildlife Biologist",
          "organization": "U.S. Fish and Wildlife Service",
          "location": "State College, PA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_usajobs_fwbio",
          "notes": "GS-12 0401 biological-sciences position.",
          "source": {
            "source_id": "src_usajobs_fwbio",
            "organization": "U.S. Fish and Wildlife Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Fish and Wildlife Biologist - State College",
            "url": "https://www.usajobs.gov/job/882387200",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-12 fish and wildlife biologist posting."
          }
        },
        {
          "observed_id": "obs_post_0058",
          "career_id": "cr_0054",
          "title": "Senior Fish and Wildlife Biologist",
          "organization": "U.S. Fish and Wildlife Service",
          "location": "Fort Worth, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_usajobs_seniorbio",
          "notes": "GS-12 senior ecological-services position.",
          "source": {
            "source_id": "src_usajobs_seniorbio",
            "organization": "U.S. Fish and Wildlife Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Senior Fish and Wildlife Biologist - Fort Worth",
            "url": "https://doi.usajobs.gov/job/882813600",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-12 senior fish and wildlife biologist posting."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0057",
          "career_id": "cr_0054",
          "title": "Fish and Wildlife Biologist",
          "employer": "U.S. Fish and Wildlife Service",
          "location": "State College, PA",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": 89508.0,
          "salary_max": 116362.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_usajobs_fwbio",
          "url": "https://www.usajobs.gov/job/882387200",
          "active_status": "current_or_recent",
          "notes": "GS-12 0401 biological-sciences position.",
          "source": {
            "source_id": "src_usajobs_fwbio",
            "organization": "U.S. Fish and Wildlife Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Fish and Wildlife Biologist - State College",
            "url": "https://www.usajobs.gov/job/882387200",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-12 fish and wildlife biologist posting."
          }
        },
        {
          "posting_id": "post_0058",
          "career_id": "cr_0054",
          "title": "Senior Fish and Wildlife Biologist",
          "employer": "U.S. Fish and Wildlife Service",
          "location": "Fort Worth, TX",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": 97307.0,
          "salary_max": 126502.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_usajobs_seniorbio",
          "url": "https://doi.usajobs.gov/job/882813600",
          "active_status": "current_or_recent",
          "notes": "GS-12 senior ecological-services position.",
          "source": {
            "source_id": "src_usajobs_seniorbio",
            "organization": "U.S. Fish and Wildlife Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Senior Fish and Wildlife Biologist - Fort Worth",
            "url": "https://doi.usajobs.gov/job/882813600",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-12 senior fish and wildlife biologist posting."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0055",
      "name": "Natural-resource manager",
      "slug": "natural-resource-manager",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_agency",
        "name": "Natural-resource agency & management",
        "description": "Agency biology, park/resource work, natural-resource management, and program management."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Coordinates management of land, wildlife, habitat, recreation, or conservation programs using science, policy, planning, staff/contract management, and stakeholder communication.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Statistics; data management; GIS/spatial methods where relevant; field ecology; regulatory/scientific writing; reproducible analysis; project documentation and communication.",
        "Searchable job titles": "Natural Resource Specialist; Resource Manager; Conservation Scientist; Refuge Manager",
        "Alternate names / terms": "Natural Resources Manager; Resource Conservation Manager",
        "Typical education / progression": "B.S./M.S. plus experience",
        "O*NET / BLS proxy": "Conservation Scientists (19-1031.00)",
        "Job outlook": "3%–4% (Average); ~2,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $47,550–$57,700; mid proxy $73,010–$91,560",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-WEC, ME-WE, URI-W, URI-WZ",
        "Credible with planning": "UMA-BIO, ME-ZOO",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Management/policy/ecology blend",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.6,
        1.5
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "leadership",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        47550,
        57700
      ],
      "midSalary": [
        73010,
        91560
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Natural Resources Manager",
        "Resource Conservation Manager",
        "Conservation Scientist",
        "Natural Resource Specialist",
        "Refuge Manager",
        "Resource Manager"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0070",
      "name": "Naturalist / interpretive educator",
      "slug": "naturalist-interpretive-educator",
      "category": "Education, outreach & science communication",
      "domain": {
        "id": "dm_education",
        "name": "Education, outreach & communication",
        "description": "Interpretation, education, outreach, museums, collections, and science communication."
      },
      "roleFamily": {
        "id": "rf_wildlife_education",
        "name": "Wildlife interpretation & outreach",
        "description": "Wildlife/environmental education, naturalist work, and conservation outreach."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Interprets natural history for visitors through guided walks, talks, exhibits, field programs, species identification, and place-based ecological education.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, museums, parks/refuges, nature centers, schools, NGOs, government outreach programs, publishers, and scientific organizations.",
        "Undergraduate preparation most useful": "Strong biological content knowledge; writing and presentation; audience-centered communication; interpretation/teaching; program organization; research literacy.",
        "Searchable job titles": "Interpretive Naturalist; Naturalist; Park Interpreter; Interpretive Ranger",
        "Alternate names / terms": "Nature Interpreter; Interpretive Specialist",
        "Typical education / progression": "B.S. common; some roles accept relevant experience",
        "O*NET / BLS proxy": "Park Naturalists (19-1031.03)",
        "Job outlook": "3%–4% (Average; Conservation Scientists proxy); ~2,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $47,550–$57,700; mid proxy $73,010–$91,560",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, URI-AZ",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Parks, refuges, nature centers, NGOs",
      "dims": [
        1.3,
        0.5,
        1.2,
        1.8,
        0.3,
        1.0,
        2.2,
        0.8,
        1.4,
        3.0
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Education / public",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        47550,
        57700
      ],
      "midSalary": [
        73010,
        91560
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Interpretive Specialist",
        "Nature Interpreter",
        "Interpretive Naturalist",
        "Interpretive Ranger",
        "Naturalist",
        "Park Interpreter"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0032",
          "career_id": "cr_0070",
          "title": "Habitat Interpreter",
          "organization": "Mystic Aquarium",
          "location": "Mystic, CT",
          "observation_type": "job_posting",
          "observed_date": "2026-05-22",
          "source_id": "src_aza_jobs",
          "notes": "Observed interpretation title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0032",
          "career_id": "cr_0070",
          "title": "Habitat Interpreter",
          "employer": "Mystic Aquarium",
          "location": "Mystic, CT",
          "posted_date": "2026-05-22",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/jobs?job=50913",
          "active_status": "current_or_recent",
          "notes": "Observed interpretation title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0047",
      "name": "Neuroethologist / neural-behavior researcher",
      "slug": "neuroethologist-neural-behavior-researcher",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_physiology",
        "name": "Physiology & neuroethology",
        "description": "Animal physiology, neuroethology, and mechanisms of behavior."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Investigates how nervous systems generate natural behavior, linking neural mechanisms with sensory processing, movement, communication, learning, or species-typical behavior.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Behavioral experimentation, neurobiology/neuroscience, physiology, statistics, experimental design, and comparative/evolutionary thinking.",
        "Searchable job titles": "Neuroethologist; Behavioral Neuroscientist; Research Scientist; Professor",
        "Alternate names / terms": "Neural Behavior Researcher; Comparative Neuroscientist",
        "Typical education / progression": "Ph.D. typical for independent research",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "URI-WZ",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-AS, ME-ZOO, URI-AZ",
        "Weakly aligned paths": "UMA-WEC, ME-WE, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "N",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "N",
        "URI-WZ": "C"
      },
      "notes": "Neuroscience + behavior integration; generally graduate-level",
      "dims": [
        2.0,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        1.8,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "variable",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Comparative Neuroscientist",
        "Neural Behavior Researcher",
        "Behavioral Neuroscientist",
        "Neuroethologist",
        "Professor",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_neuro",
          "name": "Neuroscience & neuroethology",
          "category": "Biological mechanisms",
          "description": "Neural mechanisms of behavior.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0042",
      "name": "Ornithologist",
      "slug": "ornithologist",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_taxon",
        "name": "Taxon & natural-history specialists",
        "description": "Zoology and organismal specialties such as mammalogy, ornithology, and herpetology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "F — Established scientific specialty; payroll title usually differs",
      "evidenceStatus": "established_scientific_specialty",
      "lastVerified": "2026-09-08",
      "roleFocus": "Specializes in birds, commonly through field surveys, migration, behavior, population ecology, conservation, bioacoustics, or museum research.",
      "details": {
        "Market status": "F — Established scientific specialty; payroll title usually differs",
        "Career type": "Scientific specialty; independent roles are usually graduate-level",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Broad animal biology; evolution/ecology/physiology; field or laboratory methods; statistics; species identification; scientific writing; faculty-mentored research.",
        "Searchable job titles": "Ornithologist; Avian Ecologist; Avian Biologist",
        "Alternate names / terms": "Bird Ecologist; Avian Researcher",
        "Typical education / progression": "M.S./Ph.D. common for specialist careers",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UNE-AB, UNE-AN",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Same",
      "dims": [
        2.0,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        1.8,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Avian Researcher",
        "Bird Ecologist",
        "Avian Biologist",
        "Avian Ecologist",
        "Ornithologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0056",
      "name": "Park / service biologist or resource specialist",
      "slug": "park-service-biologist-or-resource-specialist",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_agency",
        "name": "Natural-resource agency & management",
        "description": "Agency biology, park/resource work, natural-resource management, and program management."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Monitors and protects natural resources in parks, refuges, preserves, or public lands through field science, management, restoration, visitor-impact assessment, and planning.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Statistics; data management; GIS/spatial methods where relevant; field ecology; regulatory/scientific writing; reproducible analysis; project documentation and communication.",
        "Searchable job titles": "Natural Resource Specialist; Park Biologist; Resource Management Specialist; Wildlife Biologist",
        "Alternate names / terms": "Park Resource Specialist; Natural Resource Biologist",
        "Typical education / progression": "B.S. common; federal/state requirements vary",
        "O*NET / BLS proxy": "Park Naturalists (19-1031.03)",
        "Job outlook": "3%–4% (Average; Conservation Scientists proxy); ~2,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $47,550–$57,700; mid proxy $73,010–$91,560",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "NPS/refuge/park-resource type work",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.6,
        2.0
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        47550,
        57700
      ],
      "midSalary": [
        73010,
        91560
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Natural Resource Biologist",
        "Park Resource Specialist",
        "Natural Resource Specialist",
        "Park Biologist",
        "Resource Management Specialist",
        "Wildlife Biologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0074",
      "name": "Population biologist / zoo population management scientist",
      "slug": "population-biologist-zoo-population-management-scientist",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_population",
        "name": "Conservation breeding & population management",
        "description": "Conservation breeding, population biology, studbooks, and SSP population-management work."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "Established professional/scientific role; payroll titles vary",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses demographic, genetic, and population analyses to assess managed conservation populations, forecast population trajectories, and develop breeding/transfer recommendations for zoo and aquarium populations.",
      "details": {
        "Typical work settings": "AZA population-management programs, zoological institutions, conservation science centers, universities.",
        "Undergraduate preparation most useful": "Population biology, genetics, statistics, research design, data management, conservation biology, scientific writing.",
        "Searchable job titles": "Population Biologist; Population Management Scientist; Wildlife Planning Manager; Population Management Researcher",
        "Alternate names / terms": "Population management; demographic analysis; managed population planning",
        "Typical education / progression": "Strong quantitative B.S. foundation; M.S./Ph.D. commonly useful for independent population-science roles.",
        "O*NET / BLS proxy": "Biological Scientists / Zoologists-Wildlife Biologists (broad proxy)",
        "Job outlook": "No dedicated federal occupation; use current postings and related biological-science benchmarks.",
        "Salary context": "Use current postings, institutional salary data, and related biological-scientist benchmarks.",
        "Market status": "Established professional/scientific role; payroll titles vary",
        "Career type": "Scientific Specialty"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "G",
        "UMA-AS": "C",
        "UMA-BIO": "G",
        "UMA-WEC": "C",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "C",
        "URI-WZ": "C"
      },
      "notes": "",
      "dims": [
        1.2,
        0.8,
        2.2,
        1.0,
        0.5,
        2.2,
        2.5,
        3.0,
        3.0,
        0.9
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Population management",
        "demographic analysis",
        "managed population planning",
        "Population Biologist",
        "Population Management Researcher",
        "Population Management Scientist",
        "Wildlife Planning Manager"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0028",
          "career_id": "cr_0074",
          "title": "Manager, Wildlife Planning",
          "organization": "Toronto Zoo",
          "location": "Scarborough, ON",
          "observation_type": "job_posting",
          "observed_date": "2026-04-16",
          "source_id": "src_aza_jobs",
          "notes": "Observed zoo wildlife-planning title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0028",
          "career_id": "cr_0074",
          "title": "Manager, Wildlife Planning",
          "employer": "Toronto Zoo",
          "location": "Scarborough, ON",
          "posted_date": "2026-04-16",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/jobs?job=49490",
          "active_status": "current_or_recent",
          "notes": "Observed zoo wildlife-planning title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0009",
          "entity_type": "career",
          "entity_id": "cr_0074",
          "claim_type": "market_structure",
          "claim_value": "AZA Population Management Center staff include Population Biologists, a Planning Coordinator, and research support who conduct demographic/genetic analyses for SSP programs.",
          "source_id": "src_aza_pmc",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_aza_pmc",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "professional_reference",
            "title": "Population Management Center",
            "url": "https://www.aza.org/population-management-center",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Population biologists, planning coordinator, research support, and managed-population planning."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0035",
      "name": "Population ecologist",
      "slug": "population-ecologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_wildlife_biology",
        "name": "Wildlife biology & management",
        "description": "Professional wildlife biology, nongame/diversity biology, and wildlife program work."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses demographic, statistical, and modeling approaches to understand population size, survival, reproduction, trends, density dependence, and responses to management or environment.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Population Ecologist; Population Biologist; Wildlife Population Biologist; Quantitative Ecologist",
        "Alternate names / terms": "Population Dynamics Ecologist; Population Scientist",
        "Typical education / progression": "M.S./Ph.D. usually",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Quantitative graduate specialization",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Population Dynamics Ecologist",
        "Population Scientist",
        "Population Biologist",
        "Population Ecologist",
        "Quantitative Ecologist",
        "Wildlife Population Biologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0031",
      "name": "Post-release monitoring biologist",
      "slug": "post-release-monitoring-biologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_reintroduction",
        "name": "Species recovery & reintroduction",
        "description": "Release, reintroduction, post-release monitoring, and species recovery."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Evaluates survival, movement, behavior, habitat use, reproduction, and adaptation after translocation or release using telemetry, surveys, observations, and quantitative analysis.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Telemetry/GPS monitoring, behavioral observation, field logistics, survival/movement analysis, data management, species natural history, and scientific reporting.",
        "Searchable job titles": "Monitoring Biologist; Reintroduction Biologist; Field Biologist; Telemetry Technician",
        "Alternate names / terms": "Post-Release Monitor; Release Monitoring Biologist",
        "Typical education / progression": "B.S./M.S. depending responsibility",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Wildlife field methods and quantitative training important",
      "dims": [
        1.8,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Post-Release Monitor",
        "Release Monitoring Biologist",
        "Field Biologist",
        "Monitoring Biologist",
        "Reintroduction Biologist",
        "Telemetry Technician"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_release",
          "name": "Reintroduction & release",
          "category": "Applied conservation",
          "description": "Release planning, reintroduction, translocation, and post-release evaluation.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0051",
      "name": "Quantitative ecologist / biometrician",
      "slug": "quantitative-ecologist-biometrician",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_quant",
        "name": "Quantitative ecology & data science",
        "description": "Statistics, ecological modeling, data science, and quantitative ecology."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Develops and applies statistical models to ecological, wildlife, fisheries, or conservation data, often addressing abundance, survival, movement, occupancy, population dynamics, or decision-making.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Advanced statistics, ecological modeling, study design, data management, coding/reproducible analysis, and enough ecology/wildlife knowledge to choose and interpret appropriate models.",
        "Searchable job titles": "Quantitative Ecologist; Biometrician; Biostatistician; Ecological Statistician",
        "Alternate names / terms": "Quantitative Biologist; Ecological Modeler",
        "Typical education / progression": "M.S./Ph.D. common",
        "O*NET / BLS proxy": "Biostatisticians (15-2041.01)",
        "Job outlook": "7%+ (Much faster than average); ~2,000 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $64,000–$82,220; mid proxy $105,650–$141,490",
        "Proxy fit": "High",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Weakly aligned paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "N",
        "UNE-AN": "N",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Usually substantial graduate quantitative training",
      "dims": [
        0.5,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.6,
        1.5
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        64000,
        82220
      ],
      "midSalary": [
        105650,
        141490
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Ecological Modeler",
        "Quantitative Biologist",
        "Biometrician",
        "Biostatistician",
        "Ecological Statistician",
        "Quantitative Ecologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0050",
      "name": "Quantitative ecology research assistant",
      "slug": "quantitative-ecology-research-assistant",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_quant",
        "name": "Quantitative ecology & data science",
        "description": "Statistics, ecological modeling, data science, and quantitative ecology."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Supports ecology projects requiring substantial statistics, data management, modeling, reproducible analysis, or database work in addition to biological understanding.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Government agencies, environmental consulting firms, conservation NGOs, universities, parks/refuges, engineering/environmental firms, and research programs.",
        "Undergraduate preparation most useful": "Statistics; data management; GIS/spatial methods where relevant; field ecology; regulatory/scientific writing; reproducible analysis; project documentation and communication.",
        "Searchable job titles": "Research Assistant; Quantitative Research Assistant; Data/Research Technician",
        "Alternate names / terms": "Quantitative Ecology RA; Ecological Data Technician",
        "Typical education / progression": "B.S. common",
        "O*NET / BLS proxy": "Biological Technicians (19-4021.00)",
        "Job outlook": "3%–4% (Average); ~9,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $40,330–$48,130; mid proxy $57,510–$71,520",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, UMA-AS, URI-AZ",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "C",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Applied statistics/research role possible after B.S.",
      "dims": [
        1.0,
        0.3,
        0.7,
        2.2,
        0.4,
        1.3,
        3.0,
        3.0,
        2.6,
        1.5
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        40330,
        48130
      ],
      "midSalary": [
        57510,
        71520
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Ecological Data Technician",
        "Quantitative Ecology RA",
        "Data/Research Technician",
        "Quantitative Research Assistant",
        "Research Assistant"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_dir_0012",
          "career_id": "cr_0050",
          "title": "Wildlife Data Assistant",
          "organization": "U.S. Geological Survey - Bird Banding Laboratory",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_eesc",
          "notes": "Current wildlife-data support title.",
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0030",
      "name": "Reintroduction / release field technician",
      "slug": "reintroduction-release-field-technician",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_reintroduction",
        "name": "Species recovery & reintroduction",
        "description": "Release, reintroduction, post-release monitoring, and species recovery."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Supports the release or reintroduction of animals by preparing sites, assisting handling/transport, tracking released animals, documenting survival/behavior, and maintaining field equipment.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field logistics, animal handling where permitted, telemetry/monitoring, behavioral observation, release protocols, recordkeeping, and teamwork under variable field conditions.",
        "Searchable job titles": "Reintroduction Biologist; Reintroduction Technician; Field Technician; Conservation Biologist",
        "Alternate names / terms": "Release Technician; Species Reintroduction Technician",
        "Typical education / progression": "B.S. typical for entry field roles",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Strong overlap with field ecology, behavior and monitoring",
      "dims": [
        1.8,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Release Technician",
        "Species Reintroduction Technician",
        "Conservation Biologist",
        "Field Technician",
        "Reintroduction Biologist",
        "Reintroduction Technician"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_release",
          "name": "Reintroduction & release",
          "category": "Applied conservation",
          "description": "Release planning, reintroduction, translocation, and post-release evaluation.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0091",
      "name": "Remote sensing / geospatial ecologist",
      "slug": "remote-sensing-geospatial-ecologist",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_gis",
        "name": "GIS, remote sensing & spatial analysis",
        "description": "GIS, remote sensing, spatial analysis, and geospatial ecology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "Established professional/scientific role; titles vary",
      "evidenceStatus": "verified_professional_role",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses satellite, aerial, drone, GIS, and other spatial data to study wildlife habitat, landscape change, movement, distribution, or conservation priorities.",
      "details": {
        "Typical work settings": "USGS, wildlife agencies, conservation NGOs, universities, environmental consulting, remote-sensing programs.",
        "Undergraduate preparation most useful": "GIS, remote sensing, statistics, ecology, programming, spatial analysis, field validation.",
        "Searchable job titles": "Geospatial Ecologist; Remote Sensing Ecologist; GIS Specialist; Spatial Ecologist; Geospatial Scientist",
        "Alternate names / terms": "Landscape ecology; spatial ecology; remote sensing",
        "Typical education / progression": "B.S. can support GIS analyst roles; advanced ecological interpretation/modeling often benefits from graduate study.",
        "Job outlook": "Use GIS/geospatial and environmental-science benchmarks cautiously.",
        "Salary context": "Posting-specific ecology/geospatial salaries are preferable to broad computer-occupation proxies.",
        "Market status": "Established professional/scientific role; titles vary",
        "Career type": "Scientific Specialty"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        0.2,
        0.0,
        0.0,
        1.8,
        0.1,
        0.8,
        2.3,
        3.0,
        2.5,
        0.5
      ],
      "directContact": "Low",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Landscape ecology",
        "remote sensing",
        "spatial ecology",
        "GIS Specialist",
        "Geospatial Ecologist",
        "Geospatial Scientist",
        "Remote Sensing Ecologist",
        "Spatial Ecologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0060",
      "name": "Research / laboratory manager — behavioral or biological science",
      "slug": "research-laboratory-manager-behavioral-or-biological-science",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_research_support",
        "name": "Research support & lab operations",
        "description": "Research assistants, technicians, laboratory managers, and research coordination."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Coordinates day-to-day research operations, protocols, supplies, personnel, records, equipment, compliance, training, and sometimes data collection/analysis.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Universities, research institutes, museums, government laboratories, conservation research programs, and other scientific organizations.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "Lab Manager; Laboratory Manager; Research Manager; Research Administrator",
        "Alternate names / terms": "Research Lab Manager; Laboratory Operations Manager",
        "Typical education / progression": "B.S. + substantial experience or M.S. common",
        "O*NET / BLS proxy": "Natural Sciences Managers (11-9121.00)",
        "Job outlook": "3%–4% (Average); ~8,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $79,710–$119,430; mid proxy $167,220–$221,540",
        "Proxy fit": "Low",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-BIO, UMA-AS, ME-ZOO, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-WEC, ME-WE, URI-W",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "S",
        "UMA-AS": "S",
        "UMA-BIO": "S",
        "UMA-WEC": "C",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "Usually requires substantial undergraduate/post-B.S. lab experience",
      "dims": [
        1.9,
        0.7,
        1.0,
        1.9,
        0.5,
        2.5,
        2.1,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "leadership",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        79710,
        119430
      ],
      "midSalary": [
        167220,
        221540
      ],
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 50000,
        "observedMax": 60000,
        "medianLow": 50000,
        "medianHigh": 60000,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Laboratory Operations Manager",
        "Research Lab Manager",
        "Lab Manager",
        "Laboratory Manager",
        "Research Administrator",
        "Research Manager"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_dir_0008",
          "career_id": "cr_0060",
          "title": "Biologist, Lab Manager",
          "organization": "U.S. Geological Survey - EESC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_eesc",
          "notes": "Current federal lab-management title.",
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        },
        {
          "observed_id": "obs_post_0036",
          "career_id": "cr_0060",
          "title": "Quail Research Laboratory Manager",
          "organization": "East Texas A&M University",
          "location": "Commerce, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_labmanager",
          "notes": "Current wildlife research lab manager posting.",
          "source": {
            "source_id": "src_tws_labmanager",
            "organization": "East Texas A&M University / TWS",
            "source_type": "job_posting",
            "title": "Quail Research Laboratory Manager",
            "url": "https://careers.wildlife.org/jobs/function/Wildlife/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Research laboratory manager posting with salary and B.S. requirement."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0036",
          "career_id": "cr_0060",
          "title": "Quail Research Laboratory Manager",
          "employer": "East Texas A&M University",
          "location": "Commerce, TX",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "B.A./B.S.",
          "experience_min": "1–2 years",
          "salary_min": 50000.0,
          "salary_max": 60000.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_labmanager",
          "url": "https://careers.wildlife.org/jobs/function/Wildlife/",
          "active_status": "current_or_recent",
          "notes": "Current wildlife research lab manager posting.",
          "source": {
            "source_id": "src_tws_labmanager",
            "organization": "East Texas A&M University / TWS",
            "source_type": "job_posting",
            "title": "Quail Research Laboratory Manager",
            "url": "https://careers.wildlife.org/jobs/function/Wildlife/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Research laboratory manager posting with salary and B.S. requirement."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0087",
      "name": "Research ecologist",
      "slug": "research-ecologist",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_evolution",
        "name": "Evolutionary & ecological science",
        "description": "Evolutionary biology and broad ecological science involving animals."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "Verified federal/institutional title",
      "evidenceStatus": "verified_professional_role",
      "lastVerified": "2026-09-08",
      "roleFocus": "Conducts ecological research on species, populations, communities, habitats, landscapes, or environmental change, often using field data, experiments, models, or long-term monitoring.",
      "details": {
        "Typical work settings": "USGS science centers, universities, agencies, NGOs, environmental research organizations.",
        "Undergraduate preparation most useful": "Ecology, statistics, research design, field methods, GIS, scientific writing, programming/data analysis.",
        "Searchable job titles": "Research Ecologist; Ecologist; Supervisory Research Ecologist",
        "Alternate names / terms": "Applied ecologist; ecological scientist",
        "Typical education / progression": "B.S. supports research-assistant/technician roles; Ph.D. is common for independent federal/university research ecologist positions.",
        "O*NET / BLS proxy": "Biological Scientists / Environmental Scientists (broad proxy)",
        "Job outlook": "Use federal ecology series and biological/environmental-science benchmarks.",
        "Salary context": "Use federal/institutional research postings and related scientific benchmarks.",
        "Market status": "Verified federal/institutional title",
        "Career type": "Scientific Specialty"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "N",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "",
      "dims": [
        0.8,
        0.2,
        0.1,
        2.2,
        0.3,
        2.2,
        2.5,
        2.7,
        3.0,
        0.8
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Applied ecologist",
        "ecological scientist",
        "Ecologist",
        "Research Ecologist",
        "Supervisory Research Ecologist"
      ],
      "competencies": [
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_dir_0003",
          "career_id": "cr_0087",
          "title": "Research Ecologist",
          "organization": "U.S. Geological Survey - EESC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_eesc",
          "notes": "Current federal research title.",
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        },
        {
          "observed_id": "obs_dir_0004",
          "career_id": "cr_0087",
          "title": "Supervisory Research Ecologist",
          "organization": "U.S. Geological Survey - WERC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_werc",
          "notes": "Supervisory research ecology title.",
          "source": {
            "source_id": "src_usgs_werc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Western Ecological Research Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/werc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "recentPostings": [],
      "evidence": [
        {
          "evidence_id": "ev_0019",
          "entity_type": "career",
          "entity_id": "cr_0087",
          "claim_type": "market_title",
          "claim_value": "USGS ecological science centers employ Research Ecologist and Supervisory Research Ecologist roles.",
          "source_id": "src_usgs_eesc",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        },
        {
          "evidence_id": "ev_0004",
          "entity_type": "career",
          "entity_id": "cr_0087",
          "claim_type": "qualification",
          "claim_value": "Federal GS-0408 requires 30 biological-science hours including 9 ecology and 12 physical/mathematical sciences.",
          "source_id": "src_opm_0408",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_opm_0408",
            "organization": "U.S. Office of Personnel Management",
            "source_type": "qualification_standard",
            "title": "Ecology Series 0408",
            "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/ecology-series-0408/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Federal ecology education requirements."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": [
        {
          "qualification_id": "qual_0408",
          "career_id": "cr_0087",
          "organization": "U.S. Office of Personnel Management",
          "series_code": "0408",
          "name": "Federal Ecology Series 0408",
          "education_requirement": "Degree in biology or related field underlying ecological research.",
          "coursework_requirement": "At least 30 semester hours biological sciences, including 9 ecology and 12 physical/mathematical sciences.",
          "experience_requirement": "Grade-specific experience/graduate education applies.",
          "source_id": "src_opm_0408",
          "source_url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/ecology-series-0408/",
          "source_title": "Ecology Series 0408",
          "source_retrieved": "2026-09-08"
        }
      ]
    },
    {
      "id": "cr_0066",
      "name": "Research scientist / principal investigator",
      "slug": "research-scientist-principal-investigator",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_independent_research",
        "name": "Independent research & academia",
        "description": "Research scientists, principal investigators, and professors."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Designs and leads research programs, obtains funding, supervises projects and staff, analyzes and publishes results, and develops an independent scientific agenda.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "Universities, research institutes, museums, government laboratories, conservation research programs, and other scientific organizations.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "Research Scientist; Staff Scientist; Research Biologist; Principal Investigator",
        "Alternate names / terms": "PI; Principal Scientist; Lead Scientist",
        "Typical education / progression": "Ph.D. typical for PI/independent scientist; research scientist requirements vary",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Normally Ph.D.-level career",
      "dims": [
        1.4,
        0.7,
        1.0,
        1.9,
        0.5,
        2.5,
        2.1,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "leadership",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Lead Scientist",
        "PI",
        "Principal Scientist",
        "Principal Investigator",
        "Research Biologist",
        "Research Scientist",
        "Staff Scientist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0089",
      "name": "Research statistician — ecology/biology",
      "slug": "research-statistician-ecology-biology",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_quant",
        "name": "Quantitative ecology & data science",
        "description": "Statistics, ecological modeling, data science, and quantitative ecology."
      },
      "roleKind": "scientific_specialty",
      "marketStatus": "Verified federal/institutional title",
      "evidenceStatus": "verified_professional_role",
      "lastVerified": "2026-09-08",
      "roleFocus": "Develops and applies statistical methods to biological and ecological research, including abundance, occupancy, survival, movement, population dynamics, and study design.",
      "details": {
        "Typical work settings": "USGS and government science centers, universities, conservation organizations, quantitative ecology labs.",
        "Undergraduate preparation most useful": "Statistics, mathematics, programming, research design, ecology/biology, data management.",
        "Searchable job titles": "Research Statistician; Research Statistician (Biology); Biometrician; Quantitative Ecologist",
        "Alternate names / terms": "Biological statistician; ecological statistician",
        "Typical education / progression": "Advanced quantitative roles commonly require graduate training in statistics, quantitative ecology, or related fields.",
        "O*NET / BLS proxy": "Statisticians / Biostatisticians (proxy)",
        "Job outlook": "Use statistics occupations plus domain-specific postings.",
        "Salary context": "Use research/statistics postings; generic data-science salaries may overstate ecology-specific pay.",
        "Market status": "Verified federal/institutional title",
        "Career type": "Scientific Specialty"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "C",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "",
      "dims": [
        0.2,
        0.0,
        0.0,
        1.1,
        0.0,
        1.1,
        1.7,
        3.0,
        3.0,
        0.8
      ],
      "directContact": "Low",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Data / statistics",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Biological statistician",
        "ecological statistician",
        "Biometrician",
        "Quantitative Ecologist",
        "Research Statistician",
        "Research Statistician (Biology)"
      ],
      "competencies": [
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_dir_0005",
          "career_id": "cr_0089",
          "title": "Research Statistician",
          "organization": "U.S. Geological Survey - EESC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_eesc",
          "notes": "Current federal title.",
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        },
        {
          "observed_id": "obs_dir_0006",
          "career_id": "cr_0089",
          "title": "Research Statistician (Biology)",
          "organization": "U.S. Geological Survey - EESC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_eesc",
          "notes": "Current federal biology-statistics title.",
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "recentPostings": [],
      "evidence": [
        {
          "evidence_id": "ev_0017",
          "entity_type": "career",
          "entity_id": "cr_0089",
          "claim_type": "market_title",
          "claim_value": "USGS ecological science centers employ Research Statistician and Research Statistician (Biology) titles.",
          "source_id": "src_usgs_eesc",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0075",
      "name": "SSP coordinator / studbook keeper",
      "slug": "ssp-coordinator-studbook-keeper",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_population",
        "name": "Conservation breeding & population management",
        "description": "Conservation breeding, population biology, studbooks, and SSP population-management work."
      },
      "roleKind": "professional_assignment",
      "marketStatus": "Established AZA Animal Program leadership assignment",
      "evidenceStatus": "verified_professional_assignment",
      "lastVerified": "2026-09-08",
      "roleFocus": "Coordinates an AZA Species Survival Plan or maintains a regional studbook, helping manage population records, breeding/transfer planning, and communication across participating institutions.",
      "details": {
        "Typical work settings": "AZA-accredited institutions; work is commonly an added professional leadership responsibility rather than a standalone full-time job.",
        "Undergraduate preparation most useful": "Animal management, conservation breeding, population biology, records/databases, statistics, communication.",
        "Searchable job titles": "SSP Coordinator; SSP Program Leader; Studbook Keeper; Animal Program Leader",
        "Alternate names / terms": "Species Survival Plan leadership; regional studbook",
        "Typical education / progression": "Usually develops after professional zoo/aquarium experience; AZA training and institutional support are required for program-leader assignments.",
        "Job outlook": "Professional assignment rather than a separately counted occupation.",
        "Salary context": "Compensation is generally tied to the person’s primary zoo/aquarium position, not the SSP/studbook assignment itself.",
        "Market status": "Established AZA Animal Program leadership assignment",
        "Career type": "Professional Assignment"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "C",
        "UMA-AS": "C",
        "UMA-BIO": "C",
        "UMA-WEC": "C",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        1.2,
        1.1,
        2.8,
        0.8,
        0.5,
        1.7,
        2.7,
        2.1,
        1.6,
        1.5
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + substantial zoological experience",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Species Survival Plan leadership",
        "regional studbook",
        "Animal Program Leader",
        "SSP Coordinator",
        "SSP Program Leader",
        "Studbook Keeper"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_records",
          "name": "Animal records & databases",
          "category": "Professional",
          "description": "ZIMS/records systems, inventories, permits, transactions, and data stewardship.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [
        {
          "evidence_id": "ev_0010",
          "entity_type": "career",
          "entity_id": "cr_0075",
          "claim_type": "professional_role",
          "claim_value": "AZA formally defines SSP Coordinator and Studbook Keeper responsibilities and associated training/accountability requirements.",
          "source_id": "src_aza_program_roles",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_aza_program_roles",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "professional_reference",
            "title": "Updates to AZA Animal Programs - Role Descriptions",
            "url": "https://annual.aza.org/2024/documents/Boland__Marissa_Updates_to_AZA_s_Animal_Programs.pdf",
            "published_date": "2024",
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "SSP Coordinator and Studbook Keeper role descriptions."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0016",
      "name": "Sanctuary animal caregiver",
      "slug": "sanctuary-animal-caregiver",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_animal_care",
        "name": "Animal care & husbandry",
        "description": "Daily care, keeper work, sanctuary care, and managed-animal husbandry."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Provides day-to-day husbandry and welfare support in sanctuary settings, often for animals with long-term care needs and varied behavioral histories.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Animal Caregiver; Animal Care Specialist; Care Technician",
        "Alternate names / terms": "Sanctuary Caregiver; Animal Care Technician",
        "Typical education / progression": "Degree varies; experience is critical",
        "O*NET / BLS proxy": "Animal Caretakers (39-2021.00)",
        "Job outlook": "7%+ (Much faster than average); ~74,600 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $27,250–$29,820; mid proxy $35,360–$40,050",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "C",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "Direct animal-care experience important",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        0.7,
        2.2,
        1.4
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        27250,
        29820
      ],
      "midSalary": [
        35360,
        40050
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Animal Care Technician",
        "Sanctuary Caregiver",
        "Animal Care Specialist",
        "Animal Caregiver",
        "Care Technician"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0012",
          "career_id": "cr_0016",
          "title": "Avian Care Specialist",
          "organization": "Oasis Sanctuary Foundation",
          "location": "Benson, AZ",
          "observation_type": "job_posting",
          "observed_date": "2026-09-04",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0012",
          "career_id": "cr_0016",
          "title": "Avian Care Specialist",
          "employer": "Oasis Sanctuary Foundation",
          "location": "Benson, AZ",
          "posted_date": "2026-09-04",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0072",
      "name": "Science writer / communicator — biology and animals",
      "slug": "science-writer-communicator-biology-and-animals",
      "category": "Education, outreach & science communication",
      "domain": {
        "id": "dm_education",
        "name": "Education, outreach & communication",
        "description": "Interpretation, education, outreach, museums, collections, and science communication."
      },
      "roleFamily": {
        "id": "rf_scicomm",
        "name": "Science communication & museum work",
        "description": "Science writing, communication, natural-history museums, and collections."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Translates scientific information into clear public, technical, educational, journalistic, institutional, or policy-oriented communication.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Scientific organizations, universities, government agencies, conservation NGOs, publishers/media, museums/zoos, and freelance/contract communications settings.",
        "Undergraduate preparation most useful": "Scientific literacy, interviewing/source evaluation, clear explanatory writing, editing, visual/data communication, and the ability to translate technical material for different audiences.",
        "Searchable job titles": "Science Writer; Technical Writer; Scientific Communications Specialist; Medical Writer",
        "Alternate names / terms": "Scientific Writer; Science Communicator; Biology Writer",
        "Typical education / progression": "B.S. + strong writing portfolio; graduate subject expertise can help",
        "O*NET / BLS proxy": "Technical Writers (27-3042.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $57,440–$70,880; mid proxy $90,390–$115,510",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "S",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Any track can support this with strong writing/communication experience",
      "dims": [
        1.3,
        0.5,
        1.2,
        1.3,
        0.3,
        1.0,
        2.2,
        1.3,
        0.9,
        3.0
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "variable",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Education / public"
      ],
      "entrySalary": [
        57440,
        70880
      ],
      "midSalary": [
        90390,
        115510
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Biology Writer",
        "Science Communicator",
        "Scientific Writer",
        "Medical Writer",
        "Science Writer",
        "Scientific Communications Specialist",
        "Technical Writer"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0010",
      "name": "Science-based animal trainer",
      "slug": "science-based-animal-trainer",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_applied_behavior",
        "name": "Applied behavior & training",
        "description": "Science-based training, behavior modification, service-animal work, and applied behavior."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses learning theory, reinforcement, careful observation, and measurable training plans for husbandry, welfare, service work, education, or animal-care applications.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, shelters, animal-welfare organizations, assistance-animal programs, universities/research labs, sanctuaries, or other managed-animal settings.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Animal Trainer; Keeper/Trainer; Marine Mammal Trainer",
        "Alternate names / terms": "Positive-Reinforcement Trainer; Behavior Trainer",
        "Typical education / progression": "Degree requirements vary; science-based zoo roles often favor B.S. + experience",
        "O*NET / BLS proxy": "Animal Trainers (39-2011.00)",
        "Job outlook": "5%–6% (Faster than average); ~7,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $29,600–$33,740; mid proxy $39,990–$53,580",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, URI-W",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-WEC, ME-WE, ME-ZOO"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "N",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "URI certificate explicitly includes applied animal training",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.0,
        2.9,
        1.1
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Education / public",
        "Research"
      ],
      "entrySalary": [
        29600,
        33740
      ],
      "midSalary": [
        39990,
        53580
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Behavior Trainer",
        "Positive-Reinforcement Trainer",
        "Animal Trainer",
        "Keeper/Trainer",
        "Marine Mammal Trainer"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0011",
      "name": "Service-dog / assistance-animal trainer",
      "slug": "service-dog-assistance-animal-trainer",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_applied_behavior",
        "name": "Applied behavior & training",
        "description": "Science-based training, behavior modification, service-animal work, and applied behavior."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Selects, socializes, trains, evaluates, and matches assistance animals while teaching reliable task performance and appropriate public behavior.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Assistance-dog organizations, guide-dog schools, nonprofit training programs, and specialized animal-training facilities.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Service Dog Trainer; Guide Dog Trainer; Guide Dog Instructor; Guide Dog Mobility Instructor",
        "Alternate names / terms": "Assistance Dog Trainer; Service Animal Trainer",
        "Typical education / progression": "Experience/certification important; B.S. can help",
        "O*NET / BLS proxy": "Animal Trainers (39-2011.00)",
        "Job outlook": "5%–6% (Faster than average); ~7,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $29,600–$33,740; mid proxy $39,990–$53,580",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ",
        "Credible with planning": "UMA-BIO, URI-WZ",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-WEC, ME-WE, ME-ZOO, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "N",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "N",
        "URI-WZ": "C"
      },
      "notes": "UNE and UMass Animal Science have especially relevant pathways",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.0,
        2.9,
        1.1
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Education / public",
        "Research"
      ],
      "entrySalary": [
        29600,
        33740
      ],
      "midSalary": [
        39990,
        53580
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Assistance Dog Trainer",
        "Service Animal Trainer",
        "Guide Dog Instructor",
        "Guide Dog Mobility Instructor",
        "Guide Dog Trainer",
        "Service Dog Trainer"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0012",
      "name": "Shelter behavior specialist / coordinator",
      "slug": "shelter-behavior-specialist-coordinator",
      "category": "Animal behavior, cognition, welfare & training",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_shelter_companion",
        "name": "Shelter & companion-animal behavior",
        "description": "Shelter behavior, companion-animal behavior, and complex behavior consulting."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Assesses behavior in shelter animals, designs enrichment and behavior plans, supports adopters/fosters, trains staff or volunteers, and helps make placement decisions.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Animal shelters, humane societies, municipal animal-care agencies, rescue organizations, and behavior/adoption programs.",
        "Undergraduate preparation most useful": "Behavioral observation and ethograms; learning/behavior principles; animal welfare and husbandry; statistics and research design; careful recordkeeping; clear communication.",
        "Searchable job titles": "Behavior Manager; Behavior Coordinator; Animal Behavior Manager",
        "Alternate names / terms": "Shelter Behavior Specialist; Canine/Feline Behavior Specialist",
        "Typical education / progression": "B.S. plus shelter/training experience common",
        "O*NET / BLS proxy": "Animal Trainers (39-2011.00)",
        "Job outlook": "5%–6% (Faster than average); ~7,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $29,600–$33,740; mid proxy $39,990–$53,580",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-AZ",
        "Credible with planning": "UMA-BIO, ME-ZOO, URI-WZ",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-WEC, ME-WE, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "N",
        "URI-WZ": "C"
      },
      "notes": "UNE particularly direct",
      "dims": [
        3.0,
        2.9,
        2.0,
        0.7,
        0.5,
        2.0,
        0.5,
        1.0,
        2.9,
        1.1
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": [
        29600,
        33740
      ],
      "midSalary": [
        39990,
        53580
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Canine/Feline Behavior Specialist",
        "Shelter Behavior Specialist",
        "Animal Behavior Manager",
        "Behavior Coordinator",
        "Behavior Manager"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [
        {
          "relationship": "useful",
          "notes": "Shelter-specific behavior credential.",
          "credential_id": "cred_iaabc_sba",
          "name": "Shelter Behavior Affiliate (SBA)",
          "organization": "International Association of Animal Behavior Consultants",
          "credential_type": "professional credential",
          "description": "Shelter-behavior credential with recommended shelter experience and knowledge of learning/behavior change.",
          "source_id": "src_iaabc_shelter",
          "source_url": "https://iaabc.org/en/affiliate-credentials",
          "source_retrieved": "2026-09-08"
        }
      ],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0082",
      "name": "Species recovery biologist",
      "slug": "species-recovery-biologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_reintroduction",
        "name": "Species recovery & reintroduction",
        "description": "Release, reintroduction, post-release monitoring, and species recovery."
      },
      "roleKind": "career",
      "marketStatus": "Verified professional function; titles vary",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Plans or implements recovery actions for threatened or endangered species, integrating population monitoring, habitat needs, reintroduction, regulatory requirements, and partner coordination.",
      "details": {
        "Typical work settings": "Federal/state agencies, conservation NGOs, zoos/conservation centers, universities, species-recovery partnerships.",
        "Undergraduate preparation most useful": "Population ecology, field methods, conservation biology, GIS, statistics, endangered-species policy, scientific writing.",
        "Searchable job titles": "Species Recovery Biologist; Recovery Biologist; Endangered Species Biologist; Recovery Program Biologist",
        "Alternate names / terms": "Species recovery; threatened and endangered species; recovery planning",
        "Typical education / progression": "B.S. may support implementation roles; M.S. often useful for independent planning/science leadership.",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists / Biological Scientists",
        "Job outlook": "Use wildlife-biologist and biological-scientist benchmarks plus agency postings.",
        "Salary context": "Use federal/state/NGO postings and related biological-science benchmarks.",
        "Market status": "Verified professional function; titles vary",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        1.1,
        0.4,
        0.2,
        2.8,
        2.4,
        1.6,
        3.0,
        2.2,
        2.3,
        1.1
      ],
      "directContact": "Moderate",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Species recovery",
        "recovery planning",
        "threatened and endangered species",
        "Endangered Species Biologist",
        "Recovery Biologist",
        "Recovery Program Biologist",
        "Species Recovery Biologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_release",
          "name": "Reintroduction & release",
          "category": "Applied conservation",
          "description": "Release planning, reintroduction, translocation, and post-release evaluation.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0059",
      "name": "University / laboratory research assistant",
      "slug": "university-laboratory-research-assistant",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_research_support",
        "name": "Research support & lab operations",
        "description": "Research assistants, technicians, laboratory managers, and research coordination."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Supports academic biological or behavioral research through experiments, animal observation/care where applicable, sample processing, data management, literature work, and analysis.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Universities, research institutes, museums, government laboratories, conservation research programs, and other scientific organizations.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "Research Assistant; Research Associate; Lab Technician; Biological Technician",
        "Alternate names / terms": "University Research Assistant; Laboratory Research Assistant",
        "Typical education / progression": "B.S. commonly sufficient for entry roles",
        "O*NET / BLS proxy": "Biological Technicians (19-4021.00)",
        "Job outlook": "3%–4% (Average); ~9,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $40,330–$48,130; mid proxy $57,510–$71,520",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "S",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "All ten can support entry-level research if student builds experience",
      "dims": [
        1.9,
        0.7,
        1.0,
        1.9,
        0.5,
        2.5,
        2.1,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        40330,
        48130
      ],
      "midSalary": [
        57510,
        71520
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Laboratory Research Assistant",
        "University Research Assistant",
        "Biological Technician",
        "Lab Technician",
        "Research Assistant",
        "Research Associate"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0067",
      "name": "University professor",
      "slug": "university-professor",
      "category": "Research, graduate school & academia",
      "domain": {
        "id": "dm_research",
        "name": "Research & academia",
        "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers."
      },
      "roleFamily": {
        "id": "rf_independent_research",
        "name": "Independent research & academia",
        "description": "Research scientists, principal investigators, and professors."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Combines teaching, mentoring, research, service, publication, and often grant-funded laboratory or field programs in a biological or behavioral specialty.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "Colleges and universities, usually within biology, ecology/evolution, psychology, neuroscience, animal science, wildlife, or related departments.",
        "Undergraduate preparation most useful": "Research design; statistics; data management; literature synthesis; scientific writing/presentation; laboratory or field methods; sustained faculty-mentored research.",
        "Searchable job titles": "Assistant Professor; Associate Professor; Biology Professor; Lecturer",
        "Alternate names / terms": "Professor of Biology; Faculty Researcher",
        "Typical education / progression": "Ph.D. generally required for tenure-track roles",
        "O*NET / BLS proxy": "Biological Science Teachers, Postsecondary (25-1042.00)",
        "Job outlook": "7%+ (Much faster than average); ~5,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $52,150–$64,350; mid proxy $84,620–$126,770",
        "Proxy fit": "High",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Normally Ph.D. plus research record",
      "dims": [
        1.9,
        0.7,
        1.0,
        1.9,
        0.5,
        3.0,
        1.6,
        2.8,
        3.0,
        2.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "leadership",
      "workTags": [
        "Behavior / training",
        "Data / statistics",
        "Education / public",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        52150,
        64350
      ],
      "midSalary": [
        84620,
        126770
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Faculty Researcher",
        "Professor of Biology",
        "Assistant Professor",
        "Associate Professor",
        "Biology Professor",
        "Lecturer"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_neuro",
          "name": "Neuroscience & neuroethology",
          "category": "Biological mechanisms",
          "description": "Neural mechanisms of behavior.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0069",
      "name": "Wildlife / environmental educator",
      "slug": "wildlife-environmental-educator",
      "category": "Education, outreach & science communication",
      "domain": {
        "id": "dm_education",
        "name": "Education, outreach & communication",
        "description": "Interpretation, education, outreach, museums, collections, and science communication."
      },
      "roleFamily": {
        "id": "rf_wildlife_education",
        "name": "Wildlife interpretation & outreach",
        "description": "Wildlife/environmental education, naturalist work, and conservation outreach."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Teaches environmental and wildlife topics through schools, nature centers, parks, nonprofits, camps, field programs, or public outreach.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, museums, parks/refuges, nature centers, schools, NGOs, government outreach programs, publishers, and scientific organizations.",
        "Undergraduate preparation most useful": "Strong biological content knowledge; writing and presentation; audience-centered communication; interpretation/teaching; program organization; research literacy.",
        "Searchable job titles": "Environmental Educator; Wildlife Educator; Natural Resource Educator",
        "Alternate names / terms": "Conservation Educator; Outdoor Educator",
        "Typical education / progression": "B.S. common",
        "O*NET / BLS proxy": "Park Naturalists (19-1031.03)",
        "Job outlook": "3%–4% (Average; Conservation Scientists proxy); ~2,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $47,550–$57,700; mid proxy $73,010–$91,560",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UNE-AB, UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AN, URI-AZ",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "S",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Natural-resource tracks especially strong",
      "dims": [
        1.3,
        0.5,
        1.2,
        1.8,
        0.3,
        1.0,
        2.2,
        1.3,
        1.4,
        3.0
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Education / public",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        47550,
        57700
      ],
      "midSalary": [
        73010,
        91560
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Conservation Educator",
        "Outdoor Educator",
        "Environmental Educator",
        "Natural Resource Educator",
        "Wildlife Educator"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0017",
          "career_id": "cr_0069",
          "title": "Wildlife Education Curator",
          "organization": "Arizona Game and Fish Department",
          "location": "Phoenix, AZ",
          "observation_type": "job_posting",
          "observed_date": "2026-09-01",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0017",
          "career_id": "cr_0069",
          "title": "Wildlife Education Curator",
          "employer": "Arizona Game and Fish Department",
          "location": "Phoenix, AZ",
          "posted_date": "2026-09-01",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS?LOCALE=EN",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0027",
      "name": "Wildlife biologist",
      "slug": "wildlife-biologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_wildlife_biology",
        "name": "Wildlife biology & management",
        "description": "Professional wildlife biology, nongame/diversity biology, and wildlife program work."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies or manages wild animal populations and habitats using field surveys, population analysis, habitat assessment, regulatory work, management planning, and scientific reporting.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Wildlife Biologist; Fish & Wildlife Biologist; Fisheries and Wildlife Biological Scientist; Habitat Biologist",
        "Alternate names / terms": "Wildlife Scientist; Wildlife Research Biologist",
        "Typical education / progression": "B.S. minimum common; M.S. helpful/required for many advanced roles",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, URI-AZ",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Dedicated wildlife degrees strongest",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Wildlife Research Biologist",
        "Wildlife Scientist",
        "Fish & Wildlife Biologist",
        "Fisheries and Wildlife Biological Scientist",
        "Habitat Biologist",
        "Wildlife Biologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0043",
          "career_id": "cr_0027",
          "title": "Butte Area Wildlife Biologist",
          "organization": "Montana Fish, Wildlife & Parks",
          "location": "Butte, MT",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Current TWS search result.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        },
        {
          "observed_id": "obs_dir_0001",
          "career_id": "cr_0027",
          "title": "Research Wildlife Biologist",
          "organization": "U.S. Geological Survey - EESC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_eesc",
          "notes": "Current federal research title.",
          "source": {
            "source_id": "src_usgs_eesc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Eastern Ecological Science Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/eesc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0043",
          "career_id": "cr_0027",
          "title": "Butte Area Wildlife Biologist",
          "employer": "Montana Fish, Wildlife & Parks",
          "location": "Butte, MT",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/jobs/?keywords=wildlife+technician",
          "active_status": "current_or_recent",
          "notes": "Current TWS search result.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0001",
          "entity_type": "career",
          "entity_id": "cr_0027",
          "claim_type": "qualification",
          "claim_value": "Federal GS-0486 nonresearch positions require 9 semester hours wildlife subjects, 12 zoology, and 9 botany/plant sciences.",
          "source_id": "src_opm_0486",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_opm_0486",
            "organization": "U.S. Office of Personnel Management",
            "source_type": "qualification_standard",
            "title": "Wildlife Biology Series 0486",
            "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/wildlife-biology-series-0486/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Federal wildlife-biologist education requirements."
          }
        }
      ],
      "credentials": [
        {
          "relationship": "useful",
          "notes": "Can document qualifying wildlife coursework at/after graduation.",
          "credential_id": "cred_tws_awb",
          "name": "Associate Wildlife Biologist®",
          "organization": "The Wildlife Society",
          "credential_type": "professional certification",
          "description": "Academic credential for wildlife professionals demonstrating qualifying coursework.",
          "source_id": "src_tws_cert",
          "source_url": "https://wildlife.org/tws-certifications/",
          "source_retrieved": "2026-09-08"
        },
        {
          "relationship": "useful_later",
          "notes": "Professional credential after qualifying education and experience.",
          "credential_id": "cred_tws_cwb",
          "name": "Certified Wildlife Biologist®",
          "organization": "The Wildlife Society",
          "credential_type": "professional certification",
          "description": "Professional wildlife credential requiring qualifying education and professional experience; upgrade commonly follows five years of professional experience.",
          "source_id": "src_tws_cert",
          "source_url": "https://wildlife.org/tws-certifications/",
          "source_retrieved": "2026-09-08"
        }
      ],
      "qualificationProfiles": [
        {
          "qualification_id": "qual_0486",
          "career_id": "cr_0027",
          "organization": "U.S. Office of Personnel Management",
          "series_code": "0486",
          "name": "Federal Wildlife Biology Series 0486",
          "education_requirement": "Degree or equivalent biological-science preparation.",
          "coursework_requirement": "Nonresearch positions: at least 9 semester hours wildlife subjects, 12 zoology, and 9 botany/plant sciences. Research positions also require 15 hours across physical/mathematical/earth sciences.",
          "experience_requirement": "Grade-specific experience/education applies beyond the basic requirement.",
          "source_id": "src_opm_0486",
          "source_url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/wildlife-biology-series-0486/",
          "source_title": "Wildlife Biology Series 0486",
          "source_retrieved": "2026-09-08"
        }
      ]
    },
    {
      "id": "cr_0037",
      "name": "Wildlife disease / ecophysiology specialist",
      "slug": "wildlife-disease-ecophysiology-specialist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_wildlife_health",
        "name": "Wildlife health & ecophysiology",
        "description": "Wildlife disease, physiology, stress, and ecophysiology."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies disease, stress, energetics, physiology, or environmental responses in wildlife and how those factors affect individual performance, populations, and conservation.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "Graduate-level research / academic career",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Wildlife Disease Ecologist; Disease Ecologist; Ecophysiologist; Physiological Ecologist",
        "Alternate names / terms": "Wildlife Disease Biologist; Wildlife Physiologist",
        "Typical education / progression": "M.S./Ph.D. usually",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UNE-AN",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ",
        "Weakly aligned paths": "UNE-AB"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "N",
        "UNE-AN": "C",
        "URI-AZ": "G",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Usually requires specialized graduate training",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        3.0,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Wildlife Disease Biologist",
        "Wildlife Physiologist",
        "Disease Ecologist",
        "Ecophysiologist",
        "Physiological Ecologist",
        "Wildlife Disease Ecologist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0081",
      "name": "Wildlife diversity / nongame biologist",
      "slug": "wildlife-diversity-nongame-biologist",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_wildlife_biology",
        "name": "Wildlife biology & management",
        "description": "Professional wildlife biology, nongame/diversity biology, and wildlife program work."
      },
      "roleKind": "career",
      "marketStatus": "Verified current market titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Studies and manages nongame species and biodiversity, often combining surveys, species-status assessments, habitat work, data management, and conservation planning for less-harvested or at-risk taxa.",
      "details": {
        "Typical work settings": "State wildlife agencies, natural heritage programs, NGOs, consulting firms, universities.",
        "Undergraduate preparation most useful": "Wildlife biology, ecology, taxonomy/species ID, field sampling, GIS, statistics, scientific writing.",
        "Searchable job titles": "Wildlife Diversity Biologist; Nongame Biologist; Natural Heritage Zoologist; Wildlife Diversity Specialist",
        "Alternate names / terms": "Nongame wildlife; biodiversity biologist; natural heritage zoology",
        "Typical education / progression": "B.S. supports technician and some biologist roles; M.S. often improves competitiveness for specialist positions.",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists",
        "Job outlook": "Use wildlife-biologist benchmarks plus state/NGO postings.",
        "Salary context": "Use state-agency/posting salary ranges and wildlife-biologist benchmarks.",
        "Market status": "Verified current market titles",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        1.3,
        0.4,
        0.2,
        3.0,
        0.6,
        2.1,
        3.0,
        2.3,
        2.1,
        0.9
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible; M.S. often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Nongame wildlife",
        "biodiversity biologist",
        "natural heritage zoology",
        "Natural Heritage Zoologist",
        "Nongame Biologist",
        "Wildlife Diversity Biologist",
        "Wildlife Diversity Specialist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0044",
          "career_id": "cr_0081",
          "title": "Nongame and Wetlands Habitat Biologist",
          "organization": "Montana Fish, Wildlife & Parks",
          "location": "Helena, MT",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Current TWS search result.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0044",
          "career_id": "cr_0081",
          "title": "Nongame and Wetlands Habitat Biologist",
          "employer": "Montana Fish, Wildlife & Parks",
          "location": "Helena, MT",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/jobs/?keywords=wildlife+technician",
          "active_status": "current_or_recent",
          "notes": "Current TWS search result.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [
        {
          "relationship": "useful",
          "notes": "Useful professional wildlife credential.",
          "credential_id": "cred_tws_awb",
          "name": "Associate Wildlife Biologist®",
          "organization": "The Wildlife Society",
          "credential_type": "professional certification",
          "description": "Academic credential for wildlife professionals demonstrating qualifying coursework.",
          "source_id": "src_tws_cert",
          "source_url": "https://wildlife.org/tws-certifications/",
          "source_retrieved": "2026-09-08"
        }
      ],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0085",
      "name": "Wildlife program manager",
      "slug": "wildlife-program-manager",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_wildlife_biology",
        "name": "Wildlife biology & management",
        "description": "Professional wildlife biology, nongame/diversity biology, and wildlife program work."
      },
      "roleKind": "later_career",
      "marketStatus": "Verified current market titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Leads wildlife programs, multidisciplinary staff, regional priorities, budgets, partnerships, and conservation delivery across species, habitat, recreation, and agency functions.",
      "details": {
        "Typical work settings": "State wildlife agencies, federal programs, NGOs, large conservation organizations.",
        "Undergraduate preparation most useful": "Wildlife science, management, policy, project management, communication, budgeting, staff supervision.",
        "Searchable job titles": "Regional Wildlife Program Manager; Wildlife Program Manager; Applied Research Section Manager; Supervisory Wildlife Biologist",
        "Alternate names / terms": "Wildlife program leadership; regional wildlife manager",
        "Typical education / progression": "Usually a later-career role after several years of professional wildlife work; graduate study may help but is not always required.",
        "Job outlook": "Use agency/NGO postings and management benchmarks.",
        "Salary context": "Use agency salary schedules and current management postings.",
        "Market status": "Verified current market titles",
        "Career type": "Later Career"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C*",
        "UMA-AS": "N",
        "UMA-BIO": "C*",
        "UMA-WEC": "S",
        "UNE-AB": "C*",
        "UNE-AN": "C*",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        0.5,
        0.2,
        0.1,
        2.2,
        0.3,
        1.0,
        2.8,
        1.8,
        1.6,
        1.7
      ],
      "directContact": "Low",
      "educationBand": "B.S. + substantial professional experience",
      "careerStage": "leadership",
      "workTags": [
        "Conservation",
        "Education / public",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 123552,
        "observedMax": 123552,
        "medianLow": 123552,
        "medianHigh": 123552,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Wildlife program leadership",
        "regional wildlife manager",
        "Applied Research Section Manager",
        "Regional Wildlife Program Manager",
        "Supervisory Wildlife Biologist",
        "Wildlife Program Manager"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0038",
          "career_id": "cr_0085",
          "title": "Regional Wildlife Program Manager - North Puget Sound Region 4",
          "organization": "Washington Department of Fish & Wildlife",
          "location": "Stanwood, WA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_wildlife_manager",
          "notes": "Regional wildlife program leadership.",
          "source": {
            "source_id": "src_tws_wildlife_manager",
            "organization": "Washington Department of Fish & Wildlife / TWS",
            "source_type": "job_posting",
            "title": "Regional Wildlife Program Manager",
            "url": "https://careers.wildlife.org/job/regional-wildlife-program-manager-north-puget-sound-region-4/85512902/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Regional wildlife leadership posting with salary and experience."
          }
        },
        {
          "observed_id": "obs_post_0040",
          "career_id": "cr_0085",
          "title": "State Administrative Manager - Applied Research Section Manager",
          "organization": "Michigan Department of Natural Resources",
          "location": "Michigan",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Featured current TWS posting.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        },
        {
          "observed_id": "obs_dir_0002",
          "career_id": "cr_0085",
          "title": "Supervisory Research Wildlife Biologist",
          "organization": "U.S. Geological Survey - WERC",
          "location": null,
          "observation_type": "employee_directory",
          "observed_date": "2026-09-08",
          "source_id": "src_usgs_werc",
          "notes": "Supervisory research wildlife title.",
          "source": {
            "source_id": "src_usgs_werc",
            "organization": "U.S. Geological Survey",
            "source_type": "employee_directory",
            "title": "Western Ecological Research Center - Employee Directory",
            "url": "https://www.usgs.gov/centers/werc/connect",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current scientific titles in federal ecological research."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0038",
          "career_id": "cr_0085",
          "title": "Regional Wildlife Program Manager - North Puget Sound Region 4",
          "employer": "Washington Department of Fish & Wildlife",
          "location": "Stanwood, WA",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "B.A./B.S.",
          "experience_min": "5–7 years",
          "salary_min": 123552.0,
          "salary_max": 123552.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_wildlife_manager",
          "url": "https://careers.wildlife.org/job/regional-wildlife-program-manager-north-puget-sound-region-4/85512902/",
          "active_status": "current_or_recent",
          "notes": "Regional wildlife program leadership.",
          "source": {
            "source_id": "src_tws_wildlife_manager",
            "organization": "Washington Department of Fish & Wildlife / TWS",
            "source_type": "job_posting",
            "title": "Regional Wildlife Program Manager",
            "url": "https://careers.wildlife.org/job/regional-wildlife-program-manager-north-puget-sound-region-4/85512902/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Regional wildlife leadership posting with salary and experience."
          }
        },
        {
          "posting_id": "post_0040",
          "career_id": "cr_0085",
          "title": "State Administrative Manager - Applied Research Section Manager",
          "employer": "Michigan Department of Natural Resources",
          "location": "Michigan",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/",
          "active_status": "current_or_recent",
          "notes": "Featured current TWS posting.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0016",
          "entity_type": "career",
          "entity_id": "cr_0085",
          "claim_type": "market_title",
          "claim_value": "Current TWS postings include Regional Wildlife Program Manager and Applied Research Section Manager.",
          "source_id": "src_tws_wildlife_manager",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_tws_wildlife_manager",
            "organization": "Washington Department of Fish & Wildlife / TWS",
            "source_type": "job_posting",
            "title": "Regional Wildlife Program Manager",
            "url": "https://careers.wildlife.org/job/regional-wildlife-program-manager-north-puget-sound-region-4/85512902/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Regional wildlife leadership posting with salary and experience."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0083",
      "name": "Wildlife refuge manager",
      "slug": "wildlife-refuge-manager",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_habitat",
        "name": "Habitat & conservation delivery",
        "description": "Habitat biology, restoration delivery, conservation planning, and refuge management."
      },
      "roleKind": "later_career",
      "marketStatus": "Verified federal occupational series and current titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Manages public lands and waters designated as wildlife refuges, integrating wildlife and habitat conservation, land/water management, planning, administration, public relations, supervision, and regulatory responsibilities.",
      "details": {
        "Typical work settings": "National wildlife refuges and federal land/wildlife programs.",
        "Undergraduate preparation most useful": "Wildlife biology, habitat management, ecology, botany, conservation biology, public communication, project/program management.",
        "Searchable job titles": "Wildlife Refuge Manager; Wildlife Refuge Specialist; Deputy Refuge Manager; Supervisory Wildlife Refuge Specialist",
        "Alternate names / terms": "Federal refuge management; refuge specialist",
        "Typical education / progression": "Specific OPM coursework requirements apply; manager roles generally follow progressive wildlife/refuge-management experience.",
        "Job outlook": "Federal occupational series 0485; use current USAJOBS postings and federal staffing data.",
        "Salary context": "Use current GS/locality postings rather than O*NET animal-care proxies.",
        "Market status": "Verified federal occupational series and current titles",
        "Career type": "Later Career"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        0.5,
        0.2,
        0.1,
        2.4,
        0.4,
        1.0,
        3.0,
        1.5,
        1.2,
        1.9
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + progressive professional experience",
      "careerStage": "leadership",
      "workTags": [
        "Conservation",
        "Education / public",
        "Fieldwork"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": {
        "count": 2,
        "observedMin": 89508,
        "observedMax": 155521,
        "medianLow": 104569,
        "medianHigh": 135942,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Federal refuge management",
        "refuge specialist",
        "Deputy Refuge Manager",
        "Supervisory Wildlife Refuge Specialist",
        "Wildlife Refuge Manager",
        "Wildlife Refuge Specialist"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0055",
          "career_id": "cr_0083",
          "title": "Wildlife Refuge Manager",
          "organization": "U.S. Fish and Wildlife Service",
          "location": "Winona, MN",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_usajobs_refuge",
          "notes": "GS-12 supervisory refuge manager.",
          "source": {
            "source_id": "src_usajobs_refuge",
            "organization": "U.S. Fish and Wildlife Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Wildlife Refuge Manager - Winona",
            "url": "https://www.usajobs.gov/job/883089800",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-12 refuge manager posting."
          }
        },
        {
          "observed_id": "obs_post_0056",
          "career_id": "cr_0083",
          "title": "Wildlife Refuge Manager",
          "organization": "U.S. Fish and Wildlife Service",
          "location": "Ilwaco, WA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_usajobs_refuge2",
          "notes": "GS-13 supervisory refuge manager.",
          "source": {
            "source_id": "src_usajobs_refuge2",
            "organization": "U.S. Fish and Wildlife Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Wildlife Refuge Manager - Willapa",
            "url": "https://www.usajobs.gov/job/883251400",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-13 refuge manager posting."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0055",
          "career_id": "cr_0083",
          "title": "Wildlife Refuge Manager",
          "employer": "U.S. Fish and Wildlife Service",
          "location": "Winona, MN",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": "Progressive federal/professional experience",
          "salary_min": 89508.0,
          "salary_max": 116362.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_usajobs_refuge",
          "url": "https://www.usajobs.gov/job/883089800",
          "active_status": "current_or_recent",
          "notes": "GS-12 supervisory refuge manager.",
          "source": {
            "source_id": "src_usajobs_refuge",
            "organization": "U.S. Fish and Wildlife Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Wildlife Refuge Manager - Winona",
            "url": "https://www.usajobs.gov/job/883089800",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-12 refuge manager posting."
          }
        },
        {
          "posting_id": "post_0056",
          "career_id": "cr_0083",
          "title": "Wildlife Refuge Manager",
          "employer": "U.S. Fish and Wildlife Service",
          "location": "Ilwaco, WA",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": "Progressive federal/professional experience",
          "salary_min": 119630.0,
          "salary_max": 155521.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_usajobs_refuge2",
          "url": "https://www.usajobs.gov/job/883251400",
          "active_status": "current_or_recent",
          "notes": "GS-13 supervisory refuge manager.",
          "source": {
            "source_id": "src_usajobs_refuge2",
            "organization": "U.S. Fish and Wildlife Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Wildlife Refuge Manager - Willapa",
            "url": "https://www.usajobs.gov/job/883251400",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-13 refuge manager posting."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0002",
          "entity_type": "career",
          "entity_id": "cr_0083",
          "claim_type": "qualification",
          "claim_value": "Federal GS-0485 requires zoology/wildlife/biology preparation including 9 hours zoology, 6 wildlife, 3 botany, and 3 conservation biology.",
          "source_id": "src_opm_0485",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_opm_0485",
            "organization": "U.S. Office of Personnel Management",
            "source_type": "qualification_standard",
            "title": "Wildlife Refuge Management Series 0485",
            "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/wildlife-refuge-management-series-0485/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Federal wildlife-refuge management education requirements."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": [
        {
          "qualification_id": "qual_0485",
          "career_id": "cr_0083",
          "organization": "U.S. Office of Personnel Management",
          "series_code": "0485",
          "name": "Federal Wildlife Refuge Management Series 0485",
          "education_requirement": "Degree in zoology, wildlife management, or appropriate biology field, or equivalent combination.",
          "coursework_requirement": "At least 9 semester hours zoology; 6 wildlife courses; 3 botany; 3 conservation biology.",
          "experience_requirement": "Progressive grade-specific experience applies for manager positions.",
          "source_id": "src_opm_0485",
          "source_url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/wildlife-refuge-management-series-0485/",
          "source_title": "Wildlife Refuge Management Series 0485",
          "source_retrieved": "2026-09-08"
        }
      ]
    },
    {
      "id": "cr_0029",
      "name": "Wildlife rehabilitation / release coordinator",
      "slug": "wildlife-rehabilitation-release-coordinator",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_rehab",
        "name": "Wildlife rehabilitation & release",
        "description": "Wildlife rehabilitation, release coordination, and rehabilitation-center operations."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Manages rehabilitation-to-release logistics, including readiness assessment, release sites, permits, transport, records, volunteer/staff coordination, and sometimes follow-up monitoring.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Wildlife hospitals/rehabilitation centers, rescue-and-release programs, nonprofit wildlife organizations, and field release sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Rescue and Release Coordinator; Rehabilitation Coordinator; Release Coordinator",
        "Alternate names / terms": "Wildlife Release Coordinator; Rehab/Release Manager",
        "Typical education / progression": "B.S. plus rehabilitation and release experience",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UNE-AB, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AN, UMA-BIO",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS, URI-AZ"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "S",
        "UNE-AN": "C",
        "URI-AZ": "N",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Particularly aligned with Maine/URI wildlife routes",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        2.0,
        2.8,
        2.6,
        2.5,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Rehab/Release Manager",
        "Wildlife Release Coordinator",
        "Rehabilitation Coordinator",
        "Release Coordinator",
        "Rescue and Release Coordinator"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_release",
          "name": "Reintroduction & release",
          "category": "Applied conservation",
          "description": "Release planning, reintroduction, translocation, and post-release evaluation.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0093",
      "name": "Wildlife rehabilitation program manager",
      "slug": "wildlife-rehabilitation-program-manager",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_rehab",
        "name": "Wildlife rehabilitation & release",
        "description": "Wildlife rehabilitation, release coordination, and rehabilitation-center operations."
      },
      "roleKind": "later_career",
      "marketStatus": "Verified current market titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Directs or supervises rehabilitation-center operations, staff/volunteers, animal-care protocols, records, permits, budgets, training, release decisions, and public-facing program responsibilities.",
      "details": {
        "Typical work settings": "Wildlife rehabilitation centers, wildlife hospitals, park-district wildlife centers, nonprofit rehabilitation organizations.",
        "Undergraduate preparation most useful": "Wildlife biology, animal care, rehabilitation experience, staff/volunteer supervision, records, permits, biosecurity, communication.",
        "Searchable job titles": "Wildlife Care Manager; Rehabilitation Manager; Wildlife Rehabilitation Program Manager; Senior Rehabilitator",
        "Alternate names / terms": "Wildlife center manager; rehabilitation supervisor",
        "Typical education / progression": "Usually follows several years of hands-on rehabilitation plus supervisory/program responsibility; permits and center-specific requirements matter.",
        "Job outlook": "No dedicated O*NET occupation; NWRA postings provide direct market evidence.",
        "Salary context": "Use wildlife-rehabilitation postings and nonprofit/park-district salary data.",
        "Market status": "Verified current market titles",
        "Career type": "Later Career"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "C*",
        "UMA-AS": "C*",
        "UMA-BIO": "C*",
        "UMA-WEC": "C*",
        "UNE-AB": "C*",
        "UNE-AN": "C*",
        "URI-AZ": "C*",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        0.7,
        2.2,
        1.0,
        1.7,
        3.0,
        1.2,
        2.2,
        0.7,
        1.2,
        1.6
      ],
      "directContact": "High",
      "educationBand": "B.S. + 3–5+ years progressive rehabilitation experience",
      "careerStage": "leadership",
      "workTags": [
        "Animal care",
        "Conservation",
        "Education / public"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": {
        "count": 2,
        "observedMin": 53040,
        "observedMax": 91520,
        "medianLow": 56520,
        "medianHigh": 75760,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Wildlife center manager",
        "rehabilitation supervisor",
        "Rehabilitation Manager",
        "Senior Rehabilitator",
        "Wildlife Care Manager",
        "Wildlife Rehabilitation Program Manager"
      ],
      "competencies": [
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0050",
          "career_id": "cr_0093",
          "title": "Rehabilitator",
          "organization": "Tucson Wildlife Center",
          "location": "Tucson, AZ",
          "observation_type": "job_posting",
          "observed_date": "2026-08-21",
          "source_id": "src_nwra_rehab",
          "notes": "Duties include oversight of wildlife areas, staff, records, rehab, and release.",
          "source": {
            "source_id": "src_nwra_rehab",
            "organization": "Tucson Wildlife Center / NWRA",
            "source_type": "job_posting",
            "title": "Rehabilitator",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097520&view=2",
            "published_date": "2026-08-21",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current rehabilitation leadership posting."
          }
        },
        {
          "observed_id": "obs_post_0052",
          "career_id": "cr_0093",
          "title": "Wildlife Care Manager",
          "organization": "Lake Metroparks",
          "location": "Kirtland, OH",
          "observation_type": "job_posting",
          "observed_date": "2026-08-14",
          "source_id": "src_nwra_manager",
          "notes": "Operations, supervision, permits, budget, public education.",
          "source": {
            "source_id": "src_nwra_manager",
            "organization": "Lake Metroparks / NWRA",
            "source_type": "job_posting",
            "title": "Wildlife Care Manager",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1096932&view=2",
            "published_date": "2026-08-14",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Wildlife-care management posting with salary and experience."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0050",
          "career_id": "cr_0093",
          "title": "Rehabilitator",
          "employer": "Tucson Wildlife Center",
          "location": "Tucson, AZ",
          "posted_date": "2026-08-21",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "Intermediate/Advanced Wildlife Rehabilitator",
          "experience_min": "<1 year",
          "salary_min": 60000.0,
          "salary_max": 60000.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_nwra_rehab",
          "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097520&view=2",
          "active_status": "current_or_recent",
          "notes": "Duties include oversight of wildlife areas, staff, records, rehab, and release.",
          "source": {
            "source_id": "src_nwra_rehab",
            "organization": "Tucson Wildlife Center / NWRA",
            "source_type": "job_posting",
            "title": "Rehabilitator",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097520&view=2",
            "published_date": "2026-08-21",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current rehabilitation leadership posting."
          }
        },
        {
          "posting_id": "post_0052",
          "career_id": "cr_0093",
          "title": "Wildlife Care Manager",
          "employer": "Lake Metroparks",
          "location": "Kirtland, OH",
          "posted_date": "2026-08-14",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "Bachelor’s preferred",
          "experience_min": "3–5 years",
          "salary_min": 53040.0,
          "salary_max": 91520.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_nwra_manager",
          "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1096932&view=2",
          "active_status": "current_or_recent",
          "notes": "Operations, supervision, permits, budget, public education.",
          "source": {
            "source_id": "src_nwra_manager",
            "organization": "Lake Metroparks / NWRA",
            "source_type": "job_posting",
            "title": "Wildlife Care Manager",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1096932&view=2",
            "published_date": "2026-08-14",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Wildlife-care management posting with salary and experience."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0014",
          "entity_type": "career",
          "entity_id": "cr_0093",
          "claim_type": "market_title",
          "claim_value": "Current NWRA postings include Wildlife Care Manager and rehabilitation roles with staff, permit, budget, and program oversight.",
          "source_id": "src_nwra_manager",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_nwra_manager",
            "organization": "Lake Metroparks / NWRA",
            "source_type": "job_posting",
            "title": "Wildlife Care Manager",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1096932&view=2",
            "published_date": "2026-08-14",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Wildlife-care management posting with salary and experience."
          }
        }
      ],
      "credentials": [
        {
          "relationship": "role_dependent",
          "notes": "At least one qualified/permitted person must cover federally regulated rehabilitation activities.",
          "credential_id": "cred_fws_rehab",
          "name": "Federal Migratory Bird Rehabilitation Permit",
          "organization": "U.S. Fish and Wildlife Service",
          "credential_type": "permit",
          "description": "Required to rehabilitate covered migratory birds; current federal requirements include age 18+, at least 100 hands-on hours over at least one year for each bird type, and state compliance.",
          "source_id": "src_fws_rehab",
          "source_url": "https://www.fws.gov/service/3-200-10b-migratory-bird-rehabilitation",
          "source_retrieved": "2026-09-08"
        }
      ],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0028",
      "name": "Wildlife rehabilitator",
      "slug": "wildlife-rehabilitator",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_rehab",
        "name": "Wildlife rehabilitation & release",
        "description": "Wildlife rehabilitation, release coordination, and rehabilitation-center operations."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Provides licensed care to injured, orphaned, or displaced wildlife with the goal of recovery and appropriate release, combining husbandry, observation, triage support, and release planning.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Licensed wildlife hospitals, rehabilitation centers, rescue organizations, sanctuaries, and nonprofit wildlife-care programs.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Wildlife Rehabilitator; Rehabilitation Technician; Wildlife Care Specialist",
        "Alternate names / terms": "Wildlife Rehabber; Rehabilitation Specialist",
        "Typical education / progression": "Permits + substantial hands-on experience; B.S. helpful",
        "O*NET / BLS proxy": "Animal Caretakers (39-2021.00)",
        "Job outlook": "7%+ (Much faster than average); ~74,600 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $27,250–$29,820; mid proxy $35,360–$40,050",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UMA-BIO, UMA-AS, URI-AZ",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "C",
        "UMA-BIO": "C",
        "UMA-WEC": "S",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Regulations/experience requirements vary by state and role",
      "dims": [
        1.3,
        1.3,
        1.1,
        3.0,
        2.6,
        1.5,
        2.8,
        2.6,
        2.0,
        1.2
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        27250,
        29820
      ],
      "midSalary": [
        35360,
        40050
      ],
      "observedMarketSalary": {
        "count": 3,
        "observedMin": 37440,
        "observedMax": 45760,
        "medianLow": 37440,
        "medianHigh": 37440,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Rehabilitation Specialist",
        "Wildlife Rehabber",
        "Rehabilitation Technician",
        "Wildlife Care Specialist",
        "Wildlife Rehabilitator"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_release",
          "name": "Reintroduction & release",
          "category": "Applied conservation",
          "description": "Release planning, reintroduction, translocation, and post-release evaluation.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0016",
          "career_id": "cr_0028",
          "title": "Wildlife Care Specialist Hospital",
          "organization": "San Diego Zoo Wildlife Alliance",
          "location": "San Diego, CA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-01",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0049",
          "career_id": "cr_0028",
          "title": "Wildlife Rehabilitation Technician",
          "organization": "Ohio Wildlife Center",
          "location": "Powell, OH",
          "observation_type": "job_posting",
          "observed_date": "2026-08-24",
          "source_id": "src_nwra_tech",
          "notes": "Full-time rehabilitation technician.",
          "source": {
            "source_id": "src_nwra_tech",
            "organization": "Ohio Wildlife Center / NWRA",
            "source_type": "job_posting",
            "title": "Wildlife Rehabilitation Technician",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097691&view=2",
            "published_date": "2026-08-24",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current rehabilitation technician posting."
          }
        },
        {
          "observed_id": "obs_post_0051",
          "career_id": "cr_0028",
          "title": "Wildlife Rehabilitation Specialist",
          "organization": "Chintimini Wildlife Center",
          "location": "Corvallis, OR",
          "observation_type": "job_posting",
          "observed_date": "2026-08-19",
          "source_id": "src_nwra_specialist",
          "notes": "Full-time rehabilitation specialist.",
          "source": {
            "source_id": "src_nwra_specialist",
            "organization": "Chintimini Wildlife Center / NWRA",
            "source_type": "job_posting",
            "title": "Wildlife Rehabilitation Specialist",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097322&view=2",
            "published_date": "2026-08-19",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current rehabilitation specialist posting."
          }
        },
        {
          "observed_id": "obs_post_0030",
          "career_id": "cr_0028",
          "title": "Sea Turtle Rehabilitation Technician",
          "organization": "NC Aquarium on Roanoke Island",
          "location": "Manteo, NC",
          "observation_type": "job_posting",
          "observed_date": "2026-03-18",
          "source_id": "src_aza_jobs",
          "notes": "Observed rehabilitation title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0053",
          "career_id": "cr_0028",
          "title": "Seasonal Avian Care Technician",
          "organization": "Native Songbird Care & Conservation",
          "location": "Sebastopol, CA",
          "observation_type": "job_posting",
          "observed_date": "2026-02-15",
          "source_id": "src_nwra_avian",
          "notes": "Seasonal wildlife-care role.",
          "source": {
            "source_id": "src_nwra_avian",
            "organization": "Native Songbird Care & Conservation / NWRA",
            "source_type": "job_posting",
            "title": "Seasonal Avian Care Technician",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1065489&view=2",
            "published_date": "2026-02-15",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Seasonal rehabilitation posting with salary."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0016",
          "career_id": "cr_0028",
          "title": "Wildlife Care Specialist Hospital",
          "employer": "San Diego Zoo Wildlife Alliance",
          "location": "San Diego, CA",
          "posted_date": "2026-09-01",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS?LOCALE=EN",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0049",
          "career_id": "cr_0028",
          "title": "Wildlife Rehabilitation Technician",
          "employer": "Ohio Wildlife Center",
          "location": "Powell, OH",
          "posted_date": "2026-08-24",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "Bachelor’s",
          "experience_min": "<1 year",
          "salary_min": 18.0,
          "salary_max": 18.0,
          "salary_unit": "hourly",
          "currency": "USD",
          "source_id": "src_nwra_tech",
          "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097691&view=2",
          "active_status": "current_or_recent",
          "notes": "Full-time rehabilitation technician.",
          "source": {
            "source_id": "src_nwra_tech",
            "organization": "Ohio Wildlife Center / NWRA",
            "source_type": "job_posting",
            "title": "Wildlife Rehabilitation Technician",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097691&view=2",
            "published_date": "2026-08-24",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current rehabilitation technician posting."
          }
        },
        {
          "posting_id": "post_0051",
          "career_id": "cr_0028",
          "title": "Wildlife Rehabilitation Specialist",
          "employer": "Chintimini Wildlife Center",
          "location": "Corvallis, OR",
          "posted_date": "2026-08-19",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "Bachelor’s",
          "experience_min": "1–2 years",
          "salary_min": 18.0,
          "salary_max": 18.0,
          "salary_unit": "hourly",
          "currency": "USD",
          "source_id": "src_nwra_specialist",
          "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097322&view=2",
          "active_status": "current_or_recent",
          "notes": "Full-time rehabilitation specialist.",
          "source": {
            "source_id": "src_nwra_specialist",
            "organization": "Chintimini Wildlife Center / NWRA",
            "source_type": "job_posting",
            "title": "Wildlife Rehabilitation Specialist",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097322&view=2",
            "published_date": "2026-08-19",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current rehabilitation specialist posting."
          }
        },
        {
          "posting_id": "post_0030",
          "career_id": "cr_0028",
          "title": "Sea Turtle Rehabilitation Technician",
          "employer": "NC Aquarium on Roanoke Island",
          "location": "Manteo, NC",
          "posted_date": "2026-03-18",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/jobs?job=49122",
          "active_status": "current_or_recent",
          "notes": "Observed rehabilitation title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0053",
          "career_id": "cr_0028",
          "title": "Seasonal Avian Care Technician",
          "employer": "Native Songbird Care & Conservation",
          "location": "Sebastopol, CA",
          "posted_date": "2026-02-15",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "Intermediate/Advanced Wildlife Rehabilitator",
          "experience_min": "1–2 years",
          "salary_min": 20.0,
          "salary_max": 22.0,
          "salary_unit": "hourly",
          "currency": "USD",
          "source_id": "src_nwra_avian",
          "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1065489&view=2",
          "active_status": "current_or_recent",
          "notes": "Seasonal wildlife-care role.",
          "source": {
            "source_id": "src_nwra_avian",
            "organization": "Native Songbird Care & Conservation / NWRA",
            "source_type": "job_posting",
            "title": "Seasonal Avian Care Technician",
            "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1065489&view=2",
            "published_date": "2026-02-15",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Seasonal rehabilitation posting with salary."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0006",
          "entity_type": "career",
          "entity_id": "cr_0028",
          "claim_type": "permit",
          "claim_value": "Federal migratory-bird rehabilitation requires a permit, state compliance, and at least 100 hands-on hours over at least one year for each migratory-bird type.",
          "source_id": "src_fws_rehab",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_fws_rehab",
            "organization": "U.S. Fish and Wildlife Service",
            "source_type": "permit_standard",
            "title": "Migratory Bird Rehabilitation Permit 3-200-10b",
            "url": "https://www.fws.gov/service/3-200-10b-migratory-bird-rehabilitation",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Federal migratory-bird rehabilitation permit and experience requirements."
          }
        }
      ],
      "credentials": [
        {
          "relationship": "required_for_covered_birds",
          "notes": "Federal permit required for migratory-bird rehabilitation; state requirements also apply.",
          "credential_id": "cred_fws_rehab",
          "name": "Federal Migratory Bird Rehabilitation Permit",
          "organization": "U.S. Fish and Wildlife Service",
          "credential_type": "permit",
          "description": "Required to rehabilitate covered migratory birds; current federal requirements include age 18+, at least 100 hands-on hours over at least one year for each bird type, and state compliance.",
          "source_id": "src_fws_rehab",
          "source_url": "https://www.fws.gov/service/3-200-10b-migratory-bird-rehabilitation",
          "source_retrieved": "2026-09-08"
        }
      ],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0026",
      "name": "Wildlife technician / biological science technician",
      "slug": "wildlife-technician-biological-science-technician",
      "category": "Wildlife, rehabilitation & conservation",
      "domain": {
        "id": "dm_wildlife",
        "name": "Wildlife, rehabilitation & conservation",
        "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management."
      },
      "roleFamily": {
        "id": "rf_wildlife_tech",
        "name": "Wildlife field & technical work",
        "description": "Field technicians, monitoring, species surveys, and biological-science technical work."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Collects field data for wildlife or ecological projects: trapping/handling where permitted, surveys, telemetry, habitat measurements, sample collection, data entry, and equipment maintenance.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "State/federal wildlife agencies, NGOs, universities, consulting organizations, rehabilitation centers, refuges, field stations, and conservation project sites.",
        "Undergraduate preparation most useful": "Field sampling; species identification; ecology; statistics; GIS/telemetry where relevant; scientific writing; data management; permits/protocols and safe animal handling where applicable.",
        "Searchable job titles": "Biological Science Technician; Wildlife Technician; Fisheries & Wildlife Technician; Field Technician",
        "Alternate names / terms": "Wildlife Tech; Biological Technician",
        "Typical education / progression": "B.S. common for competitive wildlife positions; some seasonal roles accept less",
        "O*NET / BLS proxy": "Biological Technicians (19-4021.00)",
        "Job outlook": "3%–4% (Average); ~9,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $40,330–$48,130; mid proxy $57,510–$71,520",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, URI-AZ",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-AS"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "S",
        "UMA-AS": "N",
        "UMA-BIO": "S",
        "UMA-WEC": "S",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "Common B.S.-level entry point in wildlife science",
      "dims": [
        1.3,
        0.8,
        1.1,
        3.0,
        2.6,
        1.5,
        3.0,
        2.6,
        2.0,
        1.2
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial"
      ],
      "entrySalary": [
        40330,
        48130
      ],
      "midSalary": [
        57510,
        71520
      ],
      "observedMarketSalary": {
        "count": 2,
        "observedMin": 31200,
        "observedMax": 82007,
        "medianLow": 47140,
        "medianHigh": 58684,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Biological Technician",
        "Wildlife Tech",
        "Biological Science Technician",
        "Field Technician",
        "Fisheries & Wildlife Technician",
        "Wildlife Technician"
      ],
      "competencies": [
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_habitat",
          "name": "Habitat management & restoration",
          "category": "Applied conservation",
          "description": "Habitat assessment, restoration, management, and conservation implementation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_rehab",
          "name": "Wildlife rehabilitation",
          "category": "Applied animal care",
          "description": "Care, restraint, records, recovery, release criteria, and rehabilitation protocols.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_telemetry",
          "name": "Telemetry & movement",
          "category": "Methods",
          "description": "Radio/GPS/acoustic tracking and movement analysis.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0046",
          "career_id": "cr_0026",
          "title": "Avian Use Technician",
          "organization": "Western EcoSystems Technology, Inc.",
          "location": "Lee County, AR",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Current field-tech listing.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        },
        {
          "observed_id": "obs_post_0054",
          "career_id": "cr_0026",
          "title": "Biological Science Technician (Wildlife)",
          "organization": "National Park Service",
          "location": "Point Reyes Station, CA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_usajobs_wildtech",
          "notes": "Permanent career-seasonal GS-7.",
          "source": {
            "source_id": "src_usajobs_wildtech",
            "organization": "National Park Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Biological Science Technician (Wildlife)",
            "url": "https://www.usajobs.gov/job/882687500",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-7 wildlife technician posting."
          }
        },
        {
          "observed_id": "obs_post_0047",
          "career_id": "cr_0026",
          "title": "Chronic Wasting Disease Technician",
          "organization": "Montana Fish, Wildlife & Parks",
          "location": "Montana",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Current disease-monitoring technician listing.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        },
        {
          "observed_id": "obs_post_0048",
          "career_id": "cr_0026",
          "title": "Quail Research Technician",
          "organization": "East Foundation",
          "location": "Hebbronville, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Current research technician listing.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        },
        {
          "observed_id": "obs_post_0035",
          "career_id": "cr_0026",
          "title": "Wildlife Diversity/Natural Heritage Zoology Technician",
          "organization": "West Virginia Division of Natural Resources",
          "location": "Elkins, WV",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_diversitytech",
          "notes": "Temporary biodiversity technician; 50–75% travel.",
          "source": {
            "source_id": "src_tws_diversitytech",
            "organization": "West Virginia DNR / TWS",
            "source_type": "job_posting",
            "title": "Wildlife Diversity/Natural Heritage Zoology Technician",
            "url": "https://careers.wildlife.org/job/wildlife-diversitynatural-heritage-zoology-technician-west-virginia/85441685/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current wildlife-diversity technician posting."
          }
        },
        {
          "observed_id": "obs_post_0019",
          "career_id": "cr_0026",
          "title": "OCIC Field Technician",
          "organization": "Central Florida Zoo",
          "location": "Sanford, FL",
          "observation_type": "job_posting",
          "observed_date": "2026-09-01",
          "source_id": "src_aza_jobs",
          "notes": "Current conservation field role on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0031",
          "career_id": "cr_0026",
          "title": "Conservation Field Technician",
          "organization": "Brevard Zoo",
          "location": "Melbourne, FL",
          "observation_type": "job_posting",
          "observed_date": "2026-03-17",
          "source_id": "src_aza_jobs",
          "notes": "Observed conservation-field title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0046",
          "career_id": "cr_0026",
          "title": "Avian Use Technician",
          "employer": "Western EcoSystems Technology, Inc.",
          "location": "Lee County, AR",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/jobseeker/search/results/function/Field%20Technician/",
          "active_status": "current_or_recent",
          "notes": "Current field-tech listing.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        },
        {
          "posting_id": "post_0054",
          "career_id": "cr_0026",
          "title": "Biological Science Technician (Wildlife)",
          "employer": "National Park Service",
          "location": "Point Reyes Station, CA",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "Graduate education may substitute at GS-7",
          "experience_min": "GS-6 equivalent experience or graduate education",
          "salary_min": 63081.0,
          "salary_max": 82007.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_usajobs_wildtech",
          "url": "https://www.usajobs.gov/job/882687500",
          "active_status": "current_or_recent",
          "notes": "Permanent career-seasonal GS-7.",
          "source": {
            "source_id": "src_usajobs_wildtech",
            "organization": "National Park Service / USAJOBS",
            "source_type": "job_posting",
            "title": "Biological Science Technician (Wildlife)",
            "url": "https://www.usajobs.gov/job/882687500",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Current GS-7 wildlife technician posting."
          }
        },
        {
          "posting_id": "post_0047",
          "career_id": "cr_0026",
          "title": "Chronic Wasting Disease Technician",
          "employer": "Montana Fish, Wildlife & Parks",
          "location": "Montana",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/jobseeker/search/results/function/Field%20Technician/",
          "active_status": "current_or_recent",
          "notes": "Current disease-monitoring technician listing.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        },
        {
          "posting_id": "post_0048",
          "career_id": "cr_0026",
          "title": "Quail Research Technician",
          "employer": "East Foundation",
          "location": "Hebbronville, TX",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/jobs/?keywords=wildlife+technician",
          "active_status": "current_or_recent",
          "notes": "Current research technician listing.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        },
        {
          "posting_id": "post_0035",
          "career_id": "cr_0026",
          "title": "Wildlife Diversity/Natural Heritage Zoology Technician",
          "employer": "West Virginia Division of Natural Resources",
          "location": "Elkins, WV",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "B.A./B.S.",
          "experience_min": "0–1 year",
          "salary_min": 15.0,
          "salary_max": 17.0,
          "salary_unit": "hourly",
          "currency": "USD",
          "source_id": "src_tws_diversitytech",
          "url": "https://careers.wildlife.org/job/wildlife-diversitynatural-heritage-zoology-technician-west-virginia/85441685/",
          "active_status": "current_or_recent",
          "notes": "Temporary biodiversity technician; 50–75% travel.",
          "source": {
            "source_id": "src_tws_diversitytech",
            "organization": "West Virginia DNR / TWS",
            "source_type": "job_posting",
            "title": "Wildlife Diversity/Natural Heritage Zoology Technician",
            "url": "https://careers.wildlife.org/job/wildlife-diversitynatural-heritage-zoology-technician-west-virginia/85441685/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current wildlife-diversity technician posting."
          }
        },
        {
          "posting_id": "post_0019",
          "career_id": "cr_0026",
          "title": "OCIC Field Technician",
          "employer": "Central Florida Zoo",
          "location": "Sanford, FL",
          "posted_date": "2026-09-01",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS?LOCALE=EN",
          "active_status": "current_or_recent",
          "notes": "Current conservation field role on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0031",
          "career_id": "cr_0026",
          "title": "Conservation Field Technician",
          "employer": "Brevard Zoo",
          "location": "Melbourne, FL",
          "posted_date": "2026-03-17",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/jobs?job=49514",
          "active_status": "current_or_recent",
          "notes": "Observed conservation-field title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0078",
      "name": "Zoo / aquarium animal trainer",
      "slug": "zoo-aquarium-animal-trainer",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_zoo_training",
        "name": "Zoo training & ambassador animal programs",
        "description": "Animal training and ambassador-animal care/education within zoological settings."
      },
      "roleKind": "career",
      "marketStatus": "Verified current market titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Uses learning principles and positive-reinforcement training with zoo or aquarium animals for husbandry, cooperative medical behavior, presentations, enrichment, and welfare.",
      "details": {
        "Typical work settings": "Aquariums, zoos, wildlife presentation programs, marine mammal teams, ambassador-animal programs.",
        "Undergraduate preparation most useful": "Learning theory, animal behavior, husbandry, welfare, observation, communication, direct animal experience.",
        "Searchable job titles": "Animal Trainer; Senior Trainer; Assistant Trainer; Marine Mammal Trainer; Behavior Trainer",
        "Alternate names / terms": "Oceanarium trainer; pinniped trainer; animal behavior trainer",
        "Typical education / progression": "B.S. and extensive hands-on training/husbandry experience are common; progression may include senior trainer, supervisor, behavioral husbandry, or program leadership.",
        "O*NET / BLS proxy": "Animal Trainers (broad proxy)",
        "Job outlook": "Use Animal Trainers as a broad benchmark plus zoo/aquarium postings.",
        "Salary context": "Use employer postings; zoo/aquarium trainer pay can differ materially from broad animal-trainer data.",
        "Market status": "Verified current market titles",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "C",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        2.8,
        2.8,
        3.0,
        0.5,
        0.2,
        1.5,
        0.6,
        0.4,
        1.4,
        1.8
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Education / public"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 54080,
        "observedMax": 72800,
        "medianLow": 54080,
        "medianHigh": 72800,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Oceanarium trainer",
        "animal behavior trainer",
        "pinniped trainer",
        "Animal Trainer",
        "Assistant Trainer",
        "Behavior Trainer",
        "Marine Mammal Trainer",
        "Senior Trainer"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0026",
          "career_id": "cr_0078",
          "title": "(Sr.) Trainer",
          "organization": "John G. Shedd Aquarium",
          "location": "Chicago, IL",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_aza_senior_trainer",
          "notes": "Trainer/Senior Trainer pay band.",
          "source": {
            "source_id": "src_aza_senior_trainer",
            "organization": "John G. Shedd Aquarium / AZA",
            "source_type": "job_posting",
            "title": "(Sr.) Trainer",
            "url": "https://www.aza.org/JOBS?job=52529",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Trainer/senior trainer posting with pay range."
          }
        },
        {
          "observed_id": "obs_post_0004",
          "career_id": "cr_0078",
          "title": "Full-Time Animal Trainer",
          "organization": "Natural Encounters, Inc.",
          "location": "Winter Haven, FL",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0014",
          "career_id": "cr_0078",
          "title": "Senior Training - Pinnipeds",
          "organization": "Georgia Aquarium",
          "location": "Atlanta, GA",
          "observation_type": "job_posting",
          "observed_date": "2026-09-02",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0018",
          "career_id": "cr_0078",
          "title": "Assistant Trainer - Belugas",
          "organization": "Mystic Aquarium",
          "location": "Mystic, CT",
          "observation_type": "job_posting",
          "observed_date": "2026-09-01",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0026",
          "career_id": "cr_0078",
          "title": "(Sr.) Trainer",
          "employer": "John G. Shedd Aquarium",
          "location": "Chicago, IL",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": "Level depends on experience",
          "salary_min": 26.0,
          "salary_max": 35.0,
          "salary_unit": "hourly",
          "currency": "USD",
          "source_id": "src_aza_senior_trainer",
          "url": "https://www.aza.org/JOBS?job=52529",
          "active_status": "current_or_recent",
          "notes": "Trainer/Senior Trainer pay band.",
          "source": {
            "source_id": "src_aza_senior_trainer",
            "organization": "John G. Shedd Aquarium / AZA",
            "source_type": "job_posting",
            "title": "(Sr.) Trainer",
            "url": "https://www.aza.org/JOBS?job=52529",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Trainer/senior trainer posting with pay range."
          }
        },
        {
          "posting_id": "post_0004",
          "career_id": "cr_0078",
          "title": "Full-Time Animal Trainer",
          "employer": "Natural Encounters, Inc.",
          "location": "Winter Haven, FL",
          "posted_date": "2026-09-08",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0014",
          "career_id": "cr_0078",
          "title": "Senior Training - Pinnipeds",
          "employer": "Georgia Aquarium",
          "location": "Atlanta, GA",
          "posted_date": "2026-09-02",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/Jobs/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0018",
          "career_id": "cr_0078",
          "title": "Assistant Trainer - Belugas",
          "employer": "Mystic Aquarium",
          "location": "Mystic, CT",
          "posted_date": "2026-09-01",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS?LOCALE=EN",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0013",
          "entity_type": "career",
          "entity_id": "cr_0078",
          "claim_type": "market_title",
          "claim_value": "Current AZA postings include Trainer, Senior Trainer, Assistant Trainer, and species-specific training roles.",
          "source_id": "src_aza_senior_trainer",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_aza_senior_trainer",
            "organization": "John G. Shedd Aquarium / AZA",
            "source_type": "job_posting",
            "title": "(Sr.) Trainer",
            "url": "https://www.aza.org/JOBS?job=52529",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Trainer/senior trainer posting with pay range."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0019",
      "name": "Zoo / aquarium behavioral researcher",
      "slug": "zoo-aquarium-behavioral-researcher",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_welfare_husbandry",
        "name": "Welfare, enrichment & behavioral husbandry",
        "description": "Welfare assessment, enrichment, behavioral husbandry, and applied animal-care behavior."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_function_title_varies",
      "lastVerified": "2026-09-08",
      "roleFocus": "Conducts applied research on behavior, welfare, social relationships, cognition, enrichment, visitor effects, husbandry, or conservation-relevant questions in managed populations.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "Mixed entry path; assistant roles may be B.S.-level, scientist roles generally graduate-level",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Research Coordinator; Research Scientist; Animal Welfare Researcher; Applied Research Coordinator",
        "Alternate names / terms": "Zoo Behavior Researcher; Applied Animal Behavior Researcher",
        "Typical education / progression": "B.S. for assistant/coordinator roles; M.S./Ph.D. common for scientist roles",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "UMA-WEC, ME-WE, URI-W",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-AS, ME-ZOO, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "C",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "C",
        "URI-WZ": "G"
      },
      "notes": "Research-heavy positions commonly require graduate work",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        0.7,
        2.2,
        1.4
      ],
      "directContact": "High",
      "educationBand": "Graduate degree typical",
      "careerStage": "variable",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Applied Animal Behavior Researcher",
        "Zoo Behavior Researcher",
        "Animal Welfare Researcher",
        "Applied Research Coordinator",
        "Research Coordinator",
        "Research Scientist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0068",
      "name": "Zoo / aquarium educator",
      "slug": "zoo-aquarium-educator",
      "category": "Education, outreach & science communication",
      "domain": {
        "id": "dm_education",
        "name": "Education, outreach & communication",
        "description": "Interpretation, education, outreach, museums, collections, and science communication."
      },
      "roleFamily": {
        "id": "rf_zoo_education",
        "name": "Zoo/aquarium education",
        "description": "Zoo/aquarium education, interpretation, and public programs."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Develops and delivers public or school programs about animals, conservation, biology, welfare, and institutional missions, often using live interpretation and exhibit-based learning.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos/aquariums, museums, parks/refuges, nature centers, schools, NGOs, government outreach programs, publishers, and scientific organizations.",
        "Undergraduate preparation most useful": "Strong biological content knowledge; writing and presentation; audience-centered communication; interpretation/teaching; program organization; research literacy.",
        "Searchable job titles": "Zoo Educator; Conservation Educator; Education Specialist; Interpreter",
        "Alternate names / terms": "Aquarium Educator; Zoo Education Specialist",
        "Typical education / progression": "B.S. often preferred; communication/teaching experience important",
        "O*NET / BLS proxy": "Park Naturalists (19-1031.03)",
        "Job outlook": "3%–4% (Average; Conservation Scientists proxy); ~2,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $47,550–$57,700; mid proxy $73,010–$91,560",
        "Proxy fit": "Low",
        "Strong/direct paths": "UNE-AB, UNE-AN, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "C",
        "UMA-AS": "C",
        "UMA-BIO": "C",
        "UMA-WEC": "C",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "URI Zoo certificate adds direct institutional relevance",
      "dims": [
        1.3,
        1.0,
        1.2,
        1.3,
        0.3,
        1.0,
        2.2,
        0.8,
        1.4,
        3.0
      ],
      "directContact": "Moderate",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Education / public",
        "Research"
      ],
      "entrySalary": [
        47550,
        57700
      ],
      "midSalary": [
        73010,
        91560
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Aquarium Educator",
        "Zoo Education Specialist",
        "Conservation Educator",
        "Education Specialist",
        "Interpreter",
        "Zoo Educator"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0033",
          "career_id": "cr_0068",
          "title": "School & Teacher Programs Coordinator - Education",
          "organization": "Aquarium of the Pacific",
          "location": "Long Beach, CA",
          "observation_type": "job_posting",
          "observed_date": "2026-05-22",
          "source_id": "src_aza_jobs",
          "notes": "Observed education-program title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0033",
          "career_id": "cr_0068",
          "title": "School & Teacher Programs Coordinator - Education",
          "employer": "Aquarium of the Pacific",
          "location": "Long Beach, CA",
          "posted_date": "2026-05-22",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/jobs?job=50913",
          "active_status": "current_or_recent",
          "notes": "Observed education-program title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0018",
      "name": "Zoo / aquarium welfare specialist",
      "slug": "zoo-aquarium-welfare-specialist",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_welfare_husbandry",
        "name": "Welfare, enrichment & behavioral husbandry",
        "description": "Welfare assessment, enrichment, behavioral husbandry, and applied animal-care behavior."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Evaluates and improves welfare across animal programs using behavior, physiology, environmental design, staff practices, enrichment, and evidence-based assessment.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Welfare assessment, behavioral observation, husbandry, enrichment/training principles, evidence evaluation, statistics/research literacy, and staff communication.",
        "Searchable job titles": "Animal Welfare Specialist; Animal Welfare Scientist; Applied Animal Welfare Manager",
        "Alternate names / terms": "Zoo Welfare Specialist; Welfare & Behavior Specialist",
        "Typical education / progression": "B.S./M.S. depending applied vs scientist role",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UNE-AB, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, ME-ZOO",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Weakly aligned paths": "UMA-WEC, ME-WE, URI-W"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "G",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "SG",
        "UNE-AN": "G",
        "URI-AZ": "SG",
        "URI-W": "N",
        "URI-WZ": "SG"
      },
      "notes": "B.S. may support applied entry roles; scientist/specialist progression often graduate-level",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        2.2,
        1.9,
        1.2,
        2.2,
        1.4
      ],
      "directContact": "Moderate",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Welfare & Behavior Specialist",
        "Zoo Welfare Specialist",
        "Animal Welfare Scientist",
        "Animal Welfare Specialist",
        "Applied Animal Welfare Manager"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0023",
      "name": "Zoo animal curator",
      "slug": "zoo-animal-curator",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_zoo_science_leadership",
        "name": "Zoo research, conservation & leadership",
        "description": "Zoo/aquarium research, conservation coordination, collection leadership, and curation."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "A later-career leadership role overseeing animal collections, staff, husbandry standards, welfare, acquisitions/transfers, breeding plans, budgets, and often conservation or research priorities.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "Experience-driven later-career / management role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Animal Curator; Curator of Animals; Zoological Curator; General Curator",
        "Alternate names / terms": "Zoo Curator; Animal Collection Curator",
        "Typical education / progression": "Later-career; B.S./M.S. plus substantial keeper/management experience",
        "O*NET / BLS proxy": "Natural Sciences Managers (11-9121.00)",
        "Job outlook": "3%–4% (Average); ~8,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $79,710–$119,430; mid proxy $167,220–$221,540",
        "Proxy fit": "Low",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "None identified",
        "Later-career pathway": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "C*",
        "ME-ZOO": "C*",
        "UMA-AS": "C*",
        "UMA-BIO": "C*",
        "UMA-WEC": "C*",
        "UNE-AB": "C*",
        "UNE-AN": "C*",
        "URI-AZ": "C*",
        "URI-W": "C*",
        "URI-WZ": "C*"
      },
      "notes": "Later-career role; substantial keeper, management and/or research experience usually required",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        2.2,
        1.9,
        0.7,
        2.2,
        1.4
      ],
      "directContact": "High",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "leadership",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        79710,
        119430
      ],
      "midSalary": [
        167220,
        221540
      ],
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 68000,
        "observedMax": 68000,
        "medianLow": 68000,
        "medianHigh": 68000,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Animal Collection Curator",
        "Zoo Curator",
        "Animal Curator",
        "Curator of Animals",
        "General Curator",
        "Zoological Curator"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0007",
          "career_id": "cr_0023",
          "title": "Animal Curator",
          "organization": "Mesker Park Zoo and Botanic Garden",
          "location": "Evansville, IN",
          "observation_type": "job_posting",
          "observed_date": "2026-09-06",
          "source_id": "src_aza_curator",
          "notes": "Current posting.",
          "source": {
            "source_id": "src_aza_curator",
            "organization": "Mesker Park Zoo / AZA",
            "source_type": "job_posting",
            "title": "Animal Curator",
            "url": "https://www.aza.org/Jobs/?job=52644",
            "published_date": "2026-09-06",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current curator posting with salary."
          }
        },
        {
          "observed_id": "obs_post_0008",
          "career_id": "cr_0023",
          "title": "Assistant / Associate Curator (Avian Team)",
          "organization": "Akron Zoo",
          "location": "Akron, OH",
          "observation_type": "job_posting",
          "observed_date": "2026-09-04",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0007",
          "career_id": "cr_0023",
          "title": "Animal Curator",
          "employer": "Mesker Park Zoo and Botanic Garden",
          "location": "Evansville, IN",
          "posted_date": "2026-09-06",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": "5 years animal curator preferred",
          "salary_min": 68000.0,
          "salary_max": 68000.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_curator",
          "url": "https://www.aza.org/Jobs/?job=52644",
          "active_status": "current_or_recent",
          "notes": "Current posting.",
          "source": {
            "source_id": "src_aza_curator",
            "organization": "Mesker Park Zoo / AZA",
            "source_type": "job_posting",
            "title": "Animal Curator",
            "url": "https://www.aza.org/Jobs/?job=52644",
            "published_date": "2026-09-06",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current curator posting with salary."
          }
        },
        {
          "posting_id": "post_0008",
          "career_id": "cr_0023",
          "title": "Assistant / Associate Curator (Avian Team)",
          "employer": "Akron Zoo",
          "location": "Akron, OH",
          "posted_date": "2026-09-04",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0077",
      "name": "Zoo animal nutritionist / nutrition coordinator",
      "slug": "zoo-animal-nutritionist-nutrition-coordinator",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_records_nutrition",
        "name": "Records, nutrition & collection operations",
        "description": "Animal records/permits, nutrition, and collection planning/operations."
      },
      "roleKind": "career",
      "marketStatus": "Verified current market titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Plans, prepares, evaluates, and manages diets and food systems for zoological collections, often working with keepers, veterinarians, commissary staff, and animal-management teams.",
      "details": {
        "Typical work settings": "Zoo/aquarium nutrition departments, commissaries, conservation centers, research programs.",
        "Undergraduate preparation most useful": "Animal physiology, nutrition, chemistry, biology, statistics, animal management, research methods.",
        "Searchable job titles": "Animal Nutrition Coordinator; Zoo Nutritionist; Animal Nutrition Manager; Commissary Coordinator",
        "Alternate names / terms": "Zoological nutrition; zoo commissary; animal diet management",
        "Typical education / progression": "B.S. may support technician/coordinator work; specialized nutrition science and leadership can favor graduate study or substantial experience.",
        "Job outlook": "No dedicated zoo-nutrition occupation; use employer postings and related animal-science benchmarks.",
        "Salary context": "Use employer postings and related animal-science/nutrition benchmarks.",
        "Market status": "Verified current market titles",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "S",
        "URI-W": "N",
        "URI-WZ": "C"
      },
      "notes": "",
      "dims": [
        0.4,
        1.7,
        2.7,
        0.2,
        0.2,
        2.5,
        0.4,
        1.1,
        1.6,
        0.5
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Zoological nutrition",
        "animal diet management",
        "zoo commissary",
        "Animal Nutrition Coordinator",
        "Animal Nutrition Manager",
        "Commissary Coordinator",
        "Zoo Nutritionist"
      ],
      "competencies": [
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_nutrition",
          "name": "Animal nutrition",
          "category": "Applied animal care",
          "description": "Diet formulation, food systems, nutrition science, and feeding management.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0013",
          "career_id": "cr_0077",
          "title": "Animal Nutrition Coordinator",
          "organization": "Houston Zoo",
          "location": "Houston, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-09-03",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0029",
          "career_id": "cr_0077",
          "title": "Animal Nutrition Manager",
          "organization": "Jacksonville Zoo & Botanical Gardens",
          "location": "Jacksonville, FL",
          "observation_type": "job_posting",
          "observed_date": "2026-04-16",
          "source_id": "src_aza_jobs",
          "notes": "Observed zoo nutrition-management title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0013",
          "career_id": "cr_0077",
          "title": "Animal Nutrition Coordinator",
          "employer": "Houston Zoo",
          "location": "Houston, TX",
          "posted_date": "2026-09-03",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/Jobs/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0029",
          "career_id": "cr_0077",
          "title": "Animal Nutrition Manager",
          "employer": "Jacksonville Zoo & Botanical Gardens",
          "location": "Jacksonville, FL",
          "posted_date": "2026-04-16",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/jobs?job=49490",
          "active_status": "current_or_recent",
          "notes": "Observed zoo nutrition-management title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0017",
      "name": "Zoo behavioral-husbandry specialist",
      "slug": "zoo-behavioral-husbandry-specialist",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_behavior",
        "name": "Animal behavior, cognition & welfare",
        "description": "Behavioral science, welfare, training, enrichment, and applied behavior."
      },
      "roleFamily": {
        "id": "rf_welfare_husbandry",
        "name": "Welfare, enrichment & behavioral husbandry",
        "description": "Welfare assessment, enrichment, behavioral husbandry, and applied animal-care behavior."
      },
      "roleKind": "career",
      "marketStatus": "R — Real work/function; employers commonly use other titles",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Specializes within zoo animal care in training, enrichment, welfare monitoring, cooperative medical behaviors, and behavior-informed management.",
      "details": {
        "Market status": "R — Real work/function; employers commonly use other titles",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Behavioral Husbandry Manager; Keeper/Trainer; Animal Behavior Manager",
        "Alternate names / terms": "Zoo Behavioral Husbandry Specialist; Training Coordinator",
        "Typical education / progression": "B.S. plus keeper/training experience",
        "O*NET / BLS proxy": "Animal Trainers (39-2011.00)",
        "Job outlook": "5%–6% (Faster than average); ~7,100 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $29,600–$33,740; mid proxy $39,990–$53,580",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, ME-ZOO, URI-W",
        "Graduate-oriented foundations": "None identified",
        "Weakly aligned paths": "UMA-WEC, ME-WE"
      },
      "support": {
        "ME-WE": "N",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "N",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "Behavior + husbandry combination",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        1.2,
        2.2,
        1.4
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        29600,
        33740
      ],
      "midSalary": [
        39990,
        53580
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Training Coordinator",
        "Zoo Behavioral Husbandry Specialist",
        "Animal Behavior Manager",
        "Behavioral Husbandry Manager",
        "Keeper/Trainer"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_public",
          "name": "Public education & stakeholder communication",
          "category": "Professional",
          "description": "Teaching, interpretation, outreach, client/stakeholder communication.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0020",
          "career_id": "cr_0017",
          "title": "Curator of Behavioral Husbandry",
          "organization": "Gladys Porter Zoo",
          "location": "Brownsville, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-06-18",
          "source_id": "src_aza_curator_behavior",
          "notes": "Institution-wide behavioral-husbandry leadership.",
          "source": {
            "source_id": "src_aza_curator_behavior",
            "organization": "Gladys Porter Zoo / AZA",
            "source_type": "job_posting",
            "title": "Curator of Behavioral Husbandry",
            "url": "https://www.aza.org/jobs?job=51772",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Detailed role posting."
          }
        },
        {
          "observed_id": "obs_post_0021",
          "career_id": "cr_0017",
          "title": "Wildlife Care Specialist, Behavior",
          "organization": "San Diego Zoo Wildlife Alliance",
          "location": "Escondido, CA",
          "observation_type": "job_posting",
          "observed_date": "2026-06-04",
          "source_id": "src_aza_wildlife_behavior",
          "notes": "Training, handling, care, and public-program wildlife role.",
          "source": {
            "source_id": "src_aza_wildlife_behavior",
            "organization": "San Diego Zoo Wildlife Alliance / AZA",
            "source_type": "job_posting",
            "title": "Wildlife Care Specialist, Behavior",
            "url": "https://www.aza.org/jobs?job=51629",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Behavior/training wildlife-care posting."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0020",
          "career_id": "cr_0017",
          "title": "Curator of Behavioral Husbandry",
          "employer": "Gladys Porter Zoo",
          "location": "Brownsville, TX",
          "posted_date": "2026-06-18",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": "Highly experienced",
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_curator_behavior",
          "url": "https://www.aza.org/jobs?job=51772",
          "active_status": "current_or_recent",
          "notes": "Institution-wide behavioral-husbandry leadership.",
          "source": {
            "source_id": "src_aza_curator_behavior",
            "organization": "Gladys Porter Zoo / AZA",
            "source_type": "job_posting",
            "title": "Curator of Behavioral Husbandry",
            "url": "https://www.aza.org/jobs?job=51772",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Detailed role posting."
          }
        },
        {
          "posting_id": "post_0021",
          "career_id": "cr_0017",
          "title": "Wildlife Care Specialist, Behavior",
          "employer": "San Diego Zoo Wildlife Alliance",
          "location": "Escondido, CA",
          "posted_date": "2026-06-04",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_wildlife_behavior",
          "url": "https://www.aza.org/jobs?job=51629",
          "active_status": "current_or_recent",
          "notes": "Training, handling, care, and public-program wildlife role.",
          "source": {
            "source_id": "src_aza_wildlife_behavior",
            "organization": "San Diego Zoo Wildlife Alliance / AZA",
            "source_type": "job_posting",
            "title": "Wildlife Care Specialist, Behavior",
            "url": "https://www.aza.org/jobs?job=51629",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Behavior/training wildlife-care posting."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0012",
          "entity_type": "career",
          "entity_id": "cr_0017",
          "claim_type": "market_title",
          "claim_value": "Current/recent AZA postings include Curator of Behavioral Husbandry and Wildlife Care Specialist, Behavior.",
          "source_id": "src_aza_curator_behavior",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_aza_curator_behavior",
            "organization": "Gladys Porter Zoo / AZA",
            "source_type": "job_posting",
            "title": "Curator of Behavioral Husbandry",
            "url": "https://www.aza.org/jobs?job=51772",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Detailed role posting."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0024",
      "name": "Zoo conservation coordinator",
      "slug": "zoo-conservation-coordinator",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_zoo_science_leadership",
        "name": "Zoo research, conservation & leadership",
        "description": "Zoo/aquarium research, conservation coordination, collection leadership, and curation."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "Connects zoo resources to field or ex-situ conservation programs through project coordination, partnerships, grant/program administration, research, and conservation planning.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Conservation & Research Coordinator; Conservation Program Coordinator; Field Conservation Coordinator",
        "Alternate names / terms": "Zoo Conservation Coordinator; Conservation Programs Manager",
        "Typical education / progression": "B.S./M.S. plus program/research experience",
        "O*NET / BLS proxy": "Conservation Scientists (19-1031.00)",
        "Job outlook": "3%–4% (Average); ~2,500 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $47,550–$57,700; mid proxy $73,010–$91,560",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "UMA-WEC, ME-WE, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, UMA-AS, URI-AZ",
        "Graduate-oriented foundations": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W, URI-WZ"
      },
      "support": {
        "ME-WE": "SG",
        "ME-ZOO": "G",
        "UMA-AS": "C",
        "UMA-BIO": "G",
        "UMA-WEC": "SG",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "SG",
        "URI-WZ": "SG"
      },
      "notes": "Wildlife tracks especially strong for conservation side",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        0.7,
        2.2,
        1.4
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        47550,
        57700
      ],
      "midSalary": [
        73010,
        91560
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Conservation Programs Manager",
        "Zoo Conservation Coordinator",
        "Conservation & Research Coordinator",
        "Conservation Program Coordinator",
        "Field Conservation Coordinator"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0076",
      "name": "Zoo registrar / animal records & permits specialist",
      "slug": "zoo-registrar-animal-records-permits-specialist",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_records_nutrition",
        "name": "Records, nutrition & collection operations",
        "description": "Animal records/permits, nutrition, and collection planning/operations."
      },
      "roleKind": "career",
      "marketStatus": "Verified current market title",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Maintains animal records, permits, inventories, transfers, regulatory documentation, and institutional animal databases such as ZIMS; may coordinate transaction, training, enrichment, and diet records.",
      "details": {
        "Typical work settings": "Zoos, aquariums, wildlife centers, and conservation breeding institutions.",
        "Undergraduate preparation most useful": "Animal biology/management, database skills, records management, permits/regulation, scientific writing, attention to detail.",
        "Searchable job titles": "Registrar; Animal Registrar; Wildlife Records Specialist; Animal Records Coordinator",
        "Alternate names / terms": "ZIMS registrar; animal records; permits and transactions",
        "Typical education / progression": "B.S. in biology, zoology, animal science or related field plus records/database experience is common; specialized records training can be valuable.",
        "Job outlook": "No dedicated O*NET occupation; validate through zoo/aquarium postings.",
        "Salary context": "Use employer postings and institutional salary ranges rather than animal-caretaker proxies.",
        "Market status": "Verified current market title",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "C",
        "UMA-AS": "C",
        "UMA-BIO": "C",
        "UMA-WEC": "C",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "",
      "dims": [
        0.7,
        1.0,
        2.6,
        0.5,
        0.3,
        0.7,
        1.2,
        2.3,
        1.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Conservation",
        "Data / statistics"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "ZIMS registrar",
        "animal records",
        "permits and transactions",
        "Animal Records Coordinator",
        "Animal Registrar",
        "Registrar",
        "Wildlife Records Specialist"
      ],
      "competencies": [
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_records",
          "name": "Animal records & databases",
          "category": "Professional",
          "description": "ZIMS/records systems, inventories, permits, transactions, and data stewardship.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0025",
          "career_id": "cr_0076",
          "title": "Registrar",
          "organization": "Lee Richardson Zoo",
          "location": "Garden City, KS",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_aza_registrar",
          "notes": "Records, permits, transfers, ZIMS, behavior/enrichment/training/diet databases.",
          "source": {
            "source_id": "src_aza_registrar",
            "organization": "Lee Richardson Zoo / AZA",
            "source_type": "job_posting",
            "title": "Registrar",
            "url": "https://www.aza.org/Jobs?job=52409",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Animal records, permits, transfer, ZIMS, and database role."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0025",
          "career_id": "cr_0076",
          "title": "Registrar",
          "employer": "Lee Richardson Zoo",
          "location": "Garden City, KS",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "College degree preferred",
          "experience_min": "3+ years related experience preferred",
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_registrar",
          "url": "https://www.aza.org/Jobs?job=52409",
          "active_status": "current_or_recent",
          "notes": "Records, permits, transfers, ZIMS, behavior/enrichment/training/diet databases.",
          "source": {
            "source_id": "src_aza_registrar",
            "organization": "Lee Richardson Zoo / AZA",
            "source_type": "job_posting",
            "title": "Registrar",
            "url": "https://www.aza.org/Jobs?job=52409",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Animal records, permits, transfer, ZIMS, and database role."
          }
        }
      ],
      "evidence": [
        {
          "evidence_id": "ev_0011",
          "entity_type": "career",
          "entity_id": "cr_0076",
          "claim_type": "market_title",
          "claim_value": "Current/recent AZA postings verify Registrar as a dedicated zoo role managing records, permits, transfers, ZIMS, and related databases.",
          "source_id": "src_aza_registrar",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_aza_registrar",
            "organization": "Lee Richardson Zoo / AZA",
            "source_type": "job_posting",
            "title": "Registrar",
            "url": "https://www.aza.org/Jobs?job=52409",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Animal records, permits, transfer, ZIMS, and database role."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0025",
      "name": "Zoo research coordinator",
      "slug": "zoo-research-coordinator",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_zoo_science_leadership",
        "name": "Zoo research, conservation & leadership",
        "description": "Zoo/aquarium research, conservation coordination, collection leadership, and curation."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Organizes and supports institutional research, including project review, data collection, student collaborations, permits/ethics processes, records, and communication of findings.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Research Coordinator; Assistant Research Coordinator; Zoo Research Manager",
        "Alternate names / terms": "Applied Research Coordinator; Conservation Research Coordinator",
        "Typical education / progression": "B.S./M.S. plus research experience",
        "O*NET / BLS proxy": "Biologists / Biological Scientists, All Other (19-1029.04 / 19-1029.00)",
        "Job outlook": "1%–2% (Slower than average); ~4,800 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $60,430–$76,800; mid proxy $98,920–$127,670",
        "Proxy fit": "Moderate",
        "Strong/direct paths": "None identified",
        "Credible with planning": "None identified",
        "Graduate-oriented foundations": "UNE-AB, UNE-AN, UMA-BIO, UMA-WEC, UMA-AS, ME-WE, ME-ZOO, URI-W, URI-WZ, URI-AZ"
      },
      "support": {
        "ME-WE": "G",
        "ME-ZOO": "G",
        "UMA-AS": "G",
        "UMA-BIO": "G",
        "UMA-WEC": "G",
        "UNE-AB": "G",
        "UNE-AN": "G",
        "URI-AZ": "G",
        "URI-W": "G",
        "URI-WZ": "G"
      },
      "notes": "Generally advanced research/management position",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        1.2,
        2.2,
        1.4
      ],
      "directContact": "Low / variable",
      "educationBand": "B.S. + graduate study often useful",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        60430,
        76800
      ],
      "midSalary": [
        98920,
        127670
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Applied Research Coordinator",
        "Conservation Research Coordinator",
        "Assistant Research Coordinator",
        "Research Coordinator",
        "Zoo Research Manager"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_regulatory",
          "name": "Permits, regulation & policy",
          "category": "Professional",
          "description": "Permitting, legal/regulatory frameworks, compliance, and agency procedures.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0034",
          "career_id": "cr_0025",
          "title": "Assistant Research Coordinator",
          "organization": "Wildlife Conservation Society",
          "location": "New York, NY",
          "observation_type": "job_posting",
          "observed_date": "2026-04-17",
          "source_id": "src_aza_jobs",
          "notes": "Observed research coordination title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0034",
          "career_id": "cr_0025",
          "title": "Assistant Research Coordinator",
          "employer": "Wildlife Conservation Society",
          "location": "New York, NY",
          "posted_date": "2026-04-17",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/jobs?job=49073",
          "active_status": "current_or_recent",
          "notes": "Observed research coordination title.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0014",
      "name": "Zookeeper / animal-care specialist",
      "slug": "zookeeper-animal-care-specialist",
      "category": "Zoos, aquariums, sanctuaries & managed wildlife",
      "domain": {
        "id": "dm_managed",
        "name": "Zoos, aquariums & managed animals",
        "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings."
      },
      "roleFamily": {
        "id": "rf_animal_care",
        "name": "Animal care & husbandry",
        "description": "Daily care, keeper work, sanctuary care, and managed-animal husbandry."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Provides daily husbandry: feeding, cleaning, observation, recordkeeping, enrichment, training, enclosure care, and communication with veterinary/behavioral staff.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "B.S.-accessible or experience-driven professional role",
        "Typical work settings": "Zoos, aquariums, sanctuaries, conservation-breeding centers, wildlife parks, and affiliated research/conservation programs.",
        "Undergraduate preparation most useful": "Animal husbandry and welfare; behavioral observation; enrichment/training; species natural history; recordkeeping; research literacy; communication and teamwork.",
        "Searchable job titles": "Zookeeper; Animal Keeper; Animal Care Specialist; Keeper",
        "Alternate names / terms": "Zoo Keeper; Animal Care Keeper",
        "Typical education / progression": "B.S. increasingly common; extensive internships/animal experience crucial",
        "O*NET / BLS proxy": "Animal Caretakers (39-2021.00)",
        "Job outlook": "7%+ (Much faster than average); ~74,600 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $27,250–$29,820; mid proxy $35,360–$40,050",
        "Proxy fit": "High",
        "Strong/direct paths": "UNE-AB, UNE-AN, UMA-AS, URI-WZ, URI-AZ",
        "Credible with planning": "UMA-BIO, UMA-WEC, ME-WE, ME-ZOO, URI-W",
        "Graduate-oriented foundations": "None identified"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "C",
        "UMA-AS": "S",
        "UMA-BIO": "C",
        "UMA-WEC": "C",
        "UNE-AB": "S",
        "UNE-AN": "S",
        "URI-AZ": "S",
        "URI-W": "C",
        "URI-WZ": "S"
      },
      "notes": "Internship/animal-care experience remains critical regardless of major",
      "dims": [
        2.5,
        3.0,
        3.0,
        1.3,
        1.4,
        1.7,
        1.9,
        0.7,
        2.2,
        1.4
      ],
      "directContact": "High",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Animal care",
        "Behavior / training",
        "Conservation",
        "Fieldwork",
        "Research"
      ],
      "entrySalary": [
        27250,
        29820
      ],
      "midSalary": [
        35360,
        40050
      ],
      "observedMarketSalary": {
        "count": 1,
        "observedMin": 44512,
        "observedMax": 56472,
        "medianLow": 44512,
        "medianHigh": 56472,
        "basis": "Current/recent job-posting observations; not a national wage estimate."
      },
      "aliases": [
        "Animal Care Keeper",
        "Zoo Keeper",
        "Animal Care Specialist",
        "Animal Keeper",
        "Keeper",
        "Zookeeper"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_husbandry",
          "name": "Animal husbandry",
          "category": "Applied animal care",
          "description": "Feeding, sanitation, handling, recordkeeping, enclosure care, and daily management.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_welfare",
          "name": "Welfare assessment",
          "category": "Behavior & welfare",
          "description": "Assessing physical/behavioral welfare and quality of life.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0002",
          "career_id": "cr_0014",
          "title": "Herpetology Keeper I or II",
          "organization": "Nashville Zoo",
          "location": "Nashville, TN",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0001",
          "career_id": "cr_0014",
          "title": "Primates - Animal Care Specialist",
          "organization": "Brookfield Zoo Chicago",
          "location": "Brookfield, IL",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0006",
          "career_id": "cr_0014",
          "title": "Animal Care Specialist",
          "organization": "Greenville Zoo",
          "location": "Greenville, SC",
          "observation_type": "job_posting",
          "observed_date": "2026-09-07",
          "source_id": "src_aza_animalcare",
          "notes": "Current posting; related college degree preferred.",
          "source": {
            "source_id": "src_aza_animalcare",
            "organization": "Greenville Zoo / AZA",
            "source_type": "job_posting",
            "title": "Animal Care Specialist",
            "url": "https://www.aza.org/JOBS?job=52646",
            "published_date": "2026-09-07",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current animal-care posting with salary and education/experience."
          }
        },
        {
          "observed_id": "obs_post_0005",
          "career_id": "cr_0014",
          "title": "Animal Keeper I",
          "organization": "Sunset Zoo",
          "location": "Manhattan, KS",
          "observation_type": "job_posting",
          "observed_date": "2026-09-07",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0009",
          "career_id": "cr_0014",
          "title": "Elephant Keeper",
          "organization": "Fort Worth Zoo",
          "location": "Fort Worth, TX",
          "observation_type": "job_posting",
          "observed_date": "2026-09-04",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "observed_id": "obs_post_0011",
          "career_id": "cr_0014",
          "title": "Pachyderm Animal Care Support Tech",
          "organization": "Oklahoma City Zoo",
          "location": "Oklahoma City, OK",
          "observation_type": "job_posting",
          "observed_date": "2026-09-04",
          "source_id": "src_aza_jobs",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0002",
          "career_id": "cr_0014",
          "title": "Herpetology Keeper I or II",
          "employer": "Nashville Zoo",
          "location": "Nashville, TN",
          "posted_date": "2026-09-08",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0001",
          "career_id": "cr_0014",
          "title": "Primates - Animal Care Specialist",
          "employer": "Brookfield Zoo Chicago",
          "location": "Brookfield, IL",
          "posted_date": "2026-09-08",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0006",
          "career_id": "cr_0014",
          "title": "Animal Care Specialist",
          "employer": "Greenville Zoo",
          "location": "Greenville, SC",
          "posted_date": "2026-09-07",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": "High school; related associate/bachelor preferred",
          "experience_min": "1 year professional exotic animal care",
          "salary_min": 44512.0,
          "salary_max": 56472.0,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_animalcare",
          "url": "https://www.aza.org/JOBS?job=52646",
          "active_status": "current_or_recent",
          "notes": "Current posting; related college degree preferred.",
          "source": {
            "source_id": "src_aza_animalcare",
            "organization": "Greenville Zoo / AZA",
            "source_type": "job_posting",
            "title": "Animal Care Specialist",
            "url": "https://www.aza.org/JOBS?job=52646",
            "published_date": "2026-09-07",
            "retrieved_date": "2026-09-08",
            "authority_tier": "C",
            "notes": "Current animal-care posting with salary and education/experience."
          }
        },
        {
          "posting_id": "post_0005",
          "career_id": "cr_0014",
          "title": "Animal Keeper I",
          "employer": "Sunset Zoo",
          "location": "Manhattan, KS",
          "posted_date": "2026-09-07",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0009",
          "career_id": "cr_0014",
          "title": "Elephant Keeper",
          "employer": "Fort Worth Zoo",
          "location": "Fort Worth, TX",
          "posted_date": "2026-09-04",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        },
        {
          "posting_id": "post_0011",
          "career_id": "cr_0014",
          "title": "Pachyderm Animal Care Support Tech",
          "employer": "Oklahoma City Zoo",
          "location": "Oklahoma City, OK",
          "posted_date": "2026-09-04",
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_aza_jobs",
          "url": "https://www.aza.org/JOBS/",
          "active_status": "current_or_recent",
          "notes": "Current on AZA board.",
          "source": {
            "source_id": "src_aza_jobs",
            "organization": "Association of Zoos and Aquariums",
            "source_type": "job_board",
            "title": "AZA Career Center",
            "url": "https://www.aza.org/Jobs/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current and recent zoo/aquarium job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    },
    {
      "id": "cr_0040",
      "name": "Zoologist",
      "slug": "zoologist",
      "category": "Organismal biology & ecological science",
      "domain": {
        "id": "dm_organismal",
        "name": "Organismal & evolutionary biology",
        "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history."
      },
      "roleFamily": {
        "id": "rf_taxon",
        "name": "Taxon & natural-history specialists",
        "description": "Zoology and organismal specialties such as mammalogy, ornithology, and herpetology."
      },
      "roleKind": "career",
      "marketStatus": "E — Exact or near-exact occupation/title verified",
      "evidenceStatus": "verified_occupation_or_title",
      "lastVerified": "2026-09-08",
      "roleFocus": "A broad animal-biological occupation covering the study of animal species, anatomy, behavior, ecology, evolution, physiology, distribution, or conservation; specific job titles often identify the taxon or method.",
      "details": {
        "Market status": "E — Exact or near-exact occupation/title verified",
        "Career type": "Mixed entry path; assistant roles may be B.S.-level, scientist roles generally graduate-level",
        "Typical work settings": "Universities, museums/natural-history collections, government agencies, field stations, conservation organizations, and biological research programs.",
        "Undergraduate preparation most useful": "Broad animal biology; evolution/ecology/physiology; field or laboratory methods; statistics; species identification; scientific writing; faculty-mentored research.",
        "Searchable job titles": "Zoologist; Research Zoologist; Vertebrate Zoologist",
        "Alternate names / terms": "Animal Biologist; Zoological Researcher",
        "Typical education / progression": "B.S. for technical roles; M.S./Ph.D. for independent research",
        "O*NET / BLS proxy": "Zoologists and Wildlife Biologists (19-1023.00)",
        "Job outlook": "1%–2% (Slower than average); ~1,400 annual openings in the proxy occupation",
        "Salary context": "Entry proxy $49,100–$61,180; mid proxy $76,780–$96,100",
        "Proxy fit": "High",
        "Strong/direct paths": "UMA-BIO, ME-WE, ME-ZOO, URI-W, URI-WZ",
        "Credible with planning": "UNE-AB, UNE-AN, UMA-WEC, URI-AZ",
        "Graduate-oriented foundations": "UMA-BIO, ME-ZOO",
        "Weakly aligned paths": "UMA-AS"
      },
      "support": {
        "ME-WE": "S",
        "ME-ZOO": "SG",
        "UMA-AS": "N",
        "UMA-BIO": "SG",
        "UMA-WEC": "C",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "S",
        "URI-WZ": "S"
      },
      "notes": "“Zoologist” spans B.S.-level technical roles through graduate research",
      "dims": [
        2.0,
        0.5,
        0.9,
        2.5,
        0.5,
        3.0,
        2.5,
        1.8,
        3.0,
        1.3
      ],
      "directContact": "Low / variable",
      "educationBand": "Graduate degree typical",
      "careerStage": "professional_or_specialist",
      "workTags": [
        "Behavior / training",
        "Conservation",
        "Data / statistics",
        "Fieldwork",
        "GIS / spatial",
        "Research"
      ],
      "entrySalary": [
        49100,
        61180
      ],
      "midSalary": [
        76780,
        96100
      ],
      "observedMarketSalary": null,
      "aliases": [
        "Animal Biologist",
        "Zoological Researcher",
        "Research Zoologist",
        "Vertebrate Zoologist",
        "Zoologist"
      ],
      "competencies": [
        {
          "id": "comp_behavior_obs",
          "name": "Behavioral observation",
          "category": "Behavior & welfare",
          "description": "Systematic observation, ethograms, behavior coding, and interpretation.",
          "importance": "important"
        },
        {
          "id": "comp_conservation",
          "name": "Conservation biology",
          "category": "Applied conservation",
          "description": "Species/population conservation, recovery, and biodiversity protection.",
          "importance": "important"
        },
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_field",
          "name": "Wildlife field methods",
          "category": "Wildlife science",
          "description": "Survey design, capture/observation, monitoring, and field protocols.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_gis",
          "name": "GIS & spatial analysis",
          "category": "Methods",
          "description": "Geographic information systems and spatial analysis.",
          "importance": "important"
        },
        {
          "id": "comp_learning",
          "name": "Learning & training",
          "category": "Behavior & welfare",
          "description": "Learning theory, conditioning, reinforcement, and humane training.",
          "importance": "important"
        },
        {
          "id": "comp_physiology",
          "name": "Animal physiology",
          "category": "Biological mechanisms",
          "description": "Organ systems, endocrine/stress physiology, and functional biology.",
          "importance": "important"
        },
        {
          "id": "comp_population",
          "name": "Population biology",
          "category": "Wildlife science",
          "description": "Demography, abundance, survival, reproduction, population dynamics.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_speciesid",
          "name": "Species identification & natural history",
          "category": "Wildlife science",
          "description": "Taxonomy, field identification, life history, and natural history.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        },
        {
          "id": "comp_writing",
          "name": "Scientific writing & communication",
          "category": "Professional",
          "description": "Reports, papers, presentations, technical and public communication.",
          "importance": "important"
        }
      ],
      "observedTitles": [],
      "recentPostings": [],
      "evidence": [
        {
          "evidence_id": "ev_0003",
          "entity_type": "career",
          "entity_id": "cr_0040",
          "claim_type": "qualification",
          "claim_value": "Federal GS-0410 requires zoology or related science with at least 20 semester hours zoology/related animal sciences.",
          "source_id": "src_opm_0410",
          "confidence": "high",
          "verification_status": "verified",
          "valid_from": null,
          "last_verified": "2026-09-08",
          "notes": null,
          "source": {
            "source_id": "src_opm_0410",
            "organization": "U.S. Office of Personnel Management",
            "source_type": "qualification_standard",
            "title": "Zoology Series 0410",
            "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/zoology-series-0410/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "A",
            "notes": "Federal zoology education requirements."
          }
        }
      ],
      "credentials": [],
      "qualificationProfiles": [
        {
          "qualification_id": "qual_0410",
          "career_id": "cr_0040",
          "organization": "U.S. Office of Personnel Management",
          "series_code": "0410",
          "name": "Federal Zoology Series 0410",
          "education_requirement": "Degree in zoology or related science.",
          "coursework_requirement": "At least 20 semester hours in zoology and related animal sciences for related-discipline degrees.",
          "experience_requirement": "Grade-specific experience/graduate education applies.",
          "source_id": "src_opm_0410",
          "source_url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/zoology-series-0410/",
          "source_title": "Zoology Series 0410",
          "source_retrieved": "2026-09-08"
        }
      ]
    },
    {
      "id": "cr_0090",
      "name": "eDNA / molecular ecology technician",
      "slug": "edna-molecular-ecology-technician",
      "category": "Quantitative, environmental & agency careers",
      "domain": {
        "id": "dm_quant",
        "name": "Quantitative, environmental & agency science",
        "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work."
      },
      "roleFamily": {
        "id": "rf_quant",
        "name": "Quantitative ecology & data science",
        "description": "Statistics, ecological modeling, data science, and quantitative ecology."
      },
      "roleKind": "career",
      "marketStatus": "Verified current market title variants",
      "evidenceStatus": "verified_current_market",
      "lastVerified": "2026-09-08",
      "roleFocus": "Supports environmental DNA or molecular-ecology projects by processing biological samples, running laboratory workflows, managing data, and connecting molecular detections to wildlife or ecological monitoring.",
      "details": {
        "Typical work settings": "Molecular ecology labs, conservation genetics programs, government laboratories, universities, environmental research organizations.",
        "Undergraduate preparation most useful": "Molecular/cellular biology, genetics, ecology, laboratory methods, data management, statistics.",
        "Searchable job titles": "Environmental DNA Lab Technician; eDNA Technician; Molecular Ecology Technician; Conservation Genetics Technician",
        "Alternate names / terms": "Molecular ecology lab tech; eDNA analyst",
        "Typical education / progression": "B.S. commonly sufficient for technician roles; graduate study can lead to molecular ecologist/geneticist positions.",
        "Job outlook": "No dedicated O*NET occupation; use biological technician/genetics data and current postings.",
        "Salary context": "Use laboratory and conservation-science postings.",
        "Market status": "Verified current market title variants",
        "Career type": "Career"
      },
      "support": {
        "ME-WE": "C",
        "ME-ZOO": "S",
        "UMA-AS": "C",
        "UMA-BIO": "S",
        "UMA-WEC": "C",
        "UNE-AB": "C",
        "UNE-AN": "C",
        "URI-AZ": "C",
        "URI-W": "C",
        "URI-WZ": "C"
      },
      "notes": "",
      "dims": [
        0.2,
        0.1,
        0.0,
        1.2,
        0.1,
        2.5,
        2.0,
        2.2,
        2.6,
        0.4
      ],
      "directContact": "Low",
      "educationBand": "B.S.-accessible / experience-driven",
      "careerStage": "entry_or_early",
      "workTags": [
        "Conservation",
        "Data / statistics",
        "Research"
      ],
      "entrySalary": null,
      "midSalary": null,
      "observedMarketSalary": null,
      "aliases": [
        "Molecular ecology lab tech",
        "eDNA analyst",
        "Conservation Genetics Technician",
        "Environmental DNA Lab Technician",
        "Molecular Ecology Technician",
        "eDNA Technician"
      ],
      "competencies": [
        {
          "id": "comp_ecology",
          "name": "Ecology",
          "category": "Wildlife science",
          "description": "Organism-environment relationships, communities, habitats, and ecological processes.",
          "importance": "important"
        },
        {
          "id": "comp_genetics",
          "name": "Genetics & genomics",
          "category": "Biological mechanisms",
          "description": "Genetics, population genetics, genomics, and molecular ecology.",
          "importance": "important"
        },
        {
          "id": "comp_research",
          "name": "Research design",
          "category": "Methods",
          "description": "Hypothesis development, study design, data collection, and scientific reasoning.",
          "importance": "important"
        },
        {
          "id": "comp_stats",
          "name": "Statistics & data analysis",
          "category": "Methods",
          "description": "Statistical analysis, modeling, and quantitative inference.",
          "importance": "important"
        }
      ],
      "observedTitles": [
        {
          "observed_id": "obs_post_0045",
          "career_id": "cr_0090",
          "title": "Environmental DNA Lab Technician",
          "organization": "Great Basin Institute & U.S. Forest Service",
          "location": "Missoula, MT",
          "observation_type": "job_posting",
          "observed_date": "2026-09-08",
          "source_id": "src_tws_jobs",
          "notes": "Current TWS search result.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "recentPostings": [
        {
          "posting_id": "post_0045",
          "career_id": "cr_0090",
          "title": "Environmental DNA Lab Technician",
          "employer": "Great Basin Institute & U.S. Forest Service",
          "location": "Missoula, MT",
          "posted_date": null,
          "retrieved_date": "2026-09-08",
          "employment_type": null,
          "education_min": null,
          "experience_min": null,
          "salary_min": null,
          "salary_max": null,
          "salary_unit": "annual",
          "currency": "USD",
          "source_id": "src_tws_jobs",
          "url": "https://careers.wildlife.org/jobs/?keywords=wildlife+technician",
          "active_status": "current_or_recent",
          "notes": "Current TWS search result.",
          "source": {
            "source_id": "src_tws_jobs",
            "organization": "The Wildlife Society",
            "source_type": "job_board",
            "title": "The Wildlife Society Career Center",
            "url": "https://careers.wildlife.org/",
            "published_date": null,
            "retrieved_date": "2026-09-08",
            "authority_tier": "B",
            "notes": "Current wildlife-industry job postings."
          }
        }
      ],
      "evidence": [],
      "credentials": [],
      "qualificationProfiles": []
    }
  ],
  "domains": [
    {
      "domain_id": "dm_behavior",
      "name": "Animal behavior, cognition & welfare",
      "description": "Behavioral science, welfare, training, enrichment, and applied behavior.",
      "roleCount": 17,
      "familyCount": 4
    },
    {
      "domain_id": "dm_education",
      "name": "Education, outreach & communication",
      "description": "Interpretation, education, outreach, museums, collections, and science communication.",
      "roleCount": 6,
      "familyCount": 3
    },
    {
      "domain_id": "dm_organismal",
      "name": "Organismal & evolutionary biology",
      "description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history.",
      "roleCount": 11,
      "familyCount": 3
    },
    {
      "domain_id": "dm_quant",
      "name": "Quantitative, environmental & agency science",
      "description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work.",
      "roleCount": 14,
      "familyCount": 5
    },
    {
      "domain_id": "dm_research",
      "name": "Research & academia",
      "description": "Research support, graduate research pathways, laboratories, independent science, and academic careers.",
      "roleCount": 9,
      "familyCount": 3
    },
    {
      "domain_id": "dm_wildlife",
      "name": "Wildlife, rehabilitation & conservation",
      "description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "roleCount": 21,
      "familyCount": 8
    },
    {
      "domain_id": "dm_managed",
      "name": "Zoos, aquariums & managed animals",
      "description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings.",
      "roleCount": 15,
      "familyCount": 6
    }
  ],
  "roleFamilies": [
    {
      "family_id": "rf_applied_behavior",
      "domain_id": "dm_behavior",
      "name": "Applied behavior & training",
      "description": "Science-based training, behavior modification, service-animal work, and applied behavior.",
      "domain_name": "Animal behavior, cognition & welfare",
      "domain_description": "Behavioral science, welfare, training, enrichment, and applied behavior.",
      "role_count": 3
    },
    {
      "family_id": "rf_behavior_research",
      "domain_id": "dm_behavior",
      "name": "Behavioral research & cognition",
      "description": "Research on behavior, cognition, learning, communication, and comparative psychology.",
      "domain_name": "Animal behavior, cognition & welfare",
      "domain_description": "Behavioral science, welfare, training, enrichment, and applied behavior.",
      "role_count": 4
    },
    {
      "family_id": "rf_shelter_companion",
      "domain_id": "dm_behavior",
      "name": "Shelter & companion-animal behavior",
      "description": "Shelter behavior, companion-animal behavior, and complex behavior consulting.",
      "domain_name": "Animal behavior, cognition & welfare",
      "domain_description": "Behavioral science, welfare, training, enrichment, and applied behavior.",
      "role_count": 3
    },
    {
      "family_id": "rf_welfare_husbandry",
      "domain_id": "dm_behavior",
      "name": "Welfare, enrichment & behavioral husbandry",
      "description": "Welfare assessment, enrichment, behavioral husbandry, and applied animal-care behavior.",
      "domain_name": "Animal behavior, cognition & welfare",
      "domain_description": "Behavioral science, welfare, training, enrichment, and applied behavior.",
      "role_count": 7
    },
    {
      "family_id": "rf_scicomm",
      "domain_id": "dm_education",
      "name": "Science communication & museum work",
      "description": "Science writing, communication, natural-history museums, and collections.",
      "domain_name": "Education, outreach & communication",
      "domain_description": "Interpretation, education, outreach, museums, collections, and science communication.",
      "role_count": 2
    },
    {
      "family_id": "rf_wildlife_education",
      "domain_id": "dm_education",
      "name": "Wildlife interpretation & outreach",
      "description": "Wildlife/environmental education, naturalist work, and conservation outreach.",
      "domain_name": "Education, outreach & communication",
      "domain_description": "Interpretation, education, outreach, museums, collections, and science communication.",
      "role_count": 3
    },
    {
      "family_id": "rf_zoo_education",
      "domain_id": "dm_education",
      "name": "Zoo/aquarium education",
      "description": "Zoo/aquarium education, interpretation, and public programs.",
      "domain_name": "Education, outreach & communication",
      "domain_description": "Interpretation, education, outreach, museums, collections, and science communication.",
      "role_count": 1
    },
    {
      "family_id": "rf_evolution",
      "domain_id": "dm_organismal",
      "name": "Evolutionary & ecological science",
      "description": "Evolutionary biology and broad ecological science involving animals.",
      "domain_name": "Organismal & evolutionary biology",
      "domain_description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history.",
      "role_count": 5
    },
    {
      "family_id": "rf_physiology",
      "domain_id": "dm_organismal",
      "name": "Physiology & neuroethology",
      "description": "Animal physiology, neuroethology, and mechanisms of behavior.",
      "domain_name": "Organismal & evolutionary biology",
      "domain_description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history.",
      "role_count": 2
    },
    {
      "family_id": "rf_taxon",
      "domain_id": "dm_organismal",
      "name": "Taxon & natural-history specialists",
      "description": "Zoology and organismal specialties such as mammalogy, ornithology, and herpetology.",
      "domain_name": "Organismal & evolutionary biology",
      "domain_description": "Whole-animal biology, physiology, taxonomy, evolution, neuroethology, and natural history.",
      "role_count": 4
    },
    {
      "family_id": "rf_env_consult",
      "domain_id": "dm_quant",
      "name": "Environmental consulting & compliance",
      "description": "Environmental consulting, permitting, regulatory, and compliance biology.",
      "domain_name": "Quantitative, environmental & agency science",
      "domain_description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work.",
      "role_count": 2
    },
    {
      "family_id": "rf_gis",
      "domain_id": "dm_quant",
      "name": "GIS, remote sensing & spatial analysis",
      "description": "GIS, remote sensing, spatial analysis, and geospatial ecology.",
      "domain_name": "Quantitative, environmental & agency science",
      "domain_description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work.",
      "role_count": 2
    },
    {
      "family_id": "rf_agency",
      "domain_id": "dm_quant",
      "name": "Natural-resource agency & management",
      "description": "Agency biology, park/resource work, natural-resource management, and program management.",
      "domain_name": "Quantitative, environmental & agency science",
      "domain_description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work.",
      "role_count": 4
    },
    {
      "family_id": "rf_quant",
      "domain_id": "dm_quant",
      "name": "Quantitative ecology & data science",
      "description": "Statistics, ecological modeling, data science, and quantitative ecology.",
      "domain_name": "Quantitative, environmental & agency science",
      "domain_description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work.",
      "role_count": 5
    },
    {
      "family_id": "rf_restoration",
      "domain_id": "dm_quant",
      "name": "Restoration & ecological monitoring",
      "description": "Habitat restoration, ecological monitoring, and environmental field implementation.",
      "domain_name": "Quantitative, environmental & agency science",
      "domain_description": "GIS, statistics, ecological data, environmental consulting, restoration, and agency/resource work.",
      "role_count": 1
    },
    {
      "family_id": "rf_grad",
      "domain_id": "dm_research",
      "name": "Graduate research pathways",
      "description": "Research M.S./Ph.D. routes into advanced science.",
      "domain_name": "Research & academia",
      "domain_description": "Research support, graduate research pathways, laboratories, independent science, and academic careers.",
      "role_count": 5
    },
    {
      "family_id": "rf_independent_research",
      "domain_id": "dm_research",
      "name": "Independent research & academia",
      "description": "Research scientists, principal investigators, and professors.",
      "domain_name": "Research & academia",
      "domain_description": "Research support, graduate research pathways, laboratories, independent science, and academic careers.",
      "role_count": 2
    },
    {
      "family_id": "rf_research_support",
      "domain_id": "dm_research",
      "name": "Research support & lab operations",
      "description": "Research assistants, technicians, laboratory managers, and research coordination.",
      "domain_name": "Research & academia",
      "domain_description": "Research support, graduate research pathways, laboratories, independent science, and academic careers.",
      "role_count": 2
    },
    {
      "family_id": "rf_habitat",
      "domain_id": "dm_wildlife",
      "name": "Habitat & conservation delivery",
      "description": "Habitat biology, restoration delivery, conservation planning, and refuge management.",
      "domain_name": "Wildlife, rehabilitation & conservation",
      "domain_description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "role_count": 3
    },
    {
      "family_id": "rf_human_dimensions",
      "domain_id": "dm_wildlife",
      "name": "Human-wildlife & social dimensions",
      "description": "Human-wildlife conflict and conservation social science.",
      "domain_name": "Wildlife, rehabilitation & conservation",
      "domain_description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "role_count": 2
    },
    {
      "family_id": "rf_movement",
      "domain_id": "dm_wildlife",
      "name": "Movement, monitoring & spatial ecology",
      "description": "Movement ecology, telemetry, spatial ecology, and post-release monitoring.",
      "domain_name": "Wildlife, rehabilitation & conservation",
      "domain_description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "role_count": 1
    },
    {
      "family_id": "rf_reintroduction",
      "domain_id": "dm_wildlife",
      "name": "Species recovery & reintroduction",
      "description": "Release, reintroduction, post-release monitoring, and species recovery.",
      "domain_name": "Wildlife, rehabilitation & conservation",
      "domain_description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "role_count": 4
    },
    {
      "family_id": "rf_wildlife_biology",
      "domain_id": "dm_wildlife",
      "name": "Wildlife biology & management",
      "description": "Professional wildlife biology, nongame/diversity biology, and wildlife program work.",
      "domain_name": "Wildlife, rehabilitation & conservation",
      "domain_description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "role_count": 6
    },
    {
      "family_id": "rf_wildlife_tech",
      "domain_id": "dm_wildlife",
      "name": "Wildlife field & technical work",
      "description": "Field technicians, monitoring, species surveys, and biological-science technical work.",
      "domain_name": "Wildlife, rehabilitation & conservation",
      "domain_description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "role_count": 1
    },
    {
      "family_id": "rf_wildlife_health",
      "domain_id": "dm_wildlife",
      "name": "Wildlife health & ecophysiology",
      "description": "Wildlife disease, physiology, stress, and ecophysiology.",
      "domain_name": "Wildlife, rehabilitation & conservation",
      "domain_description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "role_count": 1
    },
    {
      "family_id": "rf_rehab",
      "domain_id": "dm_wildlife",
      "name": "Wildlife rehabilitation & release",
      "description": "Wildlife rehabilitation, release coordination, and rehabilitation-center operations.",
      "domain_name": "Wildlife, rehabilitation & conservation",
      "domain_description": "Field wildlife science, rehabilitation, release, species recovery, habitat, and wildlife management.",
      "role_count": 3
    },
    {
      "family_id": "rf_animal_care",
      "domain_id": "dm_managed",
      "name": "Animal care & husbandry",
      "description": "Daily care, keeper work, sanctuary care, and managed-animal husbandry.",
      "domain_name": "Zoos, aquariums & managed animals",
      "domain_description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings.",
      "role_count": 2
    },
    {
      "family_id": "rf_aquatic_care",
      "domain_id": "dm_managed",
      "name": "Aquatic animal care",
      "description": "Aquarist work and related aquatic animal care.",
      "domain_name": "Zoos, aquariums & managed animals",
      "domain_description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings.",
      "role_count": 1
    },
    {
      "family_id": "rf_population",
      "domain_id": "dm_managed",
      "name": "Conservation breeding & population management",
      "description": "Conservation breeding, population biology, studbooks, and SSP population-management work.",
      "domain_name": "Zoos, aquariums & managed animals",
      "domain_description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings.",
      "role_count": 4
    },
    {
      "family_id": "rf_records_nutrition",
      "domain_id": "dm_managed",
      "name": "Records, nutrition & collection operations",
      "description": "Animal records/permits, nutrition, and collection planning/operations.",
      "domain_name": "Zoos, aquariums & managed animals",
      "domain_description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings.",
      "role_count": 2
    },
    {
      "family_id": "rf_zoo_science_leadership",
      "domain_id": "dm_managed",
      "name": "Zoo research, conservation & leadership",
      "description": "Zoo/aquarium research, conservation coordination, collection leadership, and curation.",
      "domain_name": "Zoos, aquariums & managed animals",
      "domain_description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings.",
      "role_count": 4
    },
    {
      "family_id": "rf_zoo_training",
      "domain_id": "dm_managed",
      "name": "Zoo training & ambassador animal programs",
      "description": "Animal training and ambassador-animal care/education within zoological settings.",
      "domain_name": "Zoos, aquariums & managed animals",
      "domain_description": "Animal care, husbandry, training, collection management, population management, research, and conservation within managed settings.",
      "role_count": 2
    }
  ],
  "careerEdges": [
    {
      "edge_id": "edge_0045",
      "from_career_id": "cr_0059",
      "to_career_id": "cr_0061",
      "relationship_type": "graduate_transition",
      "typicality": "common",
      "education_change": "M.S.",
      "experience_change": "0–3 years",
      "evidence_status": "supported",
      "source_id": "src_abs_caab",
      "notes": "Research experience strengthens preparation for research-based graduate study.",
      "fromCareer": "University / laboratory research assistant",
      "toCareer": "M.S. in animal behavior / ethology",
      "source": {
        "source_id": "src_abs_caab",
        "organization": "Animal Behavior Society",
        "source_type": "credential_standard",
        "title": "CAAB / ACAAB Certification Requirements",
        "url": "https://www.animalbehaviorsociety.org/web/committees-applied-behavior-caab.php",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Research-based graduate education and experience requirements for applied-animal-behavior certification."
      }
    },
    {
      "edge_id": "edge_0003",
      "from_career_id": "cr_0014",
      "to_career_id": "cr_0079",
      "relationship_type": "lateral",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "1–3 years",
      "evidence_status": "verified",
      "source_id": "src_aza_jobs",
      "notes": "Current ambassador-animal titles demonstrate this specialization.",
      "fromCareer": "Zookeeper / animal-care specialist",
      "toCareer": "Ambassador animal specialist / animal programs keeper",
      "source": {
        "source_id": "src_aza_jobs",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "job_board",
        "title": "AZA Career Center",
        "url": "https://www.aza.org/Jobs/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current and recent zoo/aquarium job postings."
      }
    },
    {
      "edge_id": "edge_0024",
      "from_career_id": "cr_0027",
      "to_career_id": "cr_0039",
      "relationship_type": "lateral",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_tws_jobs",
      "notes": "Field and population biology can shift toward habitat-focused management.",
      "fromCareer": "Wildlife biologist",
      "toCareer": "Habitat / wildlife management biologist",
      "source": {
        "source_id": "src_tws_jobs",
        "organization": "The Wildlife Society",
        "source_type": "job_board",
        "title": "The Wildlife Society Career Center",
        "url": "https://careers.wildlife.org/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current wildlife-industry job postings."
      }
    },
    {
      "edge_id": "edge_0035",
      "from_career_id": "cr_0039",
      "to_career_id": "cr_0084",
      "relationship_type": "lateral",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "2–5 years",
      "evidence_status": "verified",
      "source_id": "src_tws_habitatdelivery",
      "notes": "Habitat biology and delivery coordination are adjacent applied conservation roles.",
      "fromCareer": "Habitat / wildlife management biologist",
      "toCareer": "Conservation delivery / habitat program coordinator",
      "source": {
        "source_id": "src_tws_habitatdelivery",
        "organization": "American Bird Conservancy / TWS",
        "source_type": "job_posting",
        "title": "GCJV Habitat Delivery Coordinator",
        "url": "https://careers.wildlife.org/job/gulf-coast-joint-venture-gcjv-coastal-grassland-incentive-program-cgrip-and-habitat-delivery-coordinator/85122735/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Habitat delivery posting with salary and education."
      }
    },
    {
      "edge_id": "edge_0002",
      "from_career_id": "cr_0014",
      "to_career_id": "cr_0078",
      "relationship_type": "lateral",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "1–3 years",
      "evidence_status": "supported",
      "source_id": "src_aza_jobs",
      "notes": "Shared animal-care and training skill base.",
      "fromCareer": "Zookeeper / animal-care specialist",
      "toCareer": "Zoo / aquarium animal trainer",
      "source": {
        "source_id": "src_aza_jobs",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "job_board",
        "title": "AZA Career Center",
        "url": "https://www.aza.org/Jobs/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current and recent zoo/aquarium job postings."
      }
    },
    {
      "edge_id": "edge_0006",
      "from_career_id": "cr_0015",
      "to_career_id": "cr_0078",
      "relationship_type": "lateral",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "1–3 years",
      "evidence_status": "verified",
      "source_id": "src_aza_jobs",
      "notes": "Aquarium training roles share husbandry and behavior experience.",
      "fromCareer": "Aquarist / aquarium animal-care specialist",
      "toCareer": "Zoo / aquarium animal trainer",
      "source": {
        "source_id": "src_aza_jobs",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "job_board",
        "title": "AZA Career Center",
        "url": "https://www.aza.org/Jobs/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current and recent zoo/aquarium job postings."
      }
    },
    {
      "edge_id": "edge_0015",
      "from_career_id": "cr_0074",
      "to_career_id": "cr_0024",
      "relationship_type": "lateral",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_aza_pmc",
      "notes": "Population-management expertise connects to zoo conservation program work.",
      "fromCareer": "Population biologist / zoo population management scientist",
      "toCareer": "Zoo conservation coordinator",
      "source": {
        "source_id": "src_aza_pmc",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Population Management Center",
        "url": "https://www.aza.org/population-management-center",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Population biologists, planning coordinator, research support, and managed-population planning."
      }
    },
    {
      "edge_id": "edge_0018",
      "from_career_id": "cr_0077",
      "to_career_id": "cr_0022",
      "relationship_type": "lateral",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "3–5+ years",
      "evidence_status": "supported",
      "source_id": "src_aza_jobs",
      "notes": "Nutrition managers work closely with collection operations and animal-care leadership.",
      "fromCareer": "Zoo animal nutritionist / nutrition coordinator",
      "toCareer": "Animal collection / management specialist",
      "source": {
        "source_id": "src_aza_jobs",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "job_board",
        "title": "AZA Career Center",
        "url": "https://www.aza.org/Jobs/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current and recent zoo/aquarium job postings."
      }
    },
    {
      "edge_id": "edge_0021",
      "from_career_id": "cr_0026",
      "to_career_id": "cr_0090",
      "relationship_type": "lateral",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "0–2 years",
      "evidence_status": "verified",
      "source_id": "src_tws_jobs",
      "notes": "Current eDNA lab technician titles provide a molecular-monitoring lateral option.",
      "fromCareer": "Wildlife technician / biological science technician",
      "toCareer": "eDNA / molecular ecology technician",
      "source": {
        "source_id": "src_tws_jobs",
        "organization": "The Wildlife Society",
        "source_type": "job_board",
        "title": "The Wildlife Society Career Center",
        "url": "https://careers.wildlife.org/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current wildlife-industry job postings."
      }
    },
    {
      "edge_id": "edge_0031",
      "from_career_id": "cr_0029",
      "to_career_id": "cr_0030",
      "relationship_type": "lateral",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "field monitoring skills helpful",
      "evidence_status": "supported",
      "source_id": "src_nwra_jobs",
      "notes": "Release logistics can transition toward field-based reintroduction work.",
      "fromCareer": "Wildlife rehabilitation / release coordinator",
      "toCareer": "Reintroduction / release field technician",
      "source": {
        "source_id": "src_nwra_jobs",
        "organization": "National Wildlife Rehabilitators Association",
        "source_type": "job_board",
        "title": "NWRA Career Center",
        "url": "https://www.nwrawildlife.org/networking/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current wildlife rehabilitation jobs and internships."
      }
    },
    {
      "edge_id": "edge_0037",
      "from_career_id": "cr_0049",
      "to_career_id": "cr_0088",
      "relationship_type": "lateral",
      "typicality": "possible",
      "education_change": "none_or_grad",
      "experience_change": "2–5 years",
      "evidence_status": "verified",
      "source_id": "src_usgs_eesc",
      "notes": "Spatial analysts can broaden into ecological data science.",
      "fromCareer": "GIS / wildlife spatial analyst",
      "toCareer": "Ecological data scientist",
      "source": {
        "source_id": "src_usgs_eesc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Eastern Ecological Science Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/eesc/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific titles in federal ecological research."
      }
    },
    {
      "edge_id": "edge_0005",
      "from_career_id": "cr_0014",
      "to_career_id": "cr_0023",
      "relationship_type": "management",
      "typicality": "common",
      "education_change": "none_or_grad",
      "experience_change": "5–10+ years",
      "evidence_status": "verified",
      "source_id": "src_aza_types",
      "notes": "AZA lists curators as collection-management leadership; current curator postings verify the role.",
      "fromCareer": "Zookeeper / animal-care specialist",
      "toCareer": "Zoo animal curator",
      "source": {
        "source_id": "src_aza_types",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Types of Zoo and Aquarium Jobs",
        "url": "https://www.aza.org/types-of-zoo-and-aquarium-jobs",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Official AZA career taxonomy and role descriptions."
      }
    },
    {
      "edge_id": "edge_0026",
      "from_career_id": "cr_0027",
      "to_career_id": "cr_0085",
      "relationship_type": "management",
      "typicality": "common",
      "education_change": "none_or_grad",
      "experience_change": "5–10+ years",
      "evidence_status": "verified",
      "source_id": "src_tws_wildlife_manager",
      "notes": "Regional wildlife program manager is a verified leadership role.",
      "fromCareer": "Wildlife biologist",
      "toCareer": "Wildlife program manager",
      "source": {
        "source_id": "src_tws_wildlife_manager",
        "organization": "Washington Department of Fish & Wildlife / TWS",
        "source_type": "job_posting",
        "title": "Regional Wildlife Program Manager",
        "url": "https://careers.wildlife.org/job/regional-wildlife-program-manager-north-puget-sound-region-4/85512902/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Regional wildlife leadership posting with salary and experience."
      }
    },
    {
      "edge_id": "edge_0030",
      "from_career_id": "cr_0028",
      "to_career_id": "cr_0093",
      "relationship_type": "management",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "3–5+ years",
      "evidence_status": "verified",
      "source_id": "src_nwra_manager",
      "notes": "Current wildlife care manager postings explicitly require progressive rehab/animal-care experience.",
      "fromCareer": "Wildlife rehabilitator",
      "toCareer": "Wildlife rehabilitation program manager",
      "source": {
        "source_id": "src_nwra_manager",
        "organization": "Lake Metroparks / NWRA",
        "source_type": "job_posting",
        "title": "Wildlife Care Manager",
        "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1096932&view=2",
        "published_date": "2026-08-14",
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Wildlife-care management posting with salary and experience."
      }
    },
    {
      "edge_id": "edge_0010",
      "from_career_id": "cr_0017",
      "to_career_id": "cr_0023",
      "relationship_type": "management",
      "typicality": "possible",
      "education_change": "none_or_grad",
      "experience_change": "5+ years",
      "evidence_status": "verified",
      "source_id": "src_aza_curator_behavior",
      "notes": "Curator of Behavioral Husbandry is a verified leadership pathway.",
      "fromCareer": "Zoo behavioral-husbandry specialist",
      "toCareer": "Zoo animal curator",
      "source": {
        "source_id": "src_aza_curator_behavior",
        "organization": "Gladys Porter Zoo / AZA",
        "source_type": "job_posting",
        "title": "Curator of Behavioral Husbandry",
        "url": "https://www.aza.org/jobs?job=51772",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Detailed role posting."
      }
    },
    {
      "edge_id": "edge_0025",
      "from_career_id": "cr_0027",
      "to_career_id": "cr_0083",
      "relationship_type": "management",
      "typicality": "possible",
      "education_change": "specific 0485 coursework + experience",
      "experience_change": "5+ years",
      "evidence_status": "verified",
      "source_id": "src_opm_0485",
      "notes": "Refuge management is a distinct federal progression with specific coursework.",
      "fromCareer": "Wildlife biologist",
      "toCareer": "Wildlife refuge manager",
      "source": {
        "source_id": "src_opm_0485",
        "organization": "U.S. Office of Personnel Management",
        "source_type": "qualification_standard",
        "title": "Wildlife Refuge Management Series 0485",
        "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/wildlife-refuge-management-series-0485/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Federal wildlife-refuge management education requirements."
      }
    },
    {
      "edge_id": "edge_0004",
      "from_career_id": "cr_0014",
      "to_career_id": "cr_0022",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "5+ years",
      "evidence_status": "supported",
      "source_id": "src_aza_types",
      "notes": "Lead/supervisory collection-management progression.",
      "fromCareer": "Zookeeper / animal-care specialist",
      "toCareer": "Animal collection / management specialist",
      "source": {
        "source_id": "src_aza_types",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Types of Zoo and Aquarium Jobs",
        "url": "https://www.aza.org/types-of-zoo-and-aquarium-jobs",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Official AZA career taxonomy and role descriptions."
      }
    },
    {
      "edge_id": "edge_0007",
      "from_career_id": "cr_0015",
      "to_career_id": "cr_0022",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "5+ years",
      "evidence_status": "supported",
      "source_id": "src_aza_types",
      "notes": "Senior/head aquarist progression can lead to management.",
      "fromCareer": "Aquarist / aquarium animal-care specialist",
      "toCareer": "Animal collection / management specialist",
      "source": {
        "source_id": "src_aza_types",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Types of Zoo and Aquarium Jobs",
        "url": "https://www.aza.org/types-of-zoo-and-aquarium-jobs",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Official AZA career taxonomy and role descriptions."
      }
    },
    {
      "edge_id": "edge_0008",
      "from_career_id": "cr_0008",
      "to_career_id": "cr_0007",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_aza_curator_behavior",
      "notes": "Behavioral husbandry and welfare leadership strongly overlap.",
      "fromCareer": "Behavioral husbandry specialist",
      "toCareer": "Animal welfare / behavior coordinator",
      "source": {
        "source_id": "src_aza_curator_behavior",
        "organization": "Gladys Porter Zoo / AZA",
        "source_type": "job_posting",
        "title": "Curator of Behavioral Husbandry",
        "url": "https://www.aza.org/jobs?job=51772",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Detailed role posting."
      }
    },
    {
      "edge_id": "edge_0019",
      "from_career_id": "cr_0026",
      "to_career_id": "cr_0027",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "B.S. required for many professional roles",
      "experience_change": "1–3+ years",
      "evidence_status": "verified",
      "source_id": "src_usajobs_wildtech",
      "notes": "Technician experience is a common entry route into professional wildlife biology.",
      "fromCareer": "Wildlife technician / biological science technician",
      "toCareer": "Wildlife biologist",
      "source": {
        "source_id": "src_usajobs_wildtech",
        "organization": "National Park Service / USAJOBS",
        "source_type": "job_posting",
        "title": "Biological Science Technician (Wildlife)",
        "url": "https://www.usajobs.gov/job/882687500",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current GS-7 wildlife technician posting."
      }
    },
    {
      "edge_id": "edge_0020",
      "from_career_id": "cr_0026",
      "to_career_id": "cr_0081",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "B.S.; M.S. may help",
      "experience_change": "1–3+ years",
      "evidence_status": "verified",
      "source_id": "src_tws_diversitytech",
      "notes": "Current biodiversity technician work aligns with nongame/diversity biologist progression.",
      "fromCareer": "Wildlife technician / biological science technician",
      "toCareer": "Wildlife diversity / nongame biologist",
      "source": {
        "source_id": "src_tws_diversitytech",
        "organization": "West Virginia DNR / TWS",
        "source_type": "job_posting",
        "title": "Wildlife Diversity/Natural Heritage Zoology Technician",
        "url": "https://careers.wildlife.org/job/wildlife-diversitynatural-heritage-zoology-technician-west-virginia/85441685/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Current wildlife-diversity technician posting."
      }
    },
    {
      "edge_id": "edge_0029",
      "from_career_id": "cr_0028",
      "to_career_id": "cr_0029",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_nwra_jobs",
      "notes": "Rehabilitation experience can expand into release/logistics coordination.",
      "fromCareer": "Wildlife rehabilitator",
      "toCareer": "Wildlife rehabilitation / release coordinator",
      "source": {
        "source_id": "src_nwra_jobs",
        "organization": "National Wildlife Rehabilitators Association",
        "source_type": "job_board",
        "title": "NWRA Career Center",
        "url": "https://www.nwrawildlife.org/networking/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current wildlife rehabilitation jobs and internships."
      }
    },
    {
      "edge_id": "edge_0032",
      "from_career_id": "cr_0030",
      "to_career_id": "cr_0031",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "B.S.; M.S. may help",
      "experience_change": "1–3 years",
      "evidence_status": "supported",
      "source_id": "src_tws_jobs",
      "notes": "Field release experience leads naturally to monitoring/analysis roles.",
      "fromCareer": "Reintroduction / release field technician",
      "toCareer": "Post-release monitoring biologist",
      "source": {
        "source_id": "src_tws_jobs",
        "organization": "The Wildlife Society",
        "source_type": "job_board",
        "title": "The Wildlife Society Career Center",
        "url": "https://careers.wildlife.org/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current wildlife-industry job postings."
      }
    },
    {
      "edge_id": "edge_0034",
      "from_career_id": "cr_0084",
      "to_career_id": "cr_0055",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "none_or_grad",
      "experience_change": "5+ years",
      "evidence_status": "verified",
      "source_id": "src_tws_habitatdelivery",
      "notes": "Habitat delivery coordination develops program-management responsibilities.",
      "fromCareer": "Conservation delivery / habitat program coordinator",
      "toCareer": "Natural-resource manager",
      "source": {
        "source_id": "src_tws_habitatdelivery",
        "organization": "American Bird Conservancy / TWS",
        "source_type": "job_posting",
        "title": "GCJV Habitat Delivery Coordinator",
        "url": "https://careers.wildlife.org/job/gulf-coast-joint-venture-gcjv-coastal-grassland-incentive-program-cgrip-and-habitat-delivery-coordinator/85122735/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Habitat delivery posting with salary and education."
      }
    },
    {
      "edge_id": "edge_0039",
      "from_career_id": "cr_0050",
      "to_career_id": "cr_0051",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "M.S. often useful",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_usgs_eesc",
      "notes": "Research-assistant quantitative work commonly precedes specialist ecology roles.",
      "fromCareer": "Quantitative ecology research assistant",
      "toCareer": "Quantitative ecologist / biometrician",
      "source": {
        "source_id": "src_usgs_eesc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Eastern Ecological Science Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/eesc/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific titles in federal ecological research."
      }
    },
    {
      "edge_id": "edge_0044",
      "from_career_id": "cr_0059",
      "to_career_id": "cr_0060",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "none_or_grad",
      "experience_change": "2–5 years",
      "evidence_status": "verified",
      "source_id": "src_tws_labmanager",
      "notes": "Current lab-manager postings show a B.S.-accessible management step after research experience.",
      "fromCareer": "University / laboratory research assistant",
      "toCareer": "Research / laboratory manager — behavioral or biological science",
      "source": {
        "source_id": "src_tws_labmanager",
        "organization": "East Texas A&M University / TWS",
        "source_type": "job_posting",
        "title": "Quail Research Laboratory Manager",
        "url": "https://careers.wildlife.org/jobs/function/Wildlife/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Research laboratory manager posting with salary and B.S. requirement."
      }
    },
    {
      "edge_id": "edge_0047",
      "from_career_id": "cr_0068",
      "to_career_id": "cr_0071",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_aza_types",
      "notes": "Education roles can progress to program coordination and leadership.",
      "fromCareer": "Zoo / aquarium educator",
      "toCareer": "Conservation outreach / program coordinator",
      "source": {
        "source_id": "src_aza_types",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Types of Zoo and Aquarium Jobs",
        "url": "https://www.aza.org/types-of-zoo-and-aquarium-jobs",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Official AZA career taxonomy and role descriptions."
      }
    },
    {
      "edge_id": "edge_0048",
      "from_career_id": "cr_0070",
      "to_career_id": "cr_0069",
      "relationship_type": "natural_growth",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "1–3 years",
      "evidence_status": "supported",
      "source_id": "src_tws_jobs",
      "notes": "Interpretive work provides a foundation for broader environmental education.",
      "fromCareer": "Naturalist / interpretive educator",
      "toCareer": "Wildlife / environmental educator",
      "source": {
        "source_id": "src_tws_jobs",
        "organization": "The Wildlife Society",
        "source_type": "job_board",
        "title": "The Wildlife Society Career Center",
        "url": "https://careers.wildlife.org/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Current wildlife-industry job postings."
      }
    },
    {
      "edge_id": "edge_0017",
      "from_career_id": "cr_0076",
      "to_career_id": "cr_0022",
      "relationship_type": "natural_growth",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "3–5+ years",
      "evidence_status": "verified",
      "source_id": "src_aza_registrar",
      "notes": "Records/transactions work can broaden into collection operations.",
      "fromCareer": "Zoo registrar / animal records & permits specialist",
      "toCareer": "Animal collection / management specialist",
      "source": {
        "source_id": "src_aza_registrar",
        "organization": "Lee Richardson Zoo / AZA",
        "source_type": "job_posting",
        "title": "Registrar",
        "url": "https://www.aza.org/Jobs?job=52409",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Animal records, permits, transfer, ZIMS, and database role."
      }
    },
    {
      "edge_id": "edge_0033",
      "from_career_id": "cr_0031",
      "to_career_id": "cr_0082",
      "relationship_type": "natural_growth",
      "typicality": "possible",
      "education_change": "M.S. often useful",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_usajobs_fwbio",
      "notes": "Monitoring data feed directly into species-recovery decisions.",
      "fromCareer": "Post-release monitoring biologist",
      "toCareer": "Species recovery biologist",
      "source": {
        "source_id": "src_usajobs_fwbio",
        "organization": "U.S. Fish and Wildlife Service / USAJOBS",
        "source_type": "job_posting",
        "title": "Fish and Wildlife Biologist - State College",
        "url": "https://www.usajobs.gov/job/882387200",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current GS-12 fish and wildlife biologist posting."
      }
    },
    {
      "edge_id": "edge_0014",
      "from_career_id": "cr_0020",
      "to_career_id": "cr_0075",
      "relationship_type": "professional_assignment",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "professional zoo experience",
      "evidence_status": "verified",
      "source_id": "src_aza_program_roles",
      "notes": "AZA program-leader roles are assigned to experienced zoo professionals.",
      "fromCareer": "Conservation-breeding technician",
      "toCareer": "SSP coordinator / studbook keeper",
      "source": {
        "source_id": "src_aza_program_roles",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Updates to AZA Animal Programs - Role Descriptions",
        "url": "https://annual.aza.org/2024/documents/Boland__Marissa_Updates_to_AZA_s_Animal_Programs.pdf",
        "published_date": "2024",
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "SSP Coordinator and Studbook Keeper role descriptions."
      }
    },
    {
      "edge_id": "edge_0013",
      "from_career_id": "cr_0020",
      "to_career_id": "cr_0021",
      "relationship_type": "research_progression",
      "typicality": "common",
      "education_change": "M.S./Ph.D. often useful",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_aza_pmc",
      "notes": "Technical breeding experience can progress toward research/science roles.",
      "fromCareer": "Conservation-breeding technician",
      "toCareer": "Conservation-breeding scientist",
      "source": {
        "source_id": "src_aza_pmc",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Population Management Center",
        "url": "https://www.aza.org/population-management-center",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Population biologists, planning coordinator, research support, and managed-population planning."
      }
    },
    {
      "edge_id": "edge_0041",
      "from_career_id": "cr_0090",
      "to_career_id": "cr_0086",
      "relationship_type": "research_progression",
      "typicality": "common",
      "education_change": "M.S./Ph.D. commonly needed",
      "experience_change": "2–5 years",
      "evidence_status": "verified",
      "source_id": "src_aza_genetics",
      "notes": "Molecular technician experience is a natural foundation for conservation genetics research.",
      "fromCareer": "eDNA / molecular ecology technician",
      "toCareer": "Conservation geneticist / wildlife genomicist",
      "source": {
        "source_id": "src_aza_genetics",
        "organization": "San Diego Zoo Wildlife Alliance / AZA",
        "source_type": "job_posting",
        "title": "Conservation Genetics Post Doctoral Associate",
        "url": "https://www.aza.org/jobs?job=51965",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Conservation genetics posting with salary."
      }
    },
    {
      "edge_id": "edge_0042",
      "from_career_id": "cr_0087",
      "to_career_id": "cr_0066",
      "relationship_type": "research_progression",
      "typicality": "common",
      "education_change": "Ph.D. typical",
      "experience_change": "5+ years",
      "evidence_status": "verified",
      "source_id": "src_usgs_eesc",
      "notes": "Independent research scientists commonly advance through research-specialist roles.",
      "fromCareer": "Research ecologist",
      "toCareer": "Research scientist / principal investigator",
      "source": {
        "source_id": "src_usgs_eesc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Eastern Ecological Science Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/eesc/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific titles in federal ecological research."
      }
    },
    {
      "edge_id": "edge_0043",
      "from_career_id": "cr_0086",
      "to_career_id": "cr_0066",
      "relationship_type": "research_progression",
      "typicality": "common",
      "education_change": "Ph.D. typical",
      "experience_change": "5+ years",
      "evidence_status": "verified",
      "source_id": "src_aza_genetics",
      "notes": "Independent genetics research commonly progresses to PI/scientist leadership.",
      "fromCareer": "Conservation geneticist / wildlife genomicist",
      "toCareer": "Research scientist / principal investigator",
      "source": {
        "source_id": "src_aza_genetics",
        "organization": "San Diego Zoo Wildlife Alliance / AZA",
        "source_type": "job_posting",
        "title": "Conservation Genetics Post Doctoral Associate",
        "url": "https://www.aza.org/jobs?job=51965",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Conservation genetics posting with salary."
      }
    },
    {
      "edge_id": "edge_0009",
      "from_career_id": "cr_0008",
      "to_career_id": "cr_0006",
      "relationship_type": "research_progression",
      "typicality": "possible",
      "education_change": "M.S./Ph.D. commonly needed",
      "experience_change": "variable",
      "evidence_status": "supported",
      "source_id": "src_abs_caab",
      "notes": "Applied behavior/welfare expertise can progress into research-focused welfare science with graduate training.",
      "fromCareer": "Behavioral husbandry specialist",
      "toCareer": "Animal welfare scientist",
      "source": {
        "source_id": "src_abs_caab",
        "organization": "Animal Behavior Society",
        "source_type": "credential_standard",
        "title": "CAAB / ACAAB Certification Requirements",
        "url": "https://www.animalbehaviorsociety.org/web/committees-applied-behavior-caab.php",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Research-based graduate education and experience requirements for applied-animal-behavior certification."
      }
    },
    {
      "edge_id": "edge_0016",
      "from_career_id": "cr_0075",
      "to_career_id": "cr_0074",
      "relationship_type": "research_progression",
      "typicality": "possible",
      "education_change": "M.S./Ph.D. may be needed",
      "experience_change": "variable",
      "evidence_status": "supported",
      "source_id": "src_aza_pmc",
      "notes": "Population planning and quantitative population science overlap but are not identical roles.",
      "fromCareer": "SSP coordinator / studbook keeper",
      "toCareer": "Population biologist / zoo population management scientist",
      "source": {
        "source_id": "src_aza_pmc",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Population Management Center",
        "url": "https://www.aza.org/population-management-center",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Population biologists, planning coordinator, research support, and managed-population planning."
      }
    },
    {
      "edge_id": "edge_0028",
      "from_career_id": "cr_0027",
      "to_career_id": "cr_0087",
      "relationship_type": "research_progression",
      "typicality": "possible",
      "education_change": "Ph.D. common for independent federal research",
      "experience_change": "variable",
      "evidence_status": "verified",
      "source_id": "src_usgs_eesc",
      "notes": "USGS research ecologist/wildlife biologist titles demonstrate research specialization.",
      "fromCareer": "Wildlife biologist",
      "toCareer": "Research ecologist",
      "source": {
        "source_id": "src_usgs_eesc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Eastern Ecological Science Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/eesc/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific titles in federal ecological research."
      }
    },
    {
      "edge_id": "edge_0038",
      "from_career_id": "cr_0050",
      "to_career_id": "cr_0089",
      "relationship_type": "research_progression",
      "typicality": "possible",
      "education_change": "M.S./Ph.D. commonly needed",
      "experience_change": "variable",
      "evidence_status": "verified",
      "source_id": "src_usgs_eesc",
      "notes": "USGS research-statistician titles demonstrate an advanced quantitative pathway.",
      "fromCareer": "Quantitative ecology research assistant",
      "toCareer": "Research statistician — ecology/biology",
      "source": {
        "source_id": "src_usgs_eesc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Eastern Ecological Science Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/eesc/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific titles in federal ecological research."
      }
    },
    {
      "edge_id": "edge_0046",
      "from_career_id": "cr_0060",
      "to_career_id": "cr_0066",
      "relationship_type": "research_progression",
      "typicality": "possible",
      "education_change": "Ph.D. usually needed",
      "experience_change": "variable",
      "evidence_status": "supported",
      "source_id": "src_usgs_eesc",
      "notes": "Lab management can precede independent research after graduate training.",
      "fromCareer": "Research / laboratory manager — behavioral or biological science",
      "toCareer": "Research scientist / principal investigator",
      "source": {
        "source_id": "src_usgs_eesc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Eastern Ecological Science Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/eesc/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific titles in federal ecological research."
      }
    },
    {
      "edge_id": "edge_0001",
      "from_career_id": "cr_0014",
      "to_career_id": "cr_0017",
      "relationship_type": "specialization",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_aza_types",
      "notes": "Keeper experience can progress into specialized behavioral-husbandry responsibilities.",
      "fromCareer": "Zookeeper / animal-care specialist",
      "toCareer": "Zoo behavioral-husbandry specialist",
      "source": {
        "source_id": "src_aza_types",
        "organization": "Association of Zoos and Aquariums",
        "source_type": "professional_reference",
        "title": "Types of Zoo and Aquarium Jobs",
        "url": "https://www.aza.org/types-of-zoo-and-aquarium-jobs",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Official AZA career taxonomy and role descriptions."
      }
    },
    {
      "edge_id": "edge_0012",
      "from_career_id": "cr_0012",
      "to_career_id": "cr_0080",
      "relationship_type": "specialization",
      "typicality": "common",
      "education_change": "none",
      "experience_change": "substantial behavior-case experience",
      "evidence_status": "supported",
      "source_id": "src_iaabc_shelter",
      "notes": "Shelter behavior experience overlaps with behavior-consulting competencies.",
      "fromCareer": "Shelter behavior specialist / coordinator",
      "toCareer": "Canine behavior consultant",
      "source": {
        "source_id": "src_iaabc_shelter",
        "organization": "International Association of Animal Behavior Consultants",
        "source_type": "credential_standard",
        "title": "Shelter Behavior Affiliate Credential",
        "url": "https://iaabc.org/en/affiliate-credentials",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Shelter-behavior credential and recommended experience."
      }
    },
    {
      "edge_id": "edge_0023",
      "from_career_id": "cr_0027",
      "to_career_id": "cr_0082",
      "relationship_type": "specialization",
      "typicality": "common",
      "education_change": "M.S. often useful",
      "experience_change": "2–5+ years",
      "evidence_status": "supported",
      "source_id": "src_usajobs_fwbio",
      "notes": "Agency wildlife biology commonly includes threatened/endangered species recovery work.",
      "fromCareer": "Wildlife biologist",
      "toCareer": "Species recovery biologist",
      "source": {
        "source_id": "src_usajobs_fwbio",
        "organization": "U.S. Fish and Wildlife Service / USAJOBS",
        "source_type": "job_posting",
        "title": "Fish and Wildlife Biologist - State College",
        "url": "https://www.usajobs.gov/job/882387200",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current GS-12 fish and wildlife biologist posting."
      }
    },
    {
      "edge_id": "edge_0036",
      "from_career_id": "cr_0049",
      "to_career_id": "cr_0091",
      "relationship_type": "specialization",
      "typicality": "common",
      "education_change": "M.S. useful for advanced ecology",
      "experience_change": "2–5 years",
      "evidence_status": "verified",
      "source_id": "src_usgs_npwrc",
      "notes": "GIS roles can deepen into geospatial/remote-sensing ecology.",
      "fromCareer": "GIS / wildlife spatial analyst",
      "toCareer": "Remote sensing / geospatial ecologist",
      "source": {
        "source_id": "src_usgs_npwrc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Northern Prairie Wildlife Research Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/northern-prairie-wildlife-research-center/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific/geospatial titles in federal wildlife research."
      }
    },
    {
      "edge_id": "edge_0011",
      "from_career_id": "cr_0010",
      "to_career_id": "cr_0080",
      "relationship_type": "specialization",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "300+ behavior-consulting hours for CBCC-KA eligibility",
      "evidence_status": "verified",
      "source_id": "src_ccpdt_cbcc",
      "notes": "Behavior consulting is a distinct advanced practice area.",
      "fromCareer": "Science-based animal trainer",
      "toCareer": "Canine behavior consultant",
      "source": {
        "source_id": "src_ccpdt_cbcc",
        "organization": "Certification Council for Professional Dog Trainers",
        "source_type": "credential_standard",
        "title": "Certified Behavior Consultant Canine - Knowledge Assessed",
        "url": "https://www.ccpdt.org/certification/dog-behavior-consultant/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "B",
        "notes": "Canine behavior-consultant experience and certification requirements."
      }
    },
    {
      "edge_id": "edge_0022",
      "from_career_id": "cr_0026",
      "to_career_id": "cr_0049",
      "relationship_type": "specialization",
      "typicality": "possible",
      "education_change": "none",
      "experience_change": "1–3 years + GIS skills",
      "evidence_status": "supported",
      "source_id": "src_tws_diversitytech",
      "notes": "Field technicians with GIS/data skills can specialize spatially.",
      "fromCareer": "Wildlife technician / biological science technician",
      "toCareer": "GIS / wildlife spatial analyst",
      "source": {
        "source_id": "src_tws_diversitytech",
        "organization": "West Virginia DNR / TWS",
        "source_type": "job_posting",
        "title": "Wildlife Diversity/Natural Heritage Zoology Technician",
        "url": "https://careers.wildlife.org/job/wildlife-diversitynatural-heritage-zoology-technician-west-virginia/85441685/",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "C",
        "notes": "Current wildlife-diversity technician posting."
      }
    },
    {
      "edge_id": "edge_0027",
      "from_career_id": "cr_0027",
      "to_career_id": "cr_0036",
      "relationship_type": "specialization",
      "typicality": "possible",
      "education_change": "M.S. often useful",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_usgs_npwrc",
      "notes": "Spatial and movement specialties build on wildlife ecology plus quantitative methods.",
      "fromCareer": "Wildlife biologist",
      "toCareer": "Movement / spatial ecologist",
      "source": {
        "source_id": "src_usgs_npwrc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Northern Prairie Wildlife Research Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/northern-prairie-wildlife-research-center/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific/geospatial titles in federal wildlife research."
      }
    },
    {
      "edge_id": "edge_0040",
      "from_career_id": "cr_0088",
      "to_career_id": "cr_0051",
      "relationship_type": "specialization",
      "typicality": "possible",
      "education_change": "M.S. often useful",
      "experience_change": "2–5 years",
      "evidence_status": "supported",
      "source_id": "src_usgs_eesc",
      "notes": "Data-science skills can specialize into quantitative ecological inference.",
      "fromCareer": "Ecological data scientist",
      "toCareer": "Quantitative ecologist / biometrician",
      "source": {
        "source_id": "src_usgs_eesc",
        "organization": "U.S. Geological Survey",
        "source_type": "employee_directory",
        "title": "Eastern Ecological Science Center - Employee Directory",
        "url": "https://www.usgs.gov/centers/eesc/connect",
        "published_date": null,
        "retrieved_date": "2026-09-08",
        "authority_tier": "A",
        "notes": "Current scientific titles in federal ecological research."
      }
    }
  ],
  "sources": [
    {
      "source_id": "src_aza_types",
      "organization": "Association of Zoos and Aquariums",
      "source_type": "professional_reference",
      "title": "Types of Zoo and Aquarium Jobs",
      "url": "https://www.aza.org/types-of-zoo-and-aquarium-jobs",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Official AZA career taxonomy and role descriptions."
    },
    {
      "source_id": "src_aza_jobs",
      "organization": "Association of Zoos and Aquariums",
      "source_type": "job_board",
      "title": "AZA Career Center",
      "url": "https://www.aza.org/Jobs/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Current and recent zoo/aquarium job postings."
    },
    {
      "source_id": "src_aza_pmc",
      "organization": "Association of Zoos and Aquariums",
      "source_type": "professional_reference",
      "title": "Population Management Center",
      "url": "https://www.aza.org/population-management-center",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Population biologists, planning coordinator, research support, and managed-population planning."
    },
    {
      "source_id": "src_aza_programs",
      "organization": "Association of Zoos and Aquariums",
      "source_type": "professional_reference",
      "title": "Animal Program Deadlines and Program Leader Roles",
      "url": "https://www.aza.org/animal-program-deadlines",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "SSP and studbook role requirements/deadlines."
    },
    {
      "source_id": "src_aza_program_roles",
      "organization": "Association of Zoos and Aquariums",
      "source_type": "professional_reference",
      "title": "Updates to AZA Animal Programs - Role Descriptions",
      "url": "https://annual.aza.org/2024/documents/Boland__Marissa_Updates_to_AZA_s_Animal_Programs.pdf",
      "published_date": "2024",
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "SSP Coordinator and Studbook Keeper role descriptions."
    },
    {
      "source_id": "src_tws_jobs",
      "organization": "The Wildlife Society",
      "source_type": "job_board",
      "title": "The Wildlife Society Career Center",
      "url": "https://careers.wildlife.org/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Current wildlife-industry job postings."
    },
    {
      "source_id": "src_nwra_jobs",
      "organization": "National Wildlife Rehabilitators Association",
      "source_type": "job_board",
      "title": "NWRA Career Center",
      "url": "https://www.nwrawildlife.org/networking/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Current wildlife rehabilitation jobs and internships."
    },
    {
      "source_id": "src_usgs_eesc",
      "organization": "U.S. Geological Survey",
      "source_type": "employee_directory",
      "title": "Eastern Ecological Science Center - Employee Directory",
      "url": "https://www.usgs.gov/centers/eesc/connect",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Current scientific titles in federal ecological research."
    },
    {
      "source_id": "src_usgs_werc",
      "organization": "U.S. Geological Survey",
      "source_type": "employee_directory",
      "title": "Western Ecological Research Center - Employee Directory",
      "url": "https://www.usgs.gov/centers/werc/connect",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Current scientific titles in federal ecological research."
    },
    {
      "source_id": "src_usgs_npwrc",
      "organization": "U.S. Geological Survey",
      "source_type": "employee_directory",
      "title": "Northern Prairie Wildlife Research Center - Employee Directory",
      "url": "https://www.usgs.gov/centers/northern-prairie-wildlife-research-center/connect",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Current scientific/geospatial titles in federal wildlife research."
    },
    {
      "source_id": "src_opm_0486",
      "organization": "U.S. Office of Personnel Management",
      "source_type": "qualification_standard",
      "title": "Wildlife Biology Series 0486",
      "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/wildlife-biology-series-0486/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Federal wildlife-biologist education requirements."
    },
    {
      "source_id": "src_opm_0485",
      "organization": "U.S. Office of Personnel Management",
      "source_type": "qualification_standard",
      "title": "Wildlife Refuge Management Series 0485",
      "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/wildlife-refuge-management-series-0485/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Federal wildlife-refuge management education requirements."
    },
    {
      "source_id": "src_opm_0410",
      "organization": "U.S. Office of Personnel Management",
      "source_type": "qualification_standard",
      "title": "Zoology Series 0410",
      "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/zoology-series-0410/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Federal zoology education requirements."
    },
    {
      "source_id": "src_opm_0408",
      "organization": "U.S. Office of Personnel Management",
      "source_type": "qualification_standard",
      "title": "Ecology Series 0408",
      "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/ecology-series-0408/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Federal ecology education requirements."
    },
    {
      "source_id": "src_opm_0440",
      "organization": "U.S. Office of Personnel Management",
      "source_type": "qualification_standard",
      "title": "Genetics Series 0440",
      "url": "https://www.opm.gov/policy-data-oversight/classification-qualifications/general-schedule-qualification-standards/0400/genetics-series-0440/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Federal genetics education requirements."
    },
    {
      "source_id": "src_fws_rehab",
      "organization": "U.S. Fish and Wildlife Service",
      "source_type": "permit_standard",
      "title": "Migratory Bird Rehabilitation Permit 3-200-10b",
      "url": "https://www.fws.gov/service/3-200-10b-migratory-bird-rehabilitation",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Federal migratory-bird rehabilitation permit and experience requirements."
    },
    {
      "source_id": "src_tws_cert",
      "organization": "The Wildlife Society",
      "source_type": "credential_standard",
      "title": "TWS Wildlife Biologist Certifications",
      "url": "https://wildlife.org/tws-certifications/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "AWB/CWB certification structure and experience requirements."
    },
    {
      "source_id": "src_abs_caab",
      "organization": "Animal Behavior Society",
      "source_type": "credential_standard",
      "title": "CAAB / ACAAB Certification Requirements",
      "url": "https://www.animalbehaviorsociety.org/web/committees-applied-behavior-caab.php",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Research-based graduate education and experience requirements for applied-animal-behavior certification."
    },
    {
      "source_id": "src_ccpdt_cbcc",
      "organization": "Certification Council for Professional Dog Trainers",
      "source_type": "credential_standard",
      "title": "Certified Behavior Consultant Canine - Knowledge Assessed",
      "url": "https://www.ccpdt.org/certification/dog-behavior-consultant/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Canine behavior-consultant experience and certification requirements."
    },
    {
      "source_id": "src_iaabc_shelter",
      "organization": "International Association of Animal Behavior Consultants",
      "source_type": "credential_standard",
      "title": "Shelter Behavior Affiliate Credential",
      "url": "https://iaabc.org/en/affiliate-credentials",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Shelter-behavior credential and recommended experience."
    },
    {
      "source_id": "src_aza_curator_behavior",
      "organization": "Gladys Porter Zoo / AZA",
      "source_type": "job_posting",
      "title": "Curator of Behavioral Husbandry",
      "url": "https://www.aza.org/jobs?job=51772",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Detailed role posting."
    },
    {
      "source_id": "src_aza_senior_trainer",
      "organization": "John G. Shedd Aquarium / AZA",
      "source_type": "job_posting",
      "title": "(Sr.) Trainer",
      "url": "https://www.aza.org/JOBS?job=52529",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Trainer/senior trainer posting with pay range."
    },
    {
      "source_id": "src_aza_wildlife_behavior",
      "organization": "San Diego Zoo Wildlife Alliance / AZA",
      "source_type": "job_posting",
      "title": "Wildlife Care Specialist, Behavior",
      "url": "https://www.aza.org/jobs?job=51629",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Behavior/training wildlife-care posting."
    },
    {
      "source_id": "src_aza_registrar",
      "organization": "Lee Richardson Zoo / AZA",
      "source_type": "job_posting",
      "title": "Registrar",
      "url": "https://www.aza.org/Jobs?job=52409",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Animal records, permits, transfer, ZIMS, and database role."
    },
    {
      "source_id": "src_aza_curator",
      "organization": "Mesker Park Zoo / AZA",
      "source_type": "job_posting",
      "title": "Animal Curator",
      "url": "https://www.aza.org/Jobs/?job=52644",
      "published_date": "2026-09-06",
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Current curator posting with salary."
    },
    {
      "source_id": "src_aza_animalcare",
      "organization": "Greenville Zoo / AZA",
      "source_type": "job_posting",
      "title": "Animal Care Specialist",
      "url": "https://www.aza.org/JOBS?job=52646",
      "published_date": "2026-09-07",
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Current animal-care posting with salary and education/experience."
    },
    {
      "source_id": "src_aza_aquariumcare",
      "organization": "Kansas City Zoo & Aquarium / AZA",
      "source_type": "job_posting",
      "title": "Animal Care Specialist - Aquarium Team",
      "url": "https://www.aza.org/jobs?job=51307",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Aquarium animal-care posting with salary and dive requirements."
    },
    {
      "source_id": "src_aza_elephantcomm",
      "organization": "San Diego Zoo Wildlife Alliance / AZA",
      "source_type": "job_posting",
      "title": "Post Doctoral Associate, Elephant Communication",
      "url": "https://www.aza.org/jobs?job=51494",
      "published_date": "2026-05-25",
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Advanced communication research posting with salary."
    },
    {
      "source_id": "src_aza_genetics",
      "organization": "San Diego Zoo Wildlife Alliance / AZA",
      "source_type": "job_posting",
      "title": "Conservation Genetics Post Doctoral Associate",
      "url": "https://www.aza.org/jobs?job=51965",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Conservation genetics posting with salary."
    },
    {
      "source_id": "src_tws_diversitytech",
      "organization": "West Virginia DNR / TWS",
      "source_type": "job_posting",
      "title": "Wildlife Diversity/Natural Heritage Zoology Technician",
      "url": "https://careers.wildlife.org/job/wildlife-diversitynatural-heritage-zoology-technician-west-virginia/85441685/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Current wildlife-diversity technician posting."
    },
    {
      "source_id": "src_tws_habitatdelivery",
      "organization": "American Bird Conservancy / TWS",
      "source_type": "job_posting",
      "title": "GCJV Habitat Delivery Coordinator",
      "url": "https://careers.wildlife.org/job/gulf-coast-joint-venture-gcjv-coastal-grassland-incentive-program-cgrip-and-habitat-delivery-coordinator/85122735/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Habitat delivery posting with salary and education."
    },
    {
      "source_id": "src_tws_wildlife_manager",
      "organization": "Washington Department of Fish & Wildlife / TWS",
      "source_type": "job_posting",
      "title": "Regional Wildlife Program Manager",
      "url": "https://careers.wildlife.org/job/regional-wildlife-program-manager-north-puget-sound-region-4/85512902/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Regional wildlife leadership posting with salary and experience."
    },
    {
      "source_id": "src_tws_labmanager",
      "organization": "East Texas A&M University / TWS",
      "source_type": "job_posting",
      "title": "Quail Research Laboratory Manager",
      "url": "https://careers.wildlife.org/jobs/function/Wildlife/",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Research laboratory manager posting with salary and B.S. requirement."
    },
    {
      "source_id": "src_nwra_tech",
      "organization": "Ohio Wildlife Center / NWRA",
      "source_type": "job_posting",
      "title": "Wildlife Rehabilitation Technician",
      "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097691&view=2",
      "published_date": "2026-08-24",
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Current rehabilitation technician posting."
    },
    {
      "source_id": "src_nwra_rehab",
      "organization": "Tucson Wildlife Center / NWRA",
      "source_type": "job_posting",
      "title": "Rehabilitator",
      "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097520&view=2",
      "published_date": "2026-08-21",
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Current rehabilitation leadership posting."
    },
    {
      "source_id": "src_nwra_specialist",
      "organization": "Chintimini Wildlife Center / NWRA",
      "source_type": "job_posting",
      "title": "Wildlife Rehabilitation Specialist",
      "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1097322&view=2",
      "published_date": "2026-08-19",
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Current rehabilitation specialist posting."
    },
    {
      "source_id": "src_nwra_manager",
      "organization": "Lake Metroparks / NWRA",
      "source_type": "job_posting",
      "title": "Wildlife Care Manager",
      "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1096932&view=2",
      "published_date": "2026-08-14",
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Wildlife-care management posting with salary and experience."
    },
    {
      "source_id": "src_nwra_avian",
      "organization": "Native Songbird Care & Conservation / NWRA",
      "source_type": "job_posting",
      "title": "Seasonal Avian Care Technician",
      "url": "https://www.nwrawildlife.org/networking/apply_now.aspx?id=1065489&view=2",
      "published_date": "2026-02-15",
      "retrieved_date": "2026-09-08",
      "authority_tier": "C",
      "notes": "Seasonal rehabilitation posting with salary."
    },
    {
      "source_id": "src_usajobs_wildtech",
      "organization": "National Park Service / USAJOBS",
      "source_type": "job_posting",
      "title": "Biological Science Technician (Wildlife)",
      "url": "https://www.usajobs.gov/job/882687500",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Current GS-7 wildlife technician posting."
    },
    {
      "source_id": "src_usajobs_refuge",
      "organization": "U.S. Fish and Wildlife Service / USAJOBS",
      "source_type": "job_posting",
      "title": "Wildlife Refuge Manager - Winona",
      "url": "https://www.usajobs.gov/job/883089800",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Current GS-12 refuge manager posting."
    },
    {
      "source_id": "src_usajobs_refuge2",
      "organization": "U.S. Fish and Wildlife Service / USAJOBS",
      "source_type": "job_posting",
      "title": "Wildlife Refuge Manager - Willapa",
      "url": "https://www.usajobs.gov/job/883251400",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Current GS-13 refuge manager posting."
    },
    {
      "source_id": "src_usajobs_fwbio",
      "organization": "U.S. Fish and Wildlife Service / USAJOBS",
      "source_type": "job_posting",
      "title": "Fish and Wildlife Biologist - State College",
      "url": "https://www.usajobs.gov/job/882387200",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Current GS-12 fish and wildlife biologist posting."
    },
    {
      "source_id": "src_usajobs_seniorbio",
      "organization": "U.S. Fish and Wildlife Service / USAJOBS",
      "source_type": "job_posting",
      "title": "Senior Fish and Wildlife Biologist - Fort Worth",
      "url": "https://doi.usajobs.gov/job/882813600",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "A",
      "notes": "Current GS-12 senior fish and wildlife biologist posting."
    },
    {
      "source_id": "source_aza_jobs_board",
      "organization": "Association of Zoos & Aquariums",
      "source_type": "job_board",
      "title": "AZA Jobs board",
      "url": "https://www.aza.org/Jobs",
      "published_date": null,
      "retrieved_date": "2026-09-08",
      "authority_tier": "B",
      "notes": "Public AZA employment board; exhaustive snapshot ingestion target."
    }
  ],
  "dataSummary": {
    "asOf": "2026-09-08",
    "canonicalRoles": 93,
    "roleFamilies": 32,
    "domains": 7,
    "observedTitles": 71,
    "currentRecentPostings": 58,
    "salaryObservations": 20,
    "sources": 44,
    "searchAliases": 538,
    "openReviewItems": 81,
    "explicitProgressionEdges": 48,
    "competencies": 26,
    "rolesWithPostingEvidence": 31,
    "rolesWithObservedTitles": 37,
    "sourceTierCounts": {
      "A": 14,
      "B": 12,
      "C": 18
    },
    "marketSnapshotJobs": 0,
    "marketJobsClassified": 0,
    "marketJobsReviewed": 0,
    "marketJobsMatched": 0,
    "marketJobsPendingReview": 0,
    "marketScrapeDate": null
  },
  "researchGaps": [
    {
      "review_id": "review_0002",
      "entity_id": "cr_0002",
      "career_name": "Animal behaviorist / applied animal behavior scientist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0023",
      "entity_id": "cr_0022",
      "career_name": "Animal collection / management specialist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0005",
      "entity_id": "cr_0004",
      "career_name": "Animal learning researcher",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0007",
      "entity_id": "cr_0007",
      "career_name": "Animal welfare / behavior coordinator",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0006",
      "entity_id": "cr_0006",
      "career_name": "Animal welfare scientist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0029",
      "entity_id": "cr_0032",
      "career_name": "Behavioral ecologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0008",
      "entity_id": "cr_0008",
      "career_name": "Behavioral husbandry specialist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0075",
      "entity_id": "cr_0080",
      "career_name": "Canine behavior consultant",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0015",
      "entity_id": "cr_0013",
      "career_name": "Companion-animal behavior researcher",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0004",
      "entity_id": "cr_0003",
      "career_name": "Comparative cognition researcher",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0030",
      "entity_id": "cr_0033",
      "career_name": "Conservation biologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0022",
      "entity_id": "cr_0021",
      "career_name": "Conservation-breeding scientist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0021",
      "entity_id": "cr_0020",
      "career_name": "Conservation-breeding technician",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0048",
      "entity_id": "cr_0045",
      "career_name": "Ecological research technician",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0032",
      "entity_id": "cr_0034",
      "career_name": "Endangered-species biologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0009",
      "entity_id": "cr_0009",
      "career_name": "Enrichment coordinator / specialist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0057",
      "entity_id": "cr_0052",
      "career_name": "Environmental consultant — wildlife/ecology",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0059",
      "entity_id": "cr_0053",
      "career_name": "Environmental permitting / compliance biologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0052",
      "entity_id": "cr_0048",
      "career_name": "Evolutionary biologist studying animals",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0046",
      "entity_id": "cr_0044",
      "career_name": "Field ecologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0066",
      "entity_id": "cr_0058",
      "career_name": "Habitat restoration / ecological-monitoring specialist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0045",
      "entity_id": "cr_0043",
      "career_name": "Herpetologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0081",
      "entity_id": "cr_0092",
      "career_name": "Human dimensions / conservation social scientist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0039",
      "entity_id": "cr_0038",
      "career_name": "Human-wildlife conflict specialist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0043",
      "entity_id": "cr_0041",
      "career_name": "Mammalogist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0036",
      "entity_id": "cr_0036",
      "career_name": "Movement / spatial ecologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0062",
      "entity_id": "cr_0055",
      "career_name": "Natural-resource manager",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0051",
      "entity_id": "cr_0047",
      "career_name": "Neuroethologist / neural-behavior researcher",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0044",
      "entity_id": "cr_0042",
      "career_name": "Ornithologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0063",
      "entity_id": "cr_0056",
      "career_name": "Park / service biologist or resource specialist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0034",
      "entity_id": "cr_0035",
      "career_name": "Population ecologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0028",
      "entity_id": "cr_0031",
      "career_name": "Post-release monitoring biologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0056",
      "entity_id": "cr_0051",
      "career_name": "Quantitative ecologist / biometrician",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0027",
      "entity_id": "cr_0030",
      "career_name": "Reintroduction / release field technician",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0080",
      "entity_id": "cr_0091",
      "career_name": "Remote sensing / geospatial ecologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0069",
      "entity_id": "cr_0066",
      "career_name": "Research scientist / principal investigator",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0074",
      "entity_id": "cr_0075",
      "career_name": "SSP coordinator / studbook keeper",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0072",
      "entity_id": "cr_0072",
      "career_name": "Science writer / communicator — biology and animals",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0011",
      "entity_id": "cr_0010",
      "career_name": "Science-based animal trainer",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0012",
      "entity_id": "cr_0011",
      "career_name": "Service-dog / assistance-animal trainer",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0014",
      "entity_id": "cr_0012",
      "career_name": "Shelter behavior specialist / coordinator",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0076",
      "entity_id": "cr_0082",
      "career_name": "Species recovery biologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0068",
      "entity_id": "cr_0059",
      "career_name": "University / laboratory research assistant",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0070",
      "entity_id": "cr_0067",
      "career_name": "University professor",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0037",
      "entity_id": "cr_0037",
      "career_name": "Wildlife disease / ecophysiology specialist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0026",
      "entity_id": "cr_0029",
      "career_name": "Wildlife rehabilitation / release coordinator",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0019",
      "entity_id": "cr_0019",
      "career_name": "Zoo / aquarium behavioral researcher",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0017",
      "entity_id": "cr_0018",
      "career_name": "Zoo / aquarium welfare specialist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0024",
      "entity_id": "cr_0024",
      "career_name": "Zoo conservation coordinator",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0041",
      "entity_id": "cr_0040",
      "career_name": "Zoologist",
      "issue_type": "observed_title_coverage",
      "priority": "high",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Find authoritative employer/professional examples of actual titles."
    },
    {
      "review_id": "review_0050",
      "entity_id": "cr_0046",
      "career_name": "Animal physiologist",
      "issue_type": "current_posting_coverage",
      "priority": "medium",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Add current/recent posting evidence when available."
    },
    {
      "review_id": "review_0078",
      "entity_id": "cr_0088",
      "career_name": "Ecological data scientist",
      "issue_type": "current_posting_coverage",
      "priority": "medium",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Add current/recent posting evidence when available."
    },
    {
      "review_id": "review_0054",
      "entity_id": "cr_0049",
      "career_name": "GIS / wildlife spatial analyst",
      "issue_type": "current_posting_coverage",
      "priority": "medium",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Add current/recent posting evidence when available."
    },
    {
      "review_id": "review_0055",
      "entity_id": "cr_0050",
      "career_name": "Quantitative ecology research assistant",
      "issue_type": "current_posting_coverage",
      "priority": "medium",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Add current/recent posting evidence when available."
    },
    {
      "review_id": "review_0077",
      "entity_id": "cr_0087",
      "career_name": "Research ecologist",
      "issue_type": "current_posting_coverage",
      "priority": "medium",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Add current/recent posting evidence when available."
    },
    {
      "review_id": "review_0079",
      "entity_id": "cr_0089",
      "career_name": "Research statistician — ecology/biology",
      "issue_type": "current_posting_coverage",
      "priority": "medium",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Add current/recent posting evidence when available."
    },
    {
      "review_id": "review_0001",
      "entity_id": "cr_0001",
      "career_name": "Animal behavior research assistant / technician",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0003",
      "entity_id": "cr_0002",
      "career_name": "Animal behaviorist / applied animal behavior scientist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0065",
      "entity_id": "cr_0057",
      "career_name": "Conservation NGO scientist / coordinator",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0031",
      "entity_id": "cr_0033",
      "career_name": "Conservation biologist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0049",
      "entity_id": "cr_0045",
      "career_name": "Ecological research technician",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0033",
      "entity_id": "cr_0034",
      "career_name": "Endangered-species biologist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0010",
      "entity_id": "cr_0009",
      "career_name": "Enrichment coordinator / specialist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0058",
      "entity_id": "cr_0052",
      "career_name": "Environmental consultant — wildlife/ecology",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0060",
      "entity_id": "cr_0053",
      "career_name": "Environmental permitting / compliance biologist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0053",
      "entity_id": "cr_0048",
      "career_name": "Evolutionary biologist studying animals",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0047",
      "entity_id": "cr_0044",
      "career_name": "Field ecologist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0067",
      "entity_id": "cr_0058",
      "career_name": "Habitat restoration / ecological-monitoring specialist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0040",
      "entity_id": "cr_0038",
      "career_name": "Human-wildlife conflict specialist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0061",
      "entity_id": "cr_0054",
      "career_name": "Natural-resource agency biologist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0064",
      "entity_id": "cr_0056",
      "career_name": "Park / service biologist or resource specialist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0035",
      "entity_id": "cr_0035",
      "career_name": "Population ecologist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0016",
      "entity_id": "cr_0016",
      "career_name": "Sanctuary animal caregiver",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0073",
      "entity_id": "cr_0072",
      "career_name": "Science writer / communicator — biology and animals",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0013",
      "entity_id": "cr_0011",
      "career_name": "Service-dog / assistance-animal trainer",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0071",
      "entity_id": "cr_0067",
      "career_name": "University professor",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0038",
      "entity_id": "cr_0037",
      "career_name": "Wildlife disease / ecophysiology specialist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0020",
      "entity_id": "cr_0019",
      "career_name": "Zoo / aquarium behavioral researcher",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0018",
      "entity_id": "cr_0018",
      "career_name": "Zoo / aquarium welfare specialist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0025",
      "entity_id": "cr_0025",
      "career_name": "Zoo research coordinator",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    },
    {
      "review_id": "review_0042",
      "entity_id": "cr_0040",
      "career_name": "Zoologist",
      "issue_type": "progression_coverage",
      "priority": "low",
      "status": "open",
      "created_at": "2026-09-08",
      "notes": "Research explicit natural-growth, lateral, or specialization transitions."
    }
  ],
  "evidenceStatusLabels": {
    "verified_current_market": "Current/recent market evidence",
    "verified_occupation_or_title": "Verified occupation/title",
    "verified_function_title_varies": "Verified work; title varies",
    "established_scientific_specialty": "Established scientific specialty",
    "verified_professional_role": "Verified professional role",
    "verified_professional_assignment": "Professional assignment / additional responsibility"
  },
  "roleKindLabels": {
    "career": "Career role",
    "scientific_specialty": "Scientific specialty",
    "professional_assignment": "Professional assignment",
    "later_career": "Later-career role",
    "education_path": "Graduate education pathway"
  }
};
